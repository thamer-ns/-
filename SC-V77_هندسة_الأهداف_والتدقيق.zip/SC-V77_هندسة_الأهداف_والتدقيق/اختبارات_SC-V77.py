from pathlib import Path
import re

ROOT = Path(__file__).parent
I = ROOT / 'بوصلة_التحليل_اللحظي_SC-V77-I_هندسة_الأهداف.txt'
D = ROOT / 'بوصلة_التحليل_اليومي_SC-V77-D_هندسة_الأهداف.txt'


def require(s, token, label):
    assert token in s, f'missing {label}: {token}'


def strip_comments_strings(s: str) -> str:
    out=[]; i=0; in_string=False
    while i < len(s):
        if not in_string and s.startswith('//', i):
            j=s.find('\n', i)
            if j<0: break
            out.append('\n'); i=j+1; continue
        c=s[i]
        if c=='"':
            in_string=not in_string; out.append(' '); i+=1; continue
        out.append(' ' if in_string else c); i+=1
    return ''.join(out)


def balanced(s):
    t=strip_comments_strings(s)
    pairs={')':'(',']':'[','}':'{'}; st=[]
    for c in t:
        if c in '([{': st.append(c)
        elif c in ')]}':
            assert st and st[-1]==pairs[c], f'unbalanced at {c}'
            st.pop()
    assert not st, f'unclosed {st[-10:]}'


def common(s, title):
    assert s.count('//@version=6') == 1
    assert s.count('indicator(') == 1
    assert s.count('request.security(') == 3
    assert s.count('request.security_lower_tf(') == 0
    assert s.count('alertcondition(') == 7
    assert s.count('table.new(') == 1
    assert s.count('plot(') == 7
    require(s, f'"{title}"', 'title')
    require(s, 'table.new(position.top_right, 2, 5', 'compact dashboard')
    require(s, 'array.from("الاتجاه", "الفرصة", "التأكيد", "السياق")', 'dashboard rows')
    require(s, 'f_nearest_stored_pivot', 'historical pivots')
    require(s, 'float activeRetestTolerance = nz(', 'fresh tolerance')
    require(s, 'int channelReturnWindowBars = fakeoutWindow', 'fakeout window')
    require(s, 'sweepUpperWickShare <= 0.25', 'upper wick filter')
    require(s, 'sweepLowerWickShare <= 0.25', 'lower wick filter')
    require(s, 'bodyRatio >= 0.40', 'body filter')
    require(s, 'fibObjective1', 'fib extension')
    require(s, 'retracementTargetLevel', 'fib retracement')
    require(s, 'float fallbackTarget2Distance', 'T2 fallback')
    require(s, 'float fallbackTarget3Distance', 'T3 fallback')
    require(s, 'float tickRoundedCandidate', 'tick-rounded trail')
    require(s, 'target1HitBar == bar_index or target2HitBar == bar_index or target3HitBar == bar_index', 'target alert state')
    require(s, 'stockChartAllowed and barstate.isconfirmed and (bullishBreakFailed', 'fakeout alert')
    require(s, 'closedHigherTrendBias := higherWeightedScore > 0', 'pure HTF snapshot')
    require(s, 'f_closed_htf_state()', 'closed HTF helper')
    assert s.count('lookahead = barmerge.lookahead_on') == 3
    assert 'riskText' not in s
    assert 'SC-V74' not in s
    assert '\ufffd' not in s
    balanced(s)


def horizon_i(x):
    return 1.00 if x<=60 else 1.05 if x<=300 else 1.15 if x<=900 else 1.25 if x<=1800 else 1.35 if x<=3600 else 1.55 if x<=14400 else 1.75

def stop_i(x):
    lo=0.60 if x<=60 else 0.65 if x<=300 else 0.75 if x<=900 else 0.85 if x<=1800 else 1.00 if x<=3600 else 1.15 if x<=14400 else 1.30
    hi=2.50 if x<=60 else 2.75 if x<=300 else 3.00 if x<=900 else 3.25 if x<=1800 else 3.75 if x<=3600 else 4.50 if x<=14400 else 5.25
    return lo,hi

def horizon_d(x):
    return 1.30 if x<=86400 else 1.75 if x<=604800 else 2.20 if x<=31*86400 else 2.60

def stop_d(x):
    return (1.15,5.0) if x<=86400 else (1.40,6.0) if x<=604800 else (1.70,7.0) if x<=31*86400 else (2.0,8.0)


def test_intraday():
    s=I.read_text(encoding='utf-8'); common(s,'SC-V77-I')
    require(s, 'timeframe.isintraday and chartSeconds >= 60 and chartSeconds < maximumSupportedSeconds', 'intraday support')
    require(s, 'float horizonFactor = chartSeconds <= 60 ? 1.00', 'I horizon')
    require(s, 'array.from(historicalPivotObstacle, horizontalObstacleLevel, opposingZoneBoundary, targetWyckoffLevel, minorChannelBoundaryTarget, majorChannelBoundaryTarget)', 'I hard obstacles')
    require(s, 'array.from(historicalPivotObstacle, horizontalObstacleLevel, opposingZoneBoundary, targetWyckoffLevel, minorChannelBoundaryTarget, majorChannelBoundaryTarget, minorChannelMeasuredTarget, majorChannelMeasuredTarget, fibObjective1, retracementTargetLevel', 'I ranked ladder')
    require(s, 'priorDown[rangeBars + 1]', 'pre-range down')
    require(s, 'priorUp[rangeBars + 1]', 'pre-range up')
    for x,e,st in [(60,1.0,(.6,2.5)),(300,1.05,(.65,2.75)),(900,1.15,(.75,3)),(1800,1.25,(.85,3.25)),(3600,1.35,(1,3.75)),(14400,1.55,(1.15,4.5)),(21600,1.75,(1.3,5.25))]:
        assert horizon_i(x)==e and stop_i(x)==st


def test_daily():
    s=D.read_text(encoding='utf-8'); common(s,'SC-V77-D')
    require(s, 'chartSeconds >= minimumSupportedSeconds and chartSeconds <= maximumSupportedSeconds', 'daily support')
    require(s, '? 1.30 : chartSeconds <= 7 * 24 * 60 * 60 ? 1.75', 'D horizon')
    require(s, 'f_stop_atr_limits(chartSeconds)', 'D stop helper')
    require(s, 'historicalPivotObstacle, horizontalObstacleLevel, opposingZoneBoundary, targetWyckoffLevel, primaryChannelBoundaryTarget, secondaryChannelBoundaryTarget', 'D hard obstacles')
    require(s, 'primaryChannelMeasuredTarget, secondaryChannelMeasuredTarget, fibObjective1, retracementTargetLevel', 'D target ladder')
    require(s, 'principalChannelPriority = chartSeconds >= 7 * 24 * 60 * 60', 'D channel priority')
    for x,e,st in [(86400,1.3,(1.15,5)),(604800,1.75,(1.4,6)),(30*86400,2.2,(1.7,7)),(90*86400,2.6,(2,8))]:
        assert horizon_d(x)==e and stop_d(x)==st


def test_monotonic():
    for long in (True,False):
        entry=100.; risk=2.; horizon=1.75
        d1=risk*max(1*horizon,1)
        d2=risk*max(2*horizon,max(1*horizon,1)+.75)
        d3=risk*max(3*horizon,max(2*horizon,max(1*horizon,1)+.75)+1)
        ts=[entry+d1,entry+d2,entry+d3] if long else [entry-d1,entry-d2,entry-d3]
        assert (entry<ts[0]<ts[1]<ts[2]) if long else (entry>ts[0]>ts[1]>ts[2])

if __name__=='__main__':
    test_intraday(); test_daily(); test_monotonic()
    print('SC-V77 static/logic checks: PASS')
