# جرد ملفات مشروع Telegram المرفوعة

تم تحليل AST وتشغيل `py_compile` على جميع الملفات المدرجة.

| الملف | الأسطر | Classes | Functions | SHA256 |
|---|---:|---:|---:|---|
| `presets_v39.py` | 170 | 1 | 2 | `71b08eb2f025eeaf75a8a17ee978a0d9d6b8f01f8d1b037ba62cf09262709063` |
| `risk_engine_v41.py` | 613 | 2 | 11 | `c95c431340dcd62da878f02dafdfc97d54225ca34297e48dc9ab793915efa59d` |
| `school_engine_v38.py` | 598 | 5 | 11 | `05505db8c6516c820c283c38107df01078afe0c74ad439085e84bc4840cd0832` |
| `school_engine_v38_final.py` | 521 | 1 | 7 | `3f89426115106150aaddf20405768327319c35e400db205f6f1e0d9860b660a5` |
| `school_engine_v38_safe.py` | 106 | 1 | 1 | `ba8fc26842b25dbb77292b556e3c709c68a55c20e9083be5a9314e72905eccde` |
| `school_engine_v39.py` | 296 | 2 | 4 | `dbf6ffdfeb61ebbfd876eb71b69a6a69a54f4ec048628c101c1bc69fce28a987` |
| `school_format_v38.py` | 362 | 0 | 12 | `7808d8cd4de13ff9a2b2d8c3e63c443df4d64c237edf362595d38dbe670e1ac7` |
| `school_format_v39.py` | 370 | 0 | 14 | `83e532d86c12a0bd3124cb971c73941ee2123807d7d1699a3dd43b4b15c081d1` |
| `stored_presentation_v40.py` | 63 | 0 | 2 | `de1171b07d78e17120f73838a16ed52b7398d145d759f6edf9fab661786e8802` |
| `technical.py` | 478 | 5 | 14 | `6c582ab083e22185255466da15cfb954fff3898d3025fd6a15c7b860a49d9b71` |
| `telegram.py` | 158 | 1 | 2 | `0813f2fda09de78e6ba0b6ba401a75c73337f2158b31e739f5ae7e4835ca633e` |
| `universes.py` | 147 | 1 | 1 | `a1438ea9decdc0963246da75b2724fffe7d3b399c52927718a7516635492e5c6` |

## presets_v39.py

**Classes:** `V39PresetScanner` L84-170

**Functions:**
- `frame_code_label` (sync) L35-37
- `build_signal_snapshot_v39` (sync) L40-81

## risk_engine_v41.py

**Classes:** `TimeframeRiskProfile` L10-20, `AdaptivePlan` L24-39

**Functions:**
- `profile_for` (sync) L58-59
- `saudi_tick_size` (sync) L62-73
- `tick_size` (sync) L76-96
- `round_to_tick` (sync) L99-115
- `round_market_price` (sync) L118-132
- `_true_ranges` (sync) L135-143
- `_quantile` (sync) L146-156
- `_structural_levels` (sync) L159-211
- `_duration_window` (sync) L214-350
- `estimate_remaining_duration` (sync) L353-371
- `build_adaptive_plan` (sync) L374-599

## school_engine_v38.py

**Classes:** `FrameSpec` L35-42, `SchoolSignal` L79-85, `SchoolConsensus` L89-101, `SchoolFrameAnalysis` L105-112, `SchoolConsensusAnalyzer` L484-598

**Functions:**
- `_promote` (sync) L115-128
- `_body_metrics` (sync) L131-136
- `_macd_hist_series` (sync) L139-144
- `_school_signals` (sync) L147-284
- `evaluate_school_consensus` (sync) L287-308
- `_school_plan` (sync) L311-338
- `apply_school_consensus` (sync) L341-361
- `_timezone` (sync) L364-371
- `_aggregate` (sync) L374-375
- `_equity_period_complete` (sync) L378-418
- `resample_candles` (sync) L421-481

## school_engine_v38_final.py

**Classes:** `FinalSchoolConsensusAnalyzer` L499-521

**Functions:**
- `_corrected_school_signals` (sync) L26-156
- `_school_axis` (sync) L173-174
- `_axis_best` (sync) L177-184
- `_axis_score` (sync) L187-193
- `evaluate_school_consensus_final` (sync) L195-307
- `_direct_school_plan` (sync) L310-385
- `apply_school_consensus_final` (sync) L388-496

## school_engine_v38_safe.py

**Classes:** `SafeSchoolConsensusAnalyzer` L52-106

**Functions:**
- `_last_4h_bucket_closed` (sync) L18-49

## school_engine_v39.py

**Classes:** `VerifiedSchoolFrameAnalysis` L35-40, `VerifiedSchoolConsensusAnalyzer` L219-296

**Functions:**
- `_promote_verified` (sync) L43-59
- `_valid_plan_geometry` (sync) L62-97
- `is_executable_opportunity` (sync) L100-109
- `finalize_school_frame` (sync) L112-216

## school_format_v38.py

**Classes:** —

**Functions:**
- `_price` (sync) L27-30
- `_progress` (sync) L33-39
- `select_primary_frame_v38` (sync) L42-52
- `_direction_text` (sync) L55-60
- `_state_icon` (sync) L63-75
- `_entry_zone` (sync) L78-84
- `_duration` (sync) L87-128
- `_school_lines` (sync) L131-151
- `_frame_line` (sync) L154-168
- `_compact` (sync) L171-195
- `format_analysis_v38` (sync) L198-303
- `format_scan_v38` (sync) L306-362

## school_format_v39.py

**Classes:** —

**Functions:**
- `_price` (sync) L28-31
- `_progress` (sync) L34-40
- `_duration` (sync) L43-72
- `_entry_zone` (sync) L75-81
- `_qualified` (sync) L84-85
- `_plan_valid` (sync) L88-89
- `select_primary_frame_v39` (sync) L92-104
- `_direction_text` (sync) L107-110
- `_state_icon` (sync) L113-124
- `_school_lines` (sync) L127-163
- `_frame_line` (sync) L166-184
- `_compact` (sync) L187-203
- `format_analysis_v39` (sync) L206-318
- `format_scan_v39` (sync) L321-370

## stored_presentation_v40.py

**Classes:** —

**Functions:**
- `_stored_block` (sync) L17-33
- `active_plan_pages` (sync) L36-60

## technical.py

**Classes:** `MarketDataError` L10-11, `Candle` L15-21, `FrameAnalysis` L25-64, `LiveAnalysis` L68-85, `SymbolSpec` L89-94

**Functions:**
- `normalize_symbol` (sync) L114-137
- `_ema` (sync) L140-149
- `_rsi` (sync) L152-165
- `_atr` (sync) L168-181
- `_pivot_levels` (sync) L184-194
- `_cluster` (sync) L197-208
- `_levels` (sync) L211-224
- `_structure` (sync) L227-255
- `_volume_ratio` (sync) L258-265
- `_round` (sync) L268-269
- `_setup_event` (sync) L272-294
- `_engulfing` (sync) L297-303
- `_build_plan` (sync) L306-351
- `analyze_frame` (sync) L354-478

## telegram.py

**Classes:** `TelegramClient` L65-158

**Functions:**
- `_validate_reply_markup` (sync) L12-36
- `validate_telegram_payload` (sync) L39-62

## universes.py

**Classes:** `UniverseCatalog` L69-138

**Functions:**
- `_cboe_symbol` (sync) L64-66
