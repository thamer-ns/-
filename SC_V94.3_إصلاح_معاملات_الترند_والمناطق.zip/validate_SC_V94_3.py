from pathlib import Path
import re, json, hashlib, subprocess, sys

root=Path('/mnt/data/SC_V943_إصلاح_معاملات_الترند_والمناطق')
files={
 'I':root/'output'/'SC_V94_3_I.pine.txt',
 'D':root/'output'/'SC_V94_3_D.pine.txt',
 'FX':root/'output'/'SC_FXM_V18_4.pine.txt',
 'FQ':root/'output'/'SC_FQ3_2.pine.txt',
}
old={
 'I':Path('/mnt/data/SC_V942_إصلاح_منطقي_شامل/output/SC_V94_2_I.pine.txt'),
 'D':Path('/mnt/data/SC_V942_إصلاح_منطقي_شامل/output/SC_V94_2_D.pine.txt'),
 'FX':Path('/mnt/data/SC_V942_إصلاح_منطقي_شامل/output/SC_FXM_V18_3.pine.txt'),
}

def strip_code(text):
    out=[]; i=0; quote=None
    while i<len(text):
        c=text[i]
        if quote:
            if c=='\\' and i+1<len(text): out.extend('  '); i+=2; continue
            if c==quote: quote=None
            out.append(' ' if c!='\n' else '\n'); i+=1; continue
        if c in ('"',"'"): quote=c; out.append(' '); i+=1; continue
        if c=='/' and i+1<len(text) and text[i+1]=='/':
            while i<len(text) and text[i]!='\n': out.append(' '); i+=1
            continue
        out.append(c); i+=1
    return ''.join(out)

def balanced(text):
    s=strip_code(text); stack=[]; pairs={')':'(',']':'[','}':'{'}
    for i,c in enumerate(s):
        if c in '([{': stack.append((c,i))
        elif c in ')]}':
            if not stack or stack[-1][0]!=pairs[c]: return False,('mismatch',i,c,stack[-1] if stack else None)
            stack.pop()
    return (not stack, stack[-1] if stack else None)

def find_matching(s,open_pos):
    depth=0
    for i in range(open_pos,len(s)):
        if s[i]=='(': depth+=1
        elif s[i]==')':
            depth-=1
            if depth==0:return i
    return -1

def split_arg_count(s,op,cp):
    inner=s[op+1:cp]
    if not inner.strip(): return 0
    dep={'(':0,'[':0,'{':0}; count=1
    for c in inner:
        if c=='(':dep['(']+=1
        elif c==')':dep['(']-=1
        elif c=='[':dep['[']+=1
        elif c==']':dep['[']-=1
        elif c=='{':dep['{']+=1
        elif c=='}':dep['{']-=1
        elif c==',' and all(v==0 for v in dep.values()): count+=1
    return count

def function_defs(text):
    s=strip_code(text); defs={}; spans=set()
    # top-level line starts with f_name(
    offset=0
    for line in s.splitlines(True):
        if line and not line[0].isspace():
            m=re.match(r'(f_[A-Za-z0-9_]*)\s*\(',line)
            if m:
                name=m.group(1); namepos=offset+m.start(1); op=offset+line.find('(',m.end(1)-1)
                cp=find_matching(s,op)
                if cp!=-1:
                    # after close paren must be => after whitespace/newlines
                    tail=s[cp+1:cp+80]
                    if re.match(r'\s*=>',tail):
                        defs[name]={'namepos':namepos,'op':op,'cp':cp,'arity':split_arg_count(s,op,cp)}
                        spans.add(namepos)
        offset+=len(line)
    return s,defs,spans

def arity_issues(text):
    s,defs,spans=function_defs(text); issues=[]
    for name,d in defs.items():
        for m in re.finditer(r'\b'+re.escape(name)+r'\s*\(',s):
            if m.start() in spans: continue
            op=s.find('(',m.start())
            cp=find_matching(s,op)
            if cp<0:
                issues.append({'function':name,'position':m.start(),'error':'unclosed call'}); continue
            n=split_arg_count(s,op,cp)
            if n!=d['arity']:
                line=s.count('\n',0,m.start())+1
                issues.append({'function':name,'line':line,'expected':d['arity'],'actual':n})
    return defs,issues

def lexical_count(text):
    s=strip_code(text)
    return len(re.findall(r'[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|==|!=|<=|>=|:=|=>|\S',s))

def function_block(text,name):
    s=strip_code(text)
    m=re.search(r'^'+re.escape(name)+r'\s*\(',s,re.M)
    if not m:return ''
    op=s.find('(',m.start()); cp=find_matching(s,op)
    # start body after => and end next non-indented nonblank
    line_start=s.rfind('\n',0,m.start())+1
    body_start=s.find('=>',cp)+2
    # use original line scan
    pos=body_start
    while pos<len(s):
        nxt=s.find('\n',pos)
        if nxt<0:nxt=len(s)
        line=s[pos:nxt]
        if line.strip() and not line[0].isspace(): return s[line_start:pos]
        pos=nxt+1
    return s[line_start:]

results={'version':'SC-V94.3','files':{},'checks':[],'summary':{}}
all_pass=True
for key,p in files.items():
    t=p.read_text(encoding='utf-8')
    ok,detail=balanced(t)
    defs,arity=arity_issues(t)
    info={'lines':len(t.splitlines()),'chars':len(t),'lexical_tokens_estimate':lexical_count(t),'balanced':ok,'balance_detail':detail,'function_count':len(defs),'arity_issues':arity,'sha256':hashlib.sha256(t.encode()).hexdigest()}
    if key in old:
        ot=old[key].read_text(encoding='utf-8')
        info['comparison_v94_2']={'lines_delta':len(t.splitlines())-len(ot.splitlines()),'chars_delta':len(t)-len(ot),'lexical_tokens_delta':lexical_count(t)-lexical_count(ot)}
    results['files'][key]=info
    all_pass &= ok and not arity

# Run free-variable-before-definition audit.
tech=[str(files[k]) for k in ('I','D','FX')]
proc=subprocess.run(['python','/tmp/pine_freevar_audit.py',*tech],capture_output=True,text=True,check=True)
free=json.loads(proc.stdout)
for r in free:
    key=next(k for k,p in files.items() if str(p)==r['file'])
    results['files'][key]['free_variable_before_definition_issues']=r['issues']
    all_pass &= not r['issues']

checks=[]
def add(name,passed,detail=''):
    global all_pass
    checks.append({'name':name,'pass':bool(passed),'detail':detail})
    if not passed: all_pass=False

for key in ('I','D','FX'):
    t=files[key].read_text()
    b=function_block(t,'f_trendline_retest_state')
    add(f'{key}: retest function receives atrValue', 'float atrValue' in b)
    add(f'{key}: retest function receives closeLocationValue', 'float closeLocationValue' in b)
    add(f'{key}: retest function receives bodyRatioValue', 'float bodyRatioValue' in b)
    add(f'{key}: no late safeAtr dependency in retest function', 'safeAtr' not in b)
    add(f'{key}: no late closeLocation dependency in retest function', not re.search(r'(?<!Value)\bcloseLocation\b',b))
    add(f'{key}: no late bodyRatio dependency in retest function', not re.search(r'(?<!Value)\bbodyRatio\b',b))
    add(f'{key}: call passes calculated values', 'retestWindow, safeAtr, closeLocation, bodyRatio)' in t)
    add(f'{key}: adaptive zone lifetime used', 'effectiveZoneMaxBars' in t and 'zoneMaxBars' not in t)
    add(f'{key}: zone expiration unified', t.count('> effectiveZoneMaxBars')==4, str(t.count('> effectiveZoneMaxBars')))
    add(f'{key}: box lifetime parameter unified', t.count('effectiveZoneMaxBars, bullColor)')==1 and t.count('effectiveZoneMaxBars, bearColor)')==1)
    add(f'{key}: daily ATR width 2x', 'timeframe.isdaily ? 2.0' in t)
    add(f'{key}: weekly ATR width 2.5x', 'timeframe.isweekly ? 2.5' in t)
    add(f'{key}: daily width 8 percent', 'timeframe.isdaily ? 0.08' in t)
    add(f'{key}: weekly width 12 percent', 'timeframe.isweekly ? 0.12' in t)
    add(f'{key}: no infinite zone extension', 'extend = extend.none' in function_block(t,'f_sync_zone_box') and 'extend = extend.right' not in function_block(t,'f_sync_zone_box'))
    add(f'{key}: pivot geometry guard active', 'bool newImportantHighAnchor = false' not in t and 'bool newImportantLowAnchor = false' not in t and 'newImportantHighAnchor' in t and 'newImportantLowAnchor' in t)
    add(f'{key}: trendline retest not hardcoded false', 'bool bullishTrendlineRetest = false' not in t and 'bool bearishTrendlineRetest = false' not in t)
    add(f'{key}: duplicate minor channel source absent', not re.search(r'\bminorChannel',t))
    add(f'{key}: JSON V2 fields complete', all(x in t for x in ['\\"t2\\":','\\"t3\\":','\\"n\\":','\\"q\\":','\\"qm\\":','\\"ct\\":']))
    add(f'{key}: no reserved text variable', not re.search(r'\b(?:bool|int|float|string|color|line|label|box|table)\s+text\b',strip_code(t)))
    add(f'{key}: no invalid UDT history field', not re.search(r'\b(?:ctx|candidate|setupCandidateState)\.[A-Za-z_]\w*\s*\[',strip_code(t)))

fx=files['FX'].read_text()
add('FX: higherTimeframeConflict defined before use', (lambda a,b:a!=-1 and b!=-1 and a<=b)(fx.find('bool higherTimeframeConflict ='),fx.find('higherTimeframeConflict',fx.find('bool higherTimeframeConflict =')+1)))
add('FX: dealingRangeState exists','dealingRangeState' in fx)

fq=files['FQ'].read_text()
add('FQ unchanged from SC-FQ3.2',fq==Path('/mnt/data/SC_V942_إصلاح_منطقي_شامل/output/SC_FQ3_2.pine.txt').read_text())

results['checks']=checks
results['summary']={'checks_total':len(checks),'checks_passed':sum(c['pass'] for c in checks),'static_pass':all_pass,'official_pine_compile_confirmed':False,'note':'IL token count and official compilation require TradingView Pine Editor.'}
(root/'نتائج_التدقيق_SC-V94.3.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(results['summary'],ensure_ascii=False))
for key,info in results['files'].items():
 print(key,info.get('comparison_v94_2'), 'arity',len(info['arity_issues']),'free',len(info.get('free_variable_before_definition_issues',[])))
if not all_pass:
    for c in checks:
        if not c['pass']: print('FAIL',c)
    sys.exit(1)
