from pathlib import Path
import re, json, sys

BUILTINS=set('''open high low close volume time time_close time_tradingday bar_index last_bar_index hl2 hlc3 ohlc4 true false na year month weekofyear dayofmonth dayofweek hour minute second timenow mintick dividends splits earnings'''.split())
NAMESPACES=set('''math ta array line label box table color str syminfo timeframe barstate request input display xloc yloc extend size shape location format plot alert barmerge position text hline strategy session chart matrix map log runtime currency scale font force_overlay'''.split())
KEYWORDS=set('''if else for to by while switch not and or var const type method export import as break continue return in do enum'''.split())
TYPES=set('''bool int float string color line label box table array matrix map void'''.split())
BUILTIN_FUNCS=set('''nz na int float bool string timestamp time fixnan max_bars_back indicator strategy library plot plotshape plotchar plotarrow bgcolor barcolor fill alertcondition alert runtime.error'''.split())
IGNORE=BUILTINS|NAMESPACES|KEYWORDS|TYPES|BUILTIN_FUNCS

func_start_re=re.compile(r'^([A-Za-z_]\w*)\s*\(')
ident_re=re.compile(r'(?<!\.)\b([A-Za-z_]\w*)\b')

def strip_line(line):
    # remove // comments and quoted strings, retaining spacing
    out=[]; i=0; quote=None
    while i<len(line):
        c=line[i]
        if quote:
            if c=='\\':
                out.extend('  '); i+=2; continue
            if c==quote:
                quote=None
            out.append(' '); i+=1; continue
        if c in ('"',"'"):
            quote=c; out.append(' '); i+=1; continue
        if c=='/' and i+1<len(line) and line[i+1]=='/':
            out.extend(' '*(len(line)-i)); break
        out.append(c); i+=1
    return ''.join(out)

def collect_functions(lines):
    funcs=[]
    i=0
    while i<len(lines):
        if lines[i] and not lines[i][0].isspace():
            # support multiline signature: top-level line starts identifier( and eventually =>
            m=func_start_re.match(lines[i])
            if m and m.group(1) not in {'indicator','strategy','library'}:
                j=i
                sig=[]
                while j<len(lines) and j-i<50:
                    if j > i and lines[j].strip() and not lines[j][0].isspace():
                        break
                    sig.append(lines[j])
                    if '=>' in strip_line(lines[j]): break
                    j+=1
                if j<len(lines) and '=>' in strip_line(lines[j]):
                    name=m.group(1)
                    # body until next nonblank top-level line
                    k=j+1
                    while k<len(lines):
                        l=lines[k]
                        if l.strip() and not l[0].isspace(): break
                        k+=1
                    funcs.append((name,i,j,k,sig,lines[j+1:k]))
                    i=k; continue
        i+=1
    return funcs

def globals_before(lines, end):
    names=set()
    for idx,line in enumerate(lines[:end]):
        if not line.strip() or line[0].isspace(): continue
        s=strip_line(line).strip()
        if '=>' in s or s.startswith(('type ','method ','indicator(','strategy(','library(')): continue
        # tuple declarations/assignments
        mt=re.match(r'^\[([^\]]+)\]\s*(?::=|=)',s)
        if mt:
            for part in mt.group(1).split(','):
                n=part.strip()
                if re.fullmatch(r'[A-Za-z_]\w*',n) and n!='_': names.add(n)
        # declarations with optional const/var/type
        md=re.match(r'^(?:(?:const|var|varip)\s+)?(?:(?:bool|int|float|string|color|line|label|box|table|array<[^>]+>|[A-Z]\w*)\s+)?([A-Za-z_]\w*)\s*(?::=|=)',s)
        if md: names.add(md.group(1))
    return names

def params_from_sig(sig):
    s=' '.join(strip_line(x) for x in sig)
    inside=s[s.find('(')+1:s.rfind(')')]
    params=set()
    # split commas not nested (types array<> no commas typically)
    for part in inside.split(','):
        tokens=re.findall(r'[A-Za-z_]\w*',part)
        if tokens:
            # last identifier is param name (ignoring default expression, but no defaults here)
            before_eq=part.split('=')[0]
            toks=re.findall(r'[A-Za-z_]\w*',before_eq)
            if toks: params.add(toks[-1])
    return params

def locals_from_body(body):
    names=set()
    for line in body:
        s=strip_line(line).strip()
        mt=re.match(r'^\[([^\]]+)\]\s*(?::=|=)',s)
        if mt:
            for part in mt.group(1).split(','):
                n=part.strip()
                if re.fullmatch(r'[A-Za-z_]\w*',n) and n!='_': names.add(n)
        md=re.match(r'^(?:(?:const|var|varip)\s+)?(?:(?:bool|int|float|string|color|line|label|box|table|array<[^>]+>|[A-Z]\w*)\s+)([A-Za-z_]\w*)\s*(?::=|=)',s)
        if md: names.add(md.group(1))
        # assignments can introduce inferred locals in functions
        ma=re.match(r'^([A-Za-z_]\w*)\s*(?::=|=)',s)
        if ma: names.add(ma.group(1))
        mf=re.match(r'^for\s+([A-Za-z_]\w*)\s*=|^for\s+\[([^\]]+)\]\s+in',s)
        if mf:
            if mf.group(1): names.add(mf.group(1))
            if mf.group(2):
                for n in mf.group(2).split(','): names.add(n.strip())
    return names

def audit(path):
    text=Path(path).read_text(encoding='utf-8')
    lines=text.splitlines()
    funcs=collect_functions(lines)
    all_funcs={f[0] for f in funcs}
    issues=[]
    for name,start,sigend,end,sig,body in funcs:
        allowed=IGNORE|all_funcs|globals_before(lines,start)|params_from_sig(sig)|locals_from_body(body)|{name}
        for off,line in enumerate(body,sigend+2):
            s=strip_line(line)
            for m in ident_re.finditer(s):
                ident=m.group(1)
                if ident in allowed: continue
                # Ignore named arguments (xloc = ...), enum/member after namespace handled by negative lookbehind.
                tail=s[m.end():]
                if re.match(r'\s*=',tail) and not re.match(r'\s*==',tail): continue
                # Ignore field/type constructors that are capitalized
                if ident[0].isupper(): continue
                issues.append({'function':name,'line':off,'identifier':ident,'source':line.strip()})
    # de-duplicate exact occurrences
    uniq=[]; seen=set()
    for x in issues:
        key=(x['function'],x['line'],x['identifier'])
        if key not in seen: seen.add(key); uniq.append(x)
    return {'file':str(path),'function_count':len(funcs),'issues':uniq}

if __name__=='__main__':
    results=[audit(p) for p in sys.argv[1:]]
    print(json.dumps(results,ensure_ascii=False,indent=2))
