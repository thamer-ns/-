# تقرير فاحص الرجوع SC

الملفات المفحوصة: **4** — النتائج: **12**

| حرج | عالٍ | متوسط | منخفض |
|---:|---:|---:|---:|
| 0 | 9 | 3 | 0 |

| الشدة | المعرّف | الملف:السطر | النتيجة |
|---|---|---|---|
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_SC-FXM-V17.7.txt:1009` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_SC-FXM-V17.7.txt:1010` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_SC-FXM-V17.7.txt:1011` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اللحظي_SC-V93.7-I.txt:939` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اللحظي_SC-V93.7-I.txt:940` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اللحظي_SC-V93.7-I.txt:941` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اليومي_SC-V93.7-D.txt:901` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اليومي_SC-V93.7-D.txt:902` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اليومي_SC-V93.7-D.txt:903` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| medium | `PINE-SIZE-RISK` | `بوصلة_التحليل_SC-FXM-V17.7.txt:1` | ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل |
| medium | `PINE-SIZE-RISK` | `بوصلة_التحليل_اللحظي_SC-V93.7-I.txt:1` | ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل |
| medium | `PINE-SIZE-RISK` | `بوصلة_التحليل_اليومي_SC-V93.7-D.txt:1` | ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل |

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_SC-FXM-V17.7.txt:1009`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe1, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_SC-FXM-V17.7.txt:1010`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe2, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_SC-FXM-V17.7.txt:1011`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe3, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.7-I.txt:939`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe1, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.7-I.txt:940`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe2, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.7-I.txt:941`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe3, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اليومي_SC-V93.7-D.txt:901`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe1, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اليومي_SC-V93.7-D.txt:902`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe2, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اليومي_SC-V93.7-D.txt:903`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe3, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-SIZE-RISK — ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل

- الملف: `بوصلة_التحليل_SC-FXM-V17.7.txt:1`
- الدليل: `lines=3861`
- الإصلاح: قلّل التكرار واختبر IL tokens داخل Pine Editor.

## PINE-SIZE-RISK — ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.7-I.txt:1`
- الدليل: `lines=3570`
- الإصلاح: قلّل التكرار واختبر IL tokens داخل Pine Editor.

## PINE-SIZE-RISK — ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل

- الملف: `بوصلة_التحليل_اليومي_SC-V93.7-D.txt:1`
- الدليل: `lines=3755`
- الإصلاح: قلّل التكرار واختبر IL tokens داخل Pine Editor.

## حدود الفاحص

هذا فحص ساكن لأنماط معروفة، وليس مترجم Pine ولا اختبار بيانات سوق. النجاح لا يثبت خلو الكود من كل خطأ مستقبلي.
