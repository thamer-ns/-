# تقرير فاحص الرجوع SC

الملفات المفحوصة: **4** — النتائج: **12**

| حرج | عالٍ | متوسط | منخفض |
|---:|---:|---:|---:|
| 0 | 9 | 3 | 0 |

| الشدة | المعرّف | الملف:السطر | النتيجة |
|---|---|---|---|
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_SC-FXM-V17.3.txt:1000` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_SC-FXM-V17.3.txt:1001` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_SC-FXM-V17.3.txt:1002` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اللحظي_SC-V93.3-I.txt:951` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اللحظي_SC-V93.3-I.txt:952` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اللحظي_SC-V93.3-I.txt:953` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اليومي_SC-V93.3-D.txt:889` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اليومي_SC-V93.3-D.txt:890` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اليومي_SC-V93.3-D.txt:891` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| medium | `PINE-SIZE-RISK` | `بوصلة_التحليل_SC-FXM-V17.3.txt:1` | ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل |
| medium | `PINE-SIZE-RISK` | `بوصلة_التحليل_اللحظي_SC-V93.3-I.txt:1` | ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل |
| medium | `PINE-SIZE-RISK` | `بوصلة_التحليل_اليومي_SC-V93.3-D.txt:1` | ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل |

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_SC-FXM-V17.3.txt:1000`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe1, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_SC-FXM-V17.3.txt:1001`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe2, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_SC-FXM-V17.3.txt:1002`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe3, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.3-I.txt:951`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe1, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.3-I.txt:952`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe2, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.3-I.txt:953`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe3, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اليومي_SC-V93.3-D.txt:889`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe1, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اليومي_SC-V93.3-D.txt:890`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe2, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اليومي_SC-V93.3-D.txt:891`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe3, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-SIZE-RISK — ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل

- الملف: `بوصلة_التحليل_SC-FXM-V17.3.txt:1`
- الدليل: `lines=3786`
- الإصلاح: قلّل التكرار واختبر IL tokens داخل Pine Editor.

## PINE-SIZE-RISK — ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.3-I.txt:1`
- الدليل: `lines=3589`
- الإصلاح: قلّل التكرار واختبر IL tokens داخل Pine Editor.

## PINE-SIZE-RISK — ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل

- الملف: `بوصلة_التحليل_اليومي_SC-V93.3-D.txt:1`
- الدليل: `lines=3705`
- الإصلاح: قلّل التكرار واختبر IL tokens داخل Pine Editor.

## حدود الفاحص

هذا فحص ساكن لأنماط معروفة، وليس مترجم Pine ولا اختبار بيانات سوق. النجاح لا يثبت خلو الكود من كل خطأ مستقبلي.
