نسخة لحظية بدون تنبيهات. تم تقسيم الحسابات وهندسة الخطة والعرض إلى دوال لمعالجة خطأ TradingView: The main body of the script is too long.
