from __future__ import annotations

import asyncio
import math
from dataclasses import replace
from datetime import datetime
from typing import Any

from .audited_engine import (
    AuditedMarketAnalyzer as BaseAuditedMarketAnalyzer,
    _reference_levels,
    _setup_event_audited,
    analyze_frame_audited,
)
from .market_data import FRAMES, ScanReport
from .risk_engine_v41 import build_adaptive_plan, estimate_remaining_duration
from .technical import (
    Candle,
    FrameAnalysis,
    LiveAnalysis,
    MarketDataError,
    _atr,
    _round,
    normalize_symbol,
)
from .universes import UNIVERSE_LABELS


_TERMINAL_MARKERS = ("منتهية", "مكتملة", "غير محسوم")


def opportunity_state_rank(frame: FrameAnalysis) -> int:
    """Ranks entry usability ahead of already-extended tracking plans."""
    state = frame.plan_state
    if "إعادة اختبار عميقة" in state:
        return 48
    if "إعادة اختبار" in state:
        return 72
    if "دخول قائم" in state:
        return 70
    if "فرصة مشروطة" in state:
        if frame.entry is None or frame.atr <= 0:
            return 54
        distance_atr = abs(frame.entry - frame.price) / frame.atr
        return max(48, 64 - min(16, round(distance_atr * 4)))
    if "الخطة قائمة — الدخول الجديد متأخر" in state:
        return 46
    if "فرصة قائمة" in state:
        return 52
    if "الخطة قائمة" in state:
        return 50
    if frame.entry is not None and frame.stop is not None and frame.targets:
        return 30
    if any(marker in state for marker in _TERMINAL_MARKERS):
        return 5
    return 10 if frame.direction else 0


def select_primary_frame(item: LiveAnalysis) -> FrameAnalysis:
    """Selects the most actionable frame, then confidence, then higher timeframe."""
    timeframe_weight = {"يومي": 3, "ساعة": 2, "15 دقيقة": 1}
    return max(
        item.frames,
        key=lambda frame: (
            opportunity_state_rank(frame),
            frame.confidence,
            timeframe_weight.get(frame.frame, 0),
        ),
    )


def _lookback_bars(label: str) -> int:
    if label == "15 دقيقة":
        return 104
    if label == "ساعة":
        return 84
    return 45


def _minimum_history(label: str) -> int:
    return 35 if label == "يومي" else 60


def _plan_levels(candles: list[Candle], event_level: float) -> list[float]:
    """Builds plan anchors only from candles available at plan creation time."""
    price = candles[-1].close
    atr = max(_atr(candles), price * 0.0001)
    _, _, clustered = _reference_levels(candles, price, atr)
    recent = candles[-22:-1] or candles[:-1]
    values = [*clustered, event_level]
    if recent:
        values.extend((min(bar.low for bar in recent), max(bar.high for bar in recent)))
    return sorted({value for value in values if math.isfinite(value) and value > 0})


def _build_plan(
    *,
    candles: list[Candle],
    frame_name: str,
    direction: int,
    event_level: float,
    market: str = "",
) -> tuple[float, float, tuple[float, ...], float, tuple[str, ...]] | None:
    """Compatibility wrapper around the V4.1 timeframe-adaptive risk engine."""
    plan = build_adaptive_plan(
        candles=candles,
        frame_name=frame_name,
        direction=direction,
        event_level=event_level,
        market=market,
    )
    if not plan.valid or plan.entry is None or plan.stop is None:
        return None
    return (
        plan.entry,
        plan.stop,
        plan.targets,
        float(plan.first_rr or 0.0),
        plan.warnings,
    )


def _bar_hit_target(bar: Candle, direction: int, target: float) -> bool:
    return bar.high >= target if direction > 0 else bar.low <= target


def _bar_hit_stop(bar: Candle, direction: int, stop: float) -> bool:
    return bar.low <= stop if direction > 0 else bar.high >= stop


def _evaluate_progress(
    candles: list[Candle],
    event_index: int,
    direction: int,
    stop: float,
    targets: tuple[float, ...],
) -> tuple[str, int]:
    """Tracks a close-confirmed plan from the candle after the trigger candle."""
    reached = 0
    for bar in candles[event_index + 1 :]:
        stop_hit = _bar_hit_stop(bar, direction, stop)
        target_hit = reached < len(targets) and _bar_hit_target(
            bar, direction, targets[reached]
        )
        if stop_hit and target_hit:
            return "AMBIGUOUS", reached
        if stop_hit:
            return "STOPPED", reached
        while reached < len(targets) and _bar_hit_target(
            bar, direction, targets[reached]
        ):
            reached += 1
    if reached >= len(targets):
        return "COMPLETED", reached
    return "ACTIVE", reached


def _recent_events(
    candles: list[Candle],
    label: str,
    direction: int,
) -> list[tuple[int, str, float]]:
    start = max(_minimum_history(label) - 1, len(candles) - _lookback_bars(label))
    found: list[tuple[int, str, float]] = []
    for index in range(len(candles) - 1, start - 1, -1):
        subset = candles[: index + 1]
        if len(subset) < _minimum_history(label):
            continue
        atr = _atr(subset)
        if atr <= 0 or not math.isfinite(atr):
            continue
        support, resistance, _ = _reference_levels(subset, subset[-1].close, atr)
        event_direction, event_text, event_level = _setup_event_audited(
            subset, support, resistance, atr
        )
        if event_direction == -direction and event_level is not None:
            break
        if event_direction == direction and event_level is not None:
            found.append((index, event_text, event_level))
    return found


def _event_age_text(candles: list[Candle], index: int) -> str:
    bars = len(candles) - 1 - index
    if bars <= 0:
        return "على آخر شمعة مغلقة"
    if bars == 1:
        return "قبل شمعة واحدة"
    return f"قبل {bars} شموع"


def _active_state(
    *,
    price: float,
    direction: int,
    entry: float,
    event_level: float,
    atr: float,
    progress: int,
) -> str:
    if progress:
        return f"فرصة قائمة — تحقق الهدف {progress} من 3"
    signed_distance = direction * (price - entry)
    if signed_distance < 0:
        if direction * (price - event_level) < -0.35 * atr:
            return "إعادة اختبار عميقة — الخطة قائمة ما دام الوقف لم يُكسر"
        return "إعادة اختبار — السعر قرب منطقة الدخول والخطة قائمة"
    if signed_distance <= 1.25 * atr:
        return "دخول قائم — الزناد تحقق والسعر ضمن نطاق غير ممتد"
    return "الخطة قائمة — الدخول الجديد متأخر؛ انتظر إعادة اختبار"


def enrich_frame_opportunity(candles: list[Candle], frame: FrameAnalysis) -> FrameAnalysis:
    """Keeps recent valid opportunities alive and builds conditional plans pre-breakout."""
    if frame.direction == 0 or frame.confidence < 55:
        return frame
    if frame.frame == "يومي" and len(candles) < 60:
        return frame

    direction = frame.direction
    price = candles[-1].close
    current_atr = max(_atr(candles), price * 0.0001)
    terminal_notes: list[str] = []

    for event_index, event_text, event_level in _recent_events(
        candles, frame.frame, direction
    ):
        event_candles = candles[: event_index + 1]
        plan_anchor = event_level
        retest_entry = "إعادة اختبار" in event_text
        if retest_entry:
            event_close = event_candles[-1].close
            event_atr = max(_atr(event_candles), event_close * 0.0001)
            entry_buffer = max(event_atr * 0.06, event_close * 0.0006)
            plan_anchor = event_close - direction * entry_buffer
        plan = build_adaptive_plan(
            candles=event_candles,
            frame_name=frame.frame,
            direction=direction,
            event_level=plan_anchor,
            market=frame.market,
        )
        if not plan.valid or plan.entry is None or plan.stop is None:
            continue
        entry, stop, targets = plan.entry, plan.stop, plan.targets
        rr, plan_warnings = float(plan.first_rr or 0.0), plan.warnings
        progress_state, reached = _evaluate_progress(
            candles, event_index, direction, stop, targets
        )
        if progress_state == "STOPPED":
            terminal_notes.append("أحدث زناد سابق انتهى بكسر الوقف")
            continue
        if progress_state == "COMPLETED":
            terminal_notes.append("أحدث زناد سابق أكمل أهدافه")
            continue
        if progress_state == "AMBIGUOUS":
            terminal_notes.append("تعذر حسم ترتيب الهدف والوقف داخل شمعة واحدة")
            continue

        state = _active_state(
            price=price,
            direction=direction,
            entry=entry,
            event_level=event_level,
            atr=current_atr,
            progress=reached,
        )
        age = _event_age_text(candles, event_index)
        extra_reason = (
            "دخول إعادة الاختبار عند إغلاق شمعة التأكيد"
            if retest_entry
            else "دخول الكسر من مستوى الزناد المؤكد"
        )
        reasons = tuple(
            dict.fromkeys(
                (
                    *frame.reasons,
                    f"زناد الخطة: {event_text} {age}",
                    extra_reason,
                    f"تقدم الخطة: {reached}/3",
                )
            )
        )
        warnings = tuple(dict.fromkeys((*frame.warnings, *plan_warnings)))
        next_index = min(reached, len(targets) - 1)
        duration_low, duration_high, duration_samples, duration_success_rate, duration_method = estimate_remaining_duration(
            candles,
            frame_name=frame.frame,
            direction=direction,
            reference=price,
            stop=stop,
            target=targets[next_index],
            atr=current_atr,
        )
        return replace(
            frame,
            event=f"{event_text} — {age}",
            plan_state=state,
            entry=_round(entry, price),
            stop=_round(stop, price),
            targets=tuple(_round(value, price) for value in targets),
            risk_reward=rr,
            reasons=reasons,
            warnings=warnings,
            risk_atr=plan.risk_atr,
            target_atr=plan.target_atr,
            duration_low_bars=duration_low,
            duration_high_bars=duration_high,
            duration_samples=duration_samples,
            duration_success_rate=duration_success_rate,
            duration_method=duration_method,
            plan_profile=plan.profile,
        )

    event_level = frame.resistance if direction > 0 else frame.support
    plan = build_adaptive_plan(
        candles=candles,
        frame_name=frame.frame,
        direction=direction,
        event_level=event_level,
        market=frame.market,
    )
    if not plan.valid or plan.entry is None or plan.stop is None:
        extra = (plan.rejection_reason,) if plan.rejection_reason else ()
        return replace(
            frame,
            warnings=tuple(dict.fromkeys((*frame.warnings, *plan.warnings, *extra))),
        )
    entry, stop, targets = plan.entry, plan.stop, plan.targets
    rr, plan_warnings = float(plan.first_rr or 0.0), plan.warnings
    side = "فوق" if direction > 0 else "تحت"
    action = "اختراق المقاومة" if direction > 0 else "كسر الدعم"
    warnings = tuple(
        dict.fromkeys((*frame.warnings, *plan_warnings, *terminal_notes))
    )
    reasons = tuple(
        dict.fromkeys(
            (
                *frame.reasons,
                f"الخطة التالية مشروطة بـ {action} على إغلاق {frame.frame}",
                "تقدم الخطة: 0/3",
            )
        )
    )
    return replace(
        frame,
        event=f"تجهيز لـ {action}",
        plan_state=(
            f"فرصة مشروطة — انتظار إغلاق {frame.frame} "
            f"{side} {_round(entry, price):g}"
        ),
        entry=_round(entry, price),
        stop=_round(stop, price),
        targets=tuple(_round(value, price) for value in targets),
        risk_reward=rr,
        reasons=reasons,
        warnings=warnings,
        risk_atr=plan.risk_atr,
        target_atr=plan.target_atr,
        duration_low_bars=plan.duration_low_bars,
        duration_high_bars=plan.duration_high_bars,
        duration_samples=plan.duration_samples,
        duration_success_rate=plan.duration_success_rate,
        duration_method=plan.duration_method,
        plan_profile=plan.profile,
    )


class OpportunityMarketAnalyzer(BaseAuditedMarketAnalyzer):
    """V3.7 analyzer with persistent setups and conditional plans."""

    @staticmethod
    def _build_audited(
        symbol: str,
        frames: list[FrameAnalysis],
        metadata: dict[str, Any],
        feed_sources: list[str],
    ) -> LiveAnalysis:
        result = BaseAuditedMarketAnalyzer._build_audited(
            symbol, frames, metadata, feed_sources
        )
        daily = next((frame for frame in frames if frame.frame == "يومي"), None)
        hourly = next((frame for frame in frames if frame.frame == "ساعة"), None)
        strong_conflict = bool(
            daily
            and hourly
            and daily.direction
            and hourly.direction
            and daily.direction != hourly.direction
            and daily.confidence >= 60
            and hourly.confidence >= 60
        )

        visible_frames: list[FrameAnalysis] = []
        for frame in frames:
            state = frame.plan_state
            warnings = list(frame.warnings)
            if (
                daily
                and frame.frame != "يومي"
                and daily.direction
                and frame.direction == -daily.direction
                and daily.confidence >= 65
            ):
                if frame.entry is not None:
                    state = f"{state} — خطة فاصل مستقلة عكس اليومي"
                warnings.append("الخطة عكس اتجاه اليومي؛ لا تُدمج مع الخطة العامة")
            if strong_conflict:
                warnings.append("تعارض قوي بين اليومي والساعة؛ تُعرض الخطط منفصلة فقط")
            visible_frames.append(
                replace(
                    frame,
                    plan_state=state,
                    warnings=tuple(dict.fromkeys(warnings)),
                )
            )

        if strong_conflict:
            return replace(
                result,
                recommendation="تعارض فواصل — راجع كل خطة على فاصلها ولا توحّد الاتجاه",
                frames=tuple(visible_frames),
            )
        return replace(result, frames=tuple(visible_frames))

    async def analyze(self, symbol: str) -> LiveAnalysis:
        spec = normalize_symbol(symbol)
        fetched = await asyncio.gather(
            *(self._fetch(symbol, key) for key in ("1d", "1h", "15m")),
            return_exceptions=True,
        )
        frames: list[FrameAnalysis] = []
        metadata_by_frame: list[tuple[datetime, dict[str, Any]]] = []
        feed_sources: list[str] = []
        errors: list[str] = []
        for key, item in zip(("1d", "1h", "15m"), fetched):
            if isinstance(item, Exception):
                errors.append(str(item))
                continue
            candles, metadata, provider_id = item
            frame = analyze_frame_audited(candles, FRAMES[key][2], spec.asset_class)
            frame = enrich_frame_opportunity(candles, frame)
            frames.append(frame)
            metadata_by_frame.append((frame.updated_at, metadata))
            feed_sources.append(provider_id)
        if not frames:
            raise MarketDataError(errors[0] if errors else "لم تتوفر بيانات كافية لهذا الرمز")
        latest_metadata = max(metadata_by_frame, key=lambda item: item[0])[1]
        return self._build_audited(symbol, frames, latest_metadata, feed_sources)

    async def analyze_one(self, symbol: str, frame_key: str) -> LiveAnalysis:
        if frame_key not in FRAMES:
            raise MarketDataError("الفاصل المطلوب غير مدعوم")
        spec = normalize_symbol(symbol)
        candles, metadata, provider_id = await self._fetch(symbol, frame_key)
        frame = analyze_frame_audited(candles, FRAMES[frame_key][2], spec.asset_class)
        frame = enrich_frame_opportunity(candles, frame)
        return self._build_audited(symbol, [frame], metadata, [provider_id])

    async def scan_market_detailed(
        self,
        market: str,
        horizon: str,
        direction: int,
        min_score: int,
        limit: int = 10,
    ) -> ScanReport:
        normalized = market.upper()
        frame_key = "1h" if horizon in {"INTRADAY", "SWING"} else "1d"
        all_items, total, analyzed = await self._scan_all(normalized, frame_key)
        items = list(all_items)
        if direction > 0:
            items = [item for item in items if item.direction > 0]
        elif direction < 0:
            items = [item for item in items if item.direction < 0]
        else:
            items = [item for item in items if item.direction != 0]
        items = [item for item in items if item.confidence >= min_score]
        items.sort(
            key=lambda item: (
                opportunity_state_rank(select_primary_frame(item)),
                item.confidence,
                abs(item.score - 50),
            ),
            reverse=True,
        )
        return ScanReport(
            market=normalized,
            horizon=horizon,
            universe_label=UNIVERSE_LABELS.get(normalized, normalized),
            total_symbols=total,
            analyzed_symbols=analyzed,
            failed_symbols=max(0, total - analyzed),
            direction=direction,
            items=tuple(items[:limit]),
        )
