from __future__ import annotations

import asyncio
import json
import logging
import os
import secrets
from contextlib import asynccontextmanager
from typing import Any

from fastapi import BackgroundTasks, FastAPI, HTTPException, Request

from .audited_models import AuditedTradingViewAlert
from .audited_runtime import ReliableTelegramClient
from .config import Settings
from .data_sources import SOURCE_CATALOG
from .database_v39 import VerifiedDatabase
from .focused_bot import LiveBotService
from .school_engine_v38 import FRAME_ORDER
from .universes import SAUDI_MAIN_MARKET, US_FOCUS_UNIVERSE

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)

VERSION = "4.1.1"
MAX_WEBHOOK_BYTES = 65_536
settings = Settings.from_env()
database = VerifiedDatabase(settings.database_path)
telegram = ReliableTelegramClient(
    settings.telegram_bot_token or "not-configured"
)
service = LiveBotService(settings, database, telegram)


def _feed_status() -> dict[str, Any]:
    """Configuration status only; live availability is tested per request."""

    return {
        "status_basis": "configuration_only_not_live_probe",
        "binance_public_endpoint_configured": bool(
            os.getenv("BINANCE_API_BASE", "https://api.binance.com").strip()
        ),
        "webull_configured": bool(
            os.getenv("WEBULL_APP_KEY")
            and os.getenv("WEBULL_APP_SECRET")
        ),
        "barchart_configured": bool(os.getenv("BARCHART_API_KEY")),
        "yahoo_fallback_configured": True,
    }


async def _read_json_limited(request: Request) -> Any:
    content_length = request.headers.get("content-length")
    if content_length:
        try:
            if int(content_length) > MAX_WEBHOOK_BYTES:
                raise HTTPException(
                    status_code=413, detail="payload too large"
                )
        except ValueError as exc:
            raise HTTPException(
                status_code=400, detail="invalid content length"
            ) from exc
    raw = await request.body()
    if len(raw) > MAX_WEBHOOK_BYTES:
        raise HTTPException(
            status_code=413, detail="payload too large"
        )
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise HTTPException(
            status_code=400, detail="invalid json"
        ) from exc


async def _process_telegram_inbox_once() -> int:
    rows = await database.pending_telegram_updates(limit=10)
    for row in rows:
        update_id = int(row["update_id"])
        try:
            await service.handle_update(row["payload"])
        except Exception as exc:
            attempts = int(row["attempts"]) + 1
            await database.mark_telegram_update_failed(
                update_id, attempts, repr(exc)
            )
            logger.exception(
                "Telegram update %s failed; queued for retry", update_id
            )
        else:
            await database.mark_telegram_update_done(update_id)
    return len(rows)


async def _run_telegram_inbox() -> None:
    while True:
        processed = await _process_telegram_inbox_once()
        await asyncio.sleep(0.5 if processed else 2.0)


async def _safe_drain_outbox_once() -> None:
    try:
        await service.drain_outbox_once()
    except Exception:
        logger.exception("Immediate Telegram outbox drain failed")


@asynccontextmanager
async def lifespan(_: FastAPI):
    settings.validate_runtime()
    await database.initialize()
    logger.info("Database ready at %s", settings.database_path)
    logger.info("Market data providers: %s", _feed_status())
    if settings.auto_configure_telegram_webhook:
        try:
            await service.configure_telegram()
        except Exception:
            logger.exception(
                "Automatic Telegram webhook configuration failed"
            )
            raise
    outbox_task = asyncio.create_task(
        service.run_outbox(), name="telegram-outbox"
    )
    inbox_task = asyncio.create_task(
        _run_telegram_inbox(), name="telegram-inbox"
    )
    try:
        yield
    finally:
        outbox_task.cancel()
        inbox_task.cancel()
        for task in (outbox_task, inbox_task):
            try:
                await task
            except asyncio.CancelledError:
                pass
        await telegram.close()


app = FastAPI(
    title=settings.app_name,
    version=VERSION,
    lifespan=lifespan,
)


def _analysis_contract() -> dict[str, Any]:
    return {
        "closed_candles_only": True,
        "exchange_session_aware": True,
        "multi_timeframe": True,
        "supported_frames": list(FRAME_ORDER),
        "school_consensus": True,
        "independent_schools": 9,
        "minimum_school_rule": (
            "two_independent_axes_or_one_strong_actionable"
        ),
        "independent_evidence_axes": True,
        "explicit_consensus_qualification": True,
        "scan_requires_valid_plan_geometry": True,
        "all_frame_presets": True,
        "pre_trigger_breakout_levels": True,
        "safe_telegram_html": True,
        "beginner_friendly_presentation": True,
        "paginated_multi_frame_analysis": True,
        "full_plan_in_scan_results": True,
        "full_plan_in_preset_results": True,
        "clear_call_put_underlying_labels": True,
        "monotonic_opportunity_states": True,
        "strict_target_count": True,
        "risk_geometry": True,
        "timeframe_adaptive_risk": True,
        "market_tick_aware_levels": True,
        "empirical_first_passage_duration": True,
        "durable_telegram_inbox": True,
        "persistent_opportunity_memory": True,
        "conditional_entry_plans": True,
        "target_progress_tracking": True,
        "saudi_main_market_symbols": len(SAUDI_MAIN_MARKET),
        "us_focused_symbols": len(US_FOCUS_UNIVERSE),
        "us_options_same_focused_universe": True,
    }


@app.get("/")
async def root() -> dict[str, Any]:
    return {
        "name": settings.app_name,
        "mode": "telegram-clear-opportunity-analysis",
        "version": VERSION,
        "status": "ok",
        "analysis": _analysis_contract(),
        "feeds": _feed_status(),
    }


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "version": VERSION,
        "analysis": "adaptive-risk-audited-opportunity-live",
        "school_consensus": "enabled",
        "explicit_consensus_qualification": "enabled",
        "scan_plan_validation": "enabled",
        "all_frame_presets": "enabled",
        "beginner_friendly_presentation": "enabled",
        "paginated_multi_frame_analysis": "enabled",
        "full_plan_in_scan_results": "enabled",
        "monotonic_opportunity_states": "enabled",
        "strict_target_count": "enabled",
        "independent_schools": 9,
        "supported_frames": list(FRAME_ORDER),
        "feed_mode": "multi-source-with-fallback",
        "feeds": _feed_status(),
        "opportunity_memory": "enabled",
        "conditional_plans": "enabled",
        "target_progress": "enabled",
        "saudi_scan": "main-market-wide",
        "us_stock_scan": "verified-focused-51-symbol-list",
        "us_options_scan": (
            "same-focused-list-cboe-validated-when-available"
        ),
        "tradingview": "optional",
        "source_catalog": [
            item.source_id for item in SOURCE_CATALOG
        ],
    }


@app.get("/sources")
async def sources() -> dict[str, Any]:
    return {
        "feed_mode": "multi-source-with-fallback",
        "configured": _feed_status(),
        "priority": {
            "crypto": ["binance", "yahoo"],
            "us_stocks": ["webull", "barchart", "yahoo"],
            "other_markets": ["yahoo"],
        },
        "sources": [
            {
                "id": item.source_id,
                "name": item.name,
                "role": item.role,
                "coverage": item.coverage,
                "note": item.note,
            }
            for item in SOURCE_CATALOG
        ],
    }


@app.get("/status")
async def status() -> dict[str, Any]:
    return {
        "status": "ok",
        "version": VERSION,
        "live_analysis": True,
        **_analysis_contract(),
        "feeds": _feed_status(),
        "tradingview_optional": bool(
            settings.tradingview_webhook_token
        ),
        "database": await database.health_snapshot(),
    }


@app.post("/webhooks/tradingview/{token}")
async def tradingview_webhook(
    token: str,
    request: Request,
    background_tasks: BackgroundTasks,
) -> dict[str, Any]:
    configured = settings.tradingview_webhook_token
    if not configured or not secrets.compare_digest(
        token, configured
    ):
        raise HTTPException(status_code=404, detail="not found")
    try:
        payload = AuditedTradingViewAlert.model_validate(
            await _read_json_limited(request)
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning("Rejected TradingView payload: %s", exc)
        raise HTTPException(
            status_code=422,
            detail="invalid TradingView payload",
        ) from exc

    event_id, created, market = await database.record_alert(
        payload
    )
    if created:
        chat_ids = await database.subscriber_chat_ids(
            settings.telegram_chat_ids
        )
        await database.enqueue_notifications(
            event_id, chat_ids
        )
        background_tasks.add_task(_safe_drain_outbox_once)
    return {
        "ok": True,
        "created": created,
        "event_id": event_id,
        "market": market,
    }


def _verify_telegram_header(request: Request) -> None:
    received = request.headers.get(
        "X-Telegram-Bot-Api-Secret-Token", ""
    )
    configured = settings.telegram_header_secret
    if not configured or not secrets.compare_digest(received, configured):
        raise HTTPException(
            status_code=403, detail="invalid Telegram secret"
        )


async def _queue_telegram_request(request: Request) -> dict[str, bool]:
    _verify_telegram_header(request)
    update = await _read_json_limited(request)
    if not isinstance(update, dict):
        raise HTTPException(
            status_code=422, detail="invalid Telegram update"
        )
    try:
        update_id = int(update["update_id"])
    except (KeyError, TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=422, detail="invalid Telegram update_id"
        ) from exc
    if update_id < 0:
        raise HTTPException(
            status_code=422, detail="invalid Telegram update_id"
        )
    await database.enqueue_telegram_update(update_id, update)
    return {"ok": True}


@app.post("/webhooks/telegram")
async def telegram_webhook(request: Request) -> dict[str, bool]:
    """Primary endpoint: fixed path plus Telegram's secret header."""
    return await _queue_telegram_request(request)


@app.post("/webhooks/telegram/{token}")
async def telegram_webhook_legacy(
    token: str, request: Request
) -> dict[str, bool]:
    """Temporary compatibility route for an older configured webhook."""
    if not secrets.compare_digest(token, settings.telegram_webhook_token):
        raise HTTPException(status_code=404, detail="not found")
    return await _queue_telegram_request(request)
