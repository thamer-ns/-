from __future__ import annotations

import secrets
from typing import Any

from .bot_logic import BotService


class FeedbackBotService(BotService):
    """Adds explicit onboarding feedback for unauthorized Telegram users."""

    async def handle_update(self, update: dict[str, Any]) -> None:
        if "callback_query" in update:
            await super().handle_update(update)
            return

        message = update.get("message") or update.get("edited_message")
        if not message:
            return

        chat_id = int(message["chat"]["id"])
        user_id = int(message.get("from", {}).get("id", 0))
        text = str(message.get("text", "")).strip()

        if await self._is_authorized(user_id, chat_id):
            await super().handle_update(update)
            return

        command, _, code = text.partition(" ")
        command = command.split("@", 1)[0].lower()
        claim_available = not await self.db.has_any_admin()

        if command != "/claim":
            await self.telegram.send_message(
                chat_id,
                "🔐 <b>البوت غير مربوط بهذا الحساب بعد.</b>\n\n"
                "أرسل <code>/claim</code> ثم مسافة ثم قيمة "
                "<code>TELEGRAM_BOOTSTRAP_CODE</code> كاملة.",
            )
            return

        if not claim_available:
            await self.telegram.send_message(
                chat_id,
                "⚠️ <b>تم ربط مدير للبوت مسبقًا.</b>\n\n"
                "استخدم الحساب الذي نفّذ الربط أول مرة، أو امسح قاعدة البيانات "
                "إذا كان الربط السابق تجريبيًا.",
            )
            return

        if not code.strip():
            await self.telegram.send_message(
                chat_id,
                "أرسل رمز الربط كاملًا بعد الأمر، مثال:\n"
                "<code>/claim YOUR_FULL_BOOTSTRAP_CODE</code>",
            )
            return

        configured_code = self.settings.telegram_bootstrap_code
        if not configured_code:
            await self.telegram.send_message(
                chat_id,
                "❌ رمز الربط غير مضبوط على الخادم. أضف "
                "<code>TELEGRAM_BOOTSTRAP_CODE</code> في Render ثم أعد النشر.",
            )
            return

        if not secrets.compare_digest(code.strip(), configured_code):
            await self.telegram.send_message(
                chat_id,
                "❌ <b>رمز الربط غير صحيح.</b>\n\n"
                "انسخ قيمة <code>TELEGRAM_BOOTSTRAP_CODE</code> كاملة من Render، "
                "من دون نقاط (…) أو مسافات إضافية.",
            )
            return

        # The original handler performs the actual registration and welcome response.
        await super().handle_update(update)
