from __future__ import annotations

import asyncio
import html
import logging
import os
import time
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from typing import Any, Iterable

from .data_sources import CandleProvider, YahooChartProvider
from .technical import FrameAnalysis, LiveAnalysis, MarketDataError, analyze_frame, normalize_symbol
from .universes import UNIVERSE_LABELS, UniverseCatalog

logger = logging.getLogger(__name__)


FRAMES = {
    "15m": ("30d", "15m", "15 دقيقة", 15 * 60),
    "1h": ("60d", "1h", "ساعة", 60 * 60),
    "1d": ("2y", "1d", "يومي", 24 * 60 * 60),
}


@dataclass(frozen=True, slots=True)
class ScanReport:
    market: str
    horizon: str
    universe_label: str
    total_symbols: int
    analyzed_symbols: int
    failed_symbols: int
    direction: int
    items: tuple[LiveAnalysis, ...]


class LiveMarketAnalyzer:
    def __init__(
        self,
        timeout: float | None = None,
        cache_seconds: int | None = None,
        providers: list[CandleProvider] | None = None,
    ) -> None:
        self.timeout = timeout or float(os.getenv("MARKET_DATA_TIMEOUT", "12"))
        self.cache_seconds = cache_seconds or int(os.getenv("MARKET_DATA_CACHE_SECONDS", "120"))
        self.providers = providers or [YahooChartProvider(timeout=self.timeout)]
        self.universes = UniverseCatalog(timeout=self.timeout)
        self.scan_concurrency = max(2, min(12, int(os.getenv("MARKET_SCAN_CONCURRENCY", "8"))))
        self.scan_cache_seconds = max(60, int(os.getenv("MARKET_SCAN_CACHE_SECONDS", "300")))
        self.scan_timeout_seconds = max(
            30.0, float(os.getenv("MARKET_SCAN_TIMEOUT_SECONDS", "180"))
        )
        self.max_cache_entries = max(
            100, int(os.getenv("MARKET_DATA_MAX_CACHE_ENTRIES", "1200"))
        )
        self.max_scan_cache_entries = max(
            10, int(os.getenv("MARKET_SCAN_MAX_CACHE_ENTRIES", "80"))
        )
        self._cache: dict[tuple[str, str], tuple[float, list[Any], dict[str, Any], str]] = {}
        self._locks: dict[tuple[str, str], asyncio.Lock] = {}
        self._scan_cache: dict[tuple[str, str], tuple[float, tuple[LiveAnalysis, ...], int]] = {}
        self._scan_locks: dict[tuple[str, str], asyncio.Lock] = {}

    def _prune_data_cache(self) -> None:
        if len(self._cache) <= self.max_cache_entries:
            return
        remove_count = len(self._cache) - self.max_cache_entries
        oldest = sorted(self._cache, key=lambda key: self._cache[key][0])[:remove_count]
        for key in oldest:
            self._cache.pop(key, None)
            lock = self._locks.get(key)
            if lock is not None and not lock.locked():
                self._locks.pop(key, None)

    def _prune_scan_cache(self) -> None:
        if len(self._scan_cache) <= self.max_scan_cache_entries:
            return
        remove_count = len(self._scan_cache) - self.max_scan_cache_entries
        oldest = sorted(
            self._scan_cache, key=lambda key: self._scan_cache[key][0]
        )[:remove_count]
        for key in oldest:
            self._scan_cache.pop(key, None)
            lock = self._scan_locks.get(key)
            if lock is not None and not lock.locked():
                self._scan_locks.pop(key, None)

    @staticmethod
    def _remove_incomplete(
        candles: list[Any], interval_seconds: int, metadata: dict[str, Any]
    ) -> list[Any]:
        if len(candles) < 2:
            return candles
        now = int(time.time())
        last = candles[-1]
        should_drop = False
        if interval_seconds < 24 * 60 * 60:
            should_drop = now < last.timestamp + interval_seconds + 90
        else:
            regular = ((metadata.get("currentTradingPeriod") or {}).get("regular") or {})
            regular_end = int(regular.get("end") or 0)
            if regular_end and now < regular_end:
                last_day = datetime.fromtimestamp(last.timestamp, tz=timezone.utc).date()
                now_day = datetime.fromtimestamp(now, tz=timezone.utc).date()
                should_drop = last_day == now_day
        return candles[:-1] if should_drop and len(candles) > 1 else candles

    async def _fetch(
        self, symbol: str, frame_key: str
    ) -> tuple[list[Any], dict[str, Any], str]:
        spec = normalize_symbol(symbol)
        period, interval, _, interval_seconds = FRAMES[frame_key]
        key = (spec.yahoo_symbol, frame_key)
        cached = self._cache.get(key)
        now_mono = time.monotonic()
        ttl = self.cache_seconds if frame_key != "1d" else max(self.cache_seconds, 600)
        if cached and now_mono - cached[0] <= ttl:
            return cached[1], cached[2], cached[3]
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            cached = self._cache.get(key)
            now_mono = time.monotonic()
            if cached and now_mono - cached[0] <= ttl:
                return cached[1], cached[2], cached[3]
            errors: list[str] = []
            for provider in self.providers:
                try:
                    result = await provider.fetch(spec, period, interval)
                    closed = self._remove_incomplete(
                        result.candles, interval_seconds, result.metadata
                    )
                    if len(closed) < 60:
                        raise MarketDataError(
                            "وصلت بيانات قليلة بعد استبعاد الشمعة غير المكتملة"
                        )
                    self._cache[key] = (
                        time.monotonic(),
                        closed,
                        result.metadata,
                        result.provider_id,
                    )
                    self._prune_data_cache()
                    return closed, result.metadata, result.provider_id
                except MarketDataError as exc:
                    errors.append(
                        f"{getattr(provider, 'provider_id', 'provider')}: {exc}"
                    )
            raise MarketDataError(" | ".join(errors) or "لم يعمل أي مصدر بيانات")

    @staticmethod
    def _build(
        symbol: str,
        frames: list[FrameAnalysis],
        metadata: dict[str, Any],
        feed_source: str,
    ) -> LiveAnalysis:
        spec = normalize_symbol(symbol)
        weights = {"يومي": 0.50, "ساعة": 0.35, "15 دقيقة": 0.15}
        total_weight = sum(weights.get(frame.frame, 0.0) for frame in frames)
        score = round(
            sum(frame.score * weights.get(frame.frame, 0.0) for frame in frames)
            / max(total_weight, 0.01)
        )
        confidence = round(
            sum(frame.confidence * weights.get(frame.frame, 0.0) for frame in frames)
            / max(total_weight, 0.01)
        )
        daily = next((frame for frame in frames if frame.frame == "يومي"), None)
        hourly = next((frame for frame in frames if frame.frame == "ساعة"), None)
        strong_conflict = bool(
            daily
            and hourly
            and daily.direction
            and hourly.direction
            and daily.direction != hourly.direction
            and daily.confidence >= 60
            and hourly.confidence >= 60
        )
        if strong_conflict:
            alignment = "تعارض قوي بين اليومي والساعة"
            direction = 0
            confidence = max(0, confidence - 15)
        else:
            nonzero = [frame.direction for frame in frames if frame.direction]
            if nonzero and all(value == nonzero[0] for value in nonzero):
                alignment = "توافق الفواصل"
            elif nonzero:
                alignment = "توافق جزئي/مرحلة انتقال"
            else:
                alignment = "الفواصل محايدة"
            direction = 1 if score >= 59 else -1 if score <= 41 else 0
        adjusted: list[FrameAnalysis] = []
        for frame in frames:
            if (
                daily
                and frame.frame != "يومي"
                and daily.direction
                and frame.direction == -daily.direction
                and daily.confidence >= 65
            ):
                adjusted.append(
                    replace(
                        frame,
                        plan_state="مراقبة — الفاصل اليومي يعارض الخطة",
                        entry=None,
                        stop=None,
                        targets=(),
                        risk_reward=None,
                        warnings=tuple(
                            dict.fromkeys((*frame.warnings, "تعارض مع الفاصل اليومي"))
                        ),
                    )
                )
            else:
                adjusted.append(frame)
        if strong_conflict:
            recommendation = "محايد — يمنع فتح خطة جديدة حتى ينخفض تعارض الفواصل"
        elif direction > 0 and confidence >= 70:
            recommendation = "إيجابي قوي — اعتمد فقط الخطة ذات الزناد المؤكد"
        elif direction > 0:
            recommendation = "إيجابي — مراقبة وتأكيد"
        elif direction < 0 and confidence >= 70:
            recommendation = "سلبي قوي — راقب كسرًا مؤكدًا"
        elif direction < 0:
            recommendation = "سلبي — مراقبة وتأكيد"
        else:
            recommendation = "محايد/انتقالي — الانتظار أفضل"
        primary = next((frame for frame in adjusted if frame.frame == "يومي"), adjusted[0])
        return LiveAnalysis(
            query=spec.query,
            yahoo_symbol=spec.yahoo_symbol,
            display_symbol=spec.display_symbol,
            name=str(
                metadata.get("longName")
                or metadata.get("shortName")
                or spec.display_symbol
            ),
            exchange=str(
                metadata.get("exchangeName")
                or metadata.get("fullExchangeName")
                or "غير محدد"
            ),
            currency=str(metadata.get("currency") or ""),
            asset_class=spec.asset_class,
            price=primary.price,
            score=score,
            confidence=confidence,
            recommendation=recommendation,
            direction=direction,
            alignment=alignment,
            feed_source=feed_source,
            frames=tuple(adjusted),
            updated_at=max(frame.updated_at for frame in adjusted),
        )

    async def analyze(self, symbol: str) -> LiveAnalysis:
        spec = normalize_symbol(symbol)
        fetched = await asyncio.gather(
            *(self._fetch(symbol, key) for key in ("1d", "1h", "15m")),
            return_exceptions=True,
        )
        frames: list[FrameAnalysis] = []
        metadata: dict[str, Any] = {}
        feed_source = "unknown"
        errors: list[str] = []
        for key, item in zip(("1d", "1h", "15m"), fetched):
            if isinstance(item, Exception):
                errors.append(str(item))
                continue
            candles, meta, provider_id = item
            metadata = metadata or meta
            feed_source = provider_id
            frames.append(analyze_frame(candles, FRAMES[key][2], spec.asset_class))
        if not frames:
            raise MarketDataError(
                errors[0] if errors else "لم تتوفر بيانات كافية لهذا الرمز"
            )
        return self._build(symbol, frames, metadata, feed_source)

    async def analyze_one(self, symbol: str, frame_key: str) -> LiveAnalysis:
        spec = normalize_symbol(symbol)
        candles, metadata, provider_id = await self._fetch(symbol, frame_key)
        frame = analyze_frame(candles, FRAMES[frame_key][2], spec.asset_class)
        return self._build(symbol, [frame], metadata, provider_id)

    async def _scan_all(
        self, market: str, frame_key: str
    ) -> tuple[tuple[LiveAnalysis, ...], int, int]:
        cache_key = (market, frame_key)
        now = time.monotonic()
        cached = self._scan_cache.get(cache_key)
        if cached and now - cached[0] <= self.scan_cache_seconds:
            return cached[1], cached[2], len(cached[1])
        lock = self._scan_locks.setdefault(cache_key, asyncio.Lock())
        async with lock:
            cached = self._scan_cache.get(cache_key)
            now = time.monotonic()
            if cached and now - cached[0] <= self.scan_cache_seconds:
                return cached[1], cached[2], len(cached[1])
            symbols = await self.universes.symbols(market)
            semaphore = asyncio.Semaphore(self.scan_concurrency)

            async def worker(symbol: str) -> LiveAnalysis | None:
                async with semaphore:
                    try:
                        return await self.analyze_one(symbol, frame_key)
                    except (MarketDataError, ValueError):
                        return None

            tasks = [
                asyncio.create_task(worker(symbol)) for symbol in symbols
            ]
            done, pending = await asyncio.wait(
                tasks, timeout=self.scan_timeout_seconds
            )
            for task in pending:
                task.cancel()
            if pending:
                await asyncio.gather(*pending, return_exceptions=True)
                logger.warning(
                    "Market scan timed out for %s/%s: %s of %s symbols unfinished",
                    market,
                    frame_key,
                    len(pending),
                    len(symbols),
                )
            results: list[LiveAnalysis | None] = []
            for task in done:
                try:
                    results.append(task.result())
                except Exception:
                    logger.exception(
                        "Unexpected scan worker failure for %s/%s",
                        market,
                        frame_key,
                    )
            successful = tuple(item for item in results if item is not None)
            # A partial timed-out result is useful to display but must not
            # poison the scan cache as if the entire universe completed.
            if not pending:
                self._scan_cache[cache_key] = (
                    time.monotonic(), successful, len(symbols)
                )
                self._prune_scan_cache()
            return successful, len(symbols), len(successful)

    async def scan_market_detailed(
        self,
        market: str,
        horizon: str,
        direction: int,
        min_score: int,
        limit: int = 10,
    ) -> ScanReport:
        normalized = market.upper()
        frame_key = "1h" if horizon in {"INTRADAY", "SWING"} else "1d"
        all_items, total, analyzed = await self._scan_all(normalized, frame_key)
        items = list(all_items)
        if direction > 0:
            items = [item for item in items if item.direction > 0]
        elif direction < 0:
            items = [item for item in items if item.direction < 0]
        else:
            items = [item for item in items if item.direction != 0]
        items = [item for item in items if item.confidence >= min_score]
        items.sort(
            key=lambda item: (
                item.confidence,
                abs(item.score - 50),
                item.alignment == "توافق الفواصل",
            ),
            reverse=True,
        )
        return ScanReport(
            market=normalized,
            horizon=horizon,
            universe_label=UNIVERSE_LABELS.get(normalized, normalized),
            total_symbols=total,
            analyzed_symbols=analyzed,
            failed_symbols=max(0, total - analyzed),
            direction=direction,
            items=tuple(items[:limit]),
        )

    async def scan_market(
        self,
        market: str,
        horizon: str,
        direction: int,
        min_score: int,
        limit: int = 8,
    ) -> list[LiveAnalysis]:
        report = await self.scan_market_detailed(
            market, horizon, direction, min_score, limit
        )
        return list(report.items)


def _price(value: float | None) -> str:
    if value is None:
        return "—"
    return f"{value:.5f}".rstrip("0").rstrip(".")


def format_analysis(item: LiveAnalysis) -> str:
    icon = "🟢" if item.direction > 0 else "🔴" if item.direction < 0 else "🟡"
    lines = [
        f"📊 <b>تحليل مباشر — {html.escape(item.display_symbol)}</b>",
        f"<b>{html.escape(item.name)}</b>",
        "",
        f"السعر المرجعي: <b>{_price(item.price)} {html.escape(item.currency)}</b>",
        f"النتيجة: {icon} <b>{html.escape(item.recommendation)}</b>",
        f"درجة الاتجاه: <b>{item.score}/100</b> | قوة التوافق: <b>{item.confidence}/100</b>",
        f"توافق الفواصل: <b>{html.escape(item.alignment)}</b>",
        "",
    ]
    for frame in item.frames:
        frame_icon = "🟢" if frame.direction > 0 else "🔴" if frame.direction < 0 else "🟡"
        lines += [
            f"<b>{frame_icon} فاصل {frame.frame}</b>",
            f"الاتجاه: {frame.trend} | شراء {frame.evidence_long}% | بيع {frame.evidence_short}%",
            f"البنية: {html.escape(frame.structure)}",
            f"الحدث: {html.escape(frame.event)}",
            f"RSI: {frame.rsi:.1f} | ATR: {_price(frame.atr)} ({frame.atr_percent:.2f}%)",
            f"EMA20: {_price(frame.ema20)} | EMA50: {_price(frame.ema50)}"
            + (f" | EMA200: {_price(frame.ema200)}" if frame.ema200 is not None else ""),
            f"الدعم: {_price(frame.support)} | المقاومة: {_price(frame.resistance)}",
        ]
        if frame.volume_ratio is not None:
            lines.append(f"الحجم/وسيطه: {frame.volume_ratio:.2f}×")
        elif not frame.volume_trusted:
            lines.append("الحجم: غير معتمد لهذا النوع من السوق")
        lines.append(f"حالة الخطة: <b>{html.escape(frame.plan_state)}</b>")
        if frame.entry is not None and frame.stop is not None:
            lines += [
                f"الدخول بعد التأكيد: {_price(frame.entry)}",
                f"الوقف البنيوي: {_price(frame.stop)}",
                "الأهداف: " + " • ".join(_price(value) for value in frame.targets),
            ]
            if frame.risk_reward is not None:
                lines.append(f"عائد الهدف الأول: {frame.risk_reward:.2f}R")
        if frame.reasons:
            lines.append(
                "الأدلة: " + "، ".join(html.escape(value) for value in frame.reasons[:4])
            )
        if frame.warnings:
            lines.append(
                "⚠️ " + "، ".join(html.escape(value) for value in frame.warnings[:3])
            )
        lines.append("")
    updated = item.updated_at.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    lines += [
        f"مصدر الشموع: <b>{html.escape(item.feed_source)}</b>",
        f"آخر شمعة مغلقة: <code>{updated}</code>",
        "<i>لا تُبنى خطة على شمعة غير مكتملة. البيانات المجانية قد تتأخر، والتحليل تعليمي وليس أمر تنفيذ.</i>",
    ]
    return "\n".join(lines)


def format_scan(report: ScanReport) -> str:
    names = {
        "SAUDI": "أفضل فرص السوق السعودي",
        "US": "أفضل فرص السوق الأمريكي",
        "US_OPTIONS": "فرص الأوبشن الأمريكي CALL / PUT",
        "FOREX": "أفضل فرص العملات",
        "CRYPTO": "أفضل فرص العملات الرقمية",
    }
    frame_name = "ساعة" if report.horizon in {"INTRADAY", "SWING"} else "يومي"
    direction_name = (
        "صاعدة فقط" if report.direction > 0 else "هابطة فقط" if report.direction < 0 else "صاعدة وهابطة"
    )
    lines = [
        f"🔎 <b>{names.get(report.market, report.market)}</b>",
        f"النطاق: <b>{html.escape(report.universe_label)}</b>",
        f"الفاصل: <b>{frame_name}</b> | الاتجاه: <b>{direction_name}</b>",
        f"تم تحليل: <b>{report.analyzed_symbols}/{report.total_symbols}</b>",
        "",
    ]
    if not report.items:
        lines += [
            "لم تظهر فرصة مطابقة للاتجاه وحد القوة حاليًا.",
            "خفّض حد القوة أو جرّب الفاصل الآخر؛ عدم ظهور نتيجة أفضل من فرض صفقة ضعيفة.",
        ]
    for index, item in enumerate(report.items, 1):
        icon = "🟢" if item.direction > 0 else "🔴" if item.direction < 0 else "🟡"
        option_side = ""
        if report.market == "US_OPTIONS":
            option_side = " CALL" if item.direction > 0 else " PUT"
        lines.append(
            f"{index}. {icon}<b>{option_side} {html.escape(item.display_symbol)}</b>"
            f" — قوة {item.confidence}/100 — {_price(item.price)}"
            f" — {html.escape(item.alignment)}"
        )
    if report.failed_symbols:
        lines += ["", f"تعذر جلب {report.failed_symbols} رمزًا من المصدر في هذه الجولة."]
    if report.market == "US_OPTIONS":
        lines += [
            "",
            "<i>CALL/PUT هنا اتجاه فني للأصل الأساسي ضمن كون أوبشن سائل ومؤهل؛ لا يختار عقدًا ولا يقيس السبريد أو Greeks.</i>",
        ]
    else:
        lines += ["", "<i>النتائج مرتبة فنيًا من آخر شمعة مغلقة.</i>"]
    return "\n".join(lines)
