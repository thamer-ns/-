from __future__ import annotations

import html
import math
import re
from datetime import timezone

from .market_data import ScanReport
from .opportunity_v37 import opportunity_state_rank
from .school_engine_v38 import FRAME_SPECS
from .school_engine_v39 import is_executable_opportunity
from .technical import FrameAnalysis, LiveAnalysis


FRAME_PRIORITY = {
    "1 دقيقة": 1,
    "5 دقائق": 2,
    "15 دقيقة": 3,
    "30 دقيقة": 4,
    "ساعة": 5,
    "4 ساعات": 6,
    "يومي": 7,
    "أسبوعي": 8,
    "شهري": 9,
}


def _price(value: float | None) -> str:
    if value is None:
        return "—"
    return f"{value:.5f}".rstrip("0").rstrip(".")


def _progress(frame: FrameAnalysis) -> int:
    for reason in frame.reasons:
        match = re.search(r"تقدم الخطة:\s*(\d+)/3", reason)
        if match:
            return max(0, min(3, int(match.group(1))))
    match = re.search(r"تحقق الهدف\s+(\d)", frame.plan_state)
    return int(match.group(1)) if match else 0


def _duration(frame: FrameAnalysis) -> str:
    if frame.entry is None or not frame.targets or frame.atr <= 0:
        return "لا تتوفر مدة قبل اكتمال الخطة"
    progress = _progress(frame)
    target = frame.targets[min(progress, len(frame.targets) - 1)]
    reference = (
        frame.entry if "مشروطة" in frame.plan_state else frame.price
    )
    distance = abs(target - reference)
    bars_low = max(1, math.ceil(distance / frame.atr * 1.5))
    bars_high = max(
        bars_low + 1, math.ceil(distance / frame.atr * 4.5)
    )
    if frame.frame == "1 دقيقة":
        return f"نحو {max(5, bars_low)}–{max(10, bars_high)} دقيقة تداول"
    if frame.frame == "5 دقائق":
        return f"نحو {bars_low * 5}–{bars_high * 5} دقيقة تداول"
    if frame.frame == "15 دقيقة":
        return f"نحو {max(1, math.ceil(bars_low / 26))}–{max(1, math.ceil(bars_high / 26))} جلسات"
    if frame.frame == "30 دقيقة":
        return f"نحو {max(1, math.ceil(bars_low / 13))}–{max(1, math.ceil(bars_high / 13))} جلسات"
    if frame.frame == "ساعة":
        return f"نحو {max(1, math.ceil(bars_low / 6))}–{max(1, math.ceil(bars_high / 6))} جلسات"
    if frame.frame == "4 ساعات":
        return f"نحو {max(1, math.ceil(bars_low / 2))}–{max(1, math.ceil(bars_high / 2))} جلسات تداول"
    if frame.frame == "يومي":
        return f"نحو {max(1, math.ceil(bars_low / 5))}–{max(1, math.ceil(bars_high / 5))} أسابيع"
    if frame.frame == "أسبوعي":
        return f"نحو {bars_low}–{bars_high} أسابيع"
    return f"نحو {bars_low}–{bars_high} أشهر"


def _entry_zone(frame: FrameAnalysis) -> tuple[float, float] | None:
    if frame.entry is None:
        return None
    width = max(frame.atr * 0.15, frame.entry * 0.0008)
    if frame.direction > 0:
        return frame.entry, frame.entry + width
    return frame.entry - width, frame.entry


def _qualified(frame: FrameAnalysis) -> bool:
    return bool(getattr(frame, "consensus_qualified", False))


def _plan_valid(frame: FrameAnalysis) -> bool:
    return bool(getattr(frame, "plan_valid", False))


def select_primary_frame_v39(item: LiveAnalysis) -> FrameAnalysis:
    return max(
        item.frames,
        key=lambda frame: (
            _qualified(frame),
            _plan_valid(frame),
            opportunity_state_rank(frame),
            getattr(frame, "school_count", 0),
            getattr(frame, "consensus_strength", 0),
            frame.confidence,
            FRAME_PRIORITY.get(frame.frame, 0),
        ),
    )


def _direction_text(direction: int) -> str:
    return (
        "صعود" if direction > 0 else "هبوط" if direction < 0 else "مراقبة"
    )


def _state_icon(frame: FrameAnalysis) -> str:
    if not _qualified(frame):
        return "🟡"
    if not _plan_valid(frame):
        return "🧭"
    if "إعادة اختبار" in frame.plan_state:
        return "🔄"
    if "مشروطة" in frame.plan_state:
        return "⏳"
    if "دخول قائم" in frame.plan_state or "فرصة" in frame.plan_state:
        return "🚀"
    return "🟢" if frame.direction > 0 else "🔴"


def _school_lines(frame: FrameAnalysis) -> list[str]:
    names = tuple(getattr(frame, "school_names", ()))
    details = tuple(getattr(frame, "school_details", ()))
    opposing = tuple(getattr(frame, "opposing_school_names", ()))
    if not _qualified(frame):
        lines = [
            "<b>الحالة:</b> لم يكتمل شرط الفرصة؛ القراءة للمراقبة فقط.",
            f"<b>الإشارات المرصودة:</b> {len(names)}"
            + (
                " — " + html.escape(" + ".join(names))
                if names
                else ""
            ),
        ]
        if opposing:
            lines.append(
                "<b>مدارس معاكسة:</b> "
                + html.escape(" + ".join(opposing))
            )
        return lines + [
            f"• {html.escape(detail)}" for detail in details[:4]
        ]
    strong_single = bool(
        getattr(frame, "strong_single_school", False)
    )
    headline = (
        f"<b>مدرسة واحدة قوية:</b> {html.escape(names[0])}"
        if strong_single and names
        else f"<b>عدد المدارس المتوافقة:</b> {len(names)} — {html.escape(' + '.join(names))}"
    )
    lines = [headline]
    if opposing:
        lines.append(
            "<b>تنبيه:</b> توجد قراءة معاكسة من "
            + html.escape(" + ".join(opposing))
        )
    return lines + [f"• {html.escape(detail)}" for detail in details[:5]]


def _frame_line(frame: FrameAnalysis) -> str:
    names = tuple(getattr(frame, "school_names", ()))
    if _qualified(frame) and _plan_valid(frame):
        status = "فرصة تنفيذ"
    elif _qualified(frame):
        status = "رأي مؤهل بلا خطة"
    else:
        status = "مراقبة"
    plan = (
        f" | دخول {_price(frame.entry)}"
        if _plan_valid(frame) and frame.entry is not None
        else ""
    )
    schools = " + ".join(names[:2]) if names else "لا توافق كافٍ"
    return (
        f"• {_state_icon(frame)} <b>{html.escape(frame.frame)}</b>: "
        f"{status} | {_direction_text(frame.direction)} | قوة {frame.confidence}/100 "
        f"| مدارس {len(names)} ({html.escape(schools)}){plan}"
    )


def _compact(item: LiveAnalysis, frame: FrameAnalysis) -> str:
    names = tuple(getattr(frame, "school_names", ()))
    lines = [
        f"📊 <b>{html.escape(item.display_symbol)} — {html.escape(item.name)}</b>",
        f"السعر: <b>{_price(item.price)} {html.escape(item.currency)}</b>",
        f"{_state_icon(frame)} <b>{html.escape(frame.plan_state)}</b>",
        f"الفاصل: <b>{html.escape(frame.frame)}</b> | الاتجاه: {_direction_text(frame.direction)} | قوة التوافق: {frame.confidence}/100",
        f"المدارس: <b>{len(names)}</b> — {html.escape(' + '.join(names) if names else 'لا توافق كافٍ')}",
    ]
    if is_executable_opportunity(frame):
        lines += [
            f"الدخول: <b>{_price(frame.entry)}</b> | الوقف: <b>{_price(frame.stop)}</b>",
            "الأهداف: "
            + " • ".join(_price(target) for target in frame.targets),
            f"المدة: {_duration(frame)}",
        ]
    return "\n".join(lines)


def format_analysis_v39(item: LiveAnalysis) -> str:
    primary = select_primary_frame_v39(item)
    signal_type = str(
        getattr(primary, "signal_type", "") or primary.event
    )
    qualified = _qualified(primary)
    valid_plan = is_executable_opportunity(primary)
    lines = [
        f"📊 <b>{html.escape(item.display_symbol)} — {html.escape(item.name)}</b>",
        f"السعر الحالي: <b>{_price(item.price)} {html.escape(item.currency)}</b>",
        "",
        "<b>الخلاصة التنفيذية</b>",
        f"{_state_icon(primary)} <b>{html.escape(primary.plan_state)}</b>",
        f"الرأي: <b>{_direction_text(primary.direction)}</b> | النوع: <b>{html.escape(signal_type)}</b>",
        f"الفاصل الأنسب: <b>{html.escape(primary.frame)}</b> | قوة التوافق: <b>{primary.confidence}/100</b>",
        f"توافق الفواصل: <b>{html.escape(item.alignment)}</b>",
        "",
        "<b>🧠 المدارس والأسباب</b>",
        *_school_lines(primary),
        "",
    ]

    if valid_plan:
        progress = _progress(primary)
        follow_up = progress > 0
        extended = "الدخول الجديد متأخر" in primary.plan_state
        lines.append(
            "<b>🎯 خطة المتابعة</b>"
            if follow_up
            else "<b>🎯 خطة الفرصة</b>"
        )
        if follow_up:
            next_index = min(progress, len(primary.targets) - 1)
            lines.append(
                f"الهدف التالي: <b>{_price(primary.targets[next_index])}</b>"
            )
            lines.append(
                "لا تُعامل الخطة كدخول جديد بعد تحقق هدف؛ راقب الوقف والهدف التالي."
            )
        elif extended:
            lines.append(
                "الخطة قائمة لكن السعر ممتد؛ لا تطارد الحركة وانتظر إعادة اختبار."
            )
        elif "مشروطة" in primary.plan_state:
            side = "فوق" if primary.direction > 0 else "تحت"
            lines.append(
                f"شرط التفعيل: إغلاق شمعة {html.escape(primary.frame)} {side} <b>{_price(primary.entry)}</b>"
            )
            zone = _entry_zone(primary)
            if zone:
                lines.append(
                    f"نطاق التنفيذ بعد التفعيل: <code>{_price(zone[0])} - {_price(zone[1])}</code>"
                )
        else:
            zone = _entry_zone(primary)
            lines.append(
                f"الدخول المرجعي: <b>{_price(primary.entry)}</b>"
            )
            if zone:
                lines.append(
                    f"نطاق التنفيذ: <code>{_price(zone[0])} - {_price(zone[1])}</code>"
                )
        risk_pct = (
            abs(primary.entry - primary.stop)
            / max(primary.entry, 1e-9)
            * 100
        )
        lines.append(
            f"وقف الإلغاء: <b>{_price(primary.stop)}</b> (مخاطرة سعرية {risk_pct:.2f}%)"
        )
        for index, target in enumerate(primary.targets, 1):
            marker = "✅" if index <= progress else "🎯"
            lines.append(
                f"{marker} الهدف {index}: <b>{_price(target)}</b>"
            )
        lines += [
            f"⏱ المدة الاحتمالية: <b>{html.escape(_duration(primary))}</b>",
            "",
        ]
    elif qualified:
        lines += [
            "<b>🎯 قرار التنفيذ</b>",
            "الرأي الفني مؤهل، لكن لا توجد حاليًا منطقة دخول ووقف وأهداف اجتازت هندسة المخاطر؛ لا تُفتح صفقة من هذه القراءة وحدها.",
            f"الدعم: <b>{_price(primary.support)}</b> | المقاومة: <b>{_price(primary.resistance)}</b>",
            "",
        ]
    else:
        lines += [
            "<b>🎯 قرار التنفيذ</b>",
            "لا توجد فرصة مكتملة على الفاصل المختار؛ لا دخول قبل اكتمال شرط المدارس وهندسة المخاطر.",
            f"الدعم: <b>{_price(primary.support)}</b> | المقاومة: <b>{_price(primary.resistance)}</b>",
            "",
        ]

    lines += ["<b>🧭 تحليل الفواصل من دقيقة إلى شهر</b>"]
    lines.extend(_frame_line(frame) for frame in item.frames)
    warnings = list(dict.fromkeys(primary.warnings))[:5]
    if warnings:
        lines += [
            "",
            "<b>⚠️ ملاحظات المخاطر</b>",
            *(f"• {html.escape(value)}" for value in warnings),
        ]
    updated = item.updated_at.astimezone(timezone.utc).strftime(
        "%Y-%m-%d %H:%M UTC"
    )
    lines += [
        "",
        f"مصدر الشموع: <b>{html.escape(item.feed_source)}</b> | آخر إغلاق: <code>{updated}</code>",
        "<i>المسح لا يعرض فرصة إلا بعد قبول المدارس وصحة الدخول والوقف والأهداف. التحليل احتمالي، والوقف إلغاء للفكرة.</i>",
    ]
    message = "\n".join(lines)
    return message if len(message) <= 4096 else _compact(item, primary)


def format_scan_v39(report: ScanReport) -> str:
    frame_label = (
        FRAME_SPECS[report.horizon].label
        if report.horizon in FRAME_SPECS
        else report.horizon
    )
    title = {
        "SAUDI": "السوق السعودي",
        "US": "السوق الأمريكي",
        "US_OPTIONS": "الأوبشن الأمريكي حسب الأصل",
        "FOREX": "العملات",
        "CRYPTO": "العملات الرقمية",
    }.get(report.market, report.market)
    header = [
        f"🔎 <b>فرص مؤكدة بتوافق المدارس — {html.escape(title)}</b>",
        f"الفاصل: <b>{html.escape(frame_label)}</b> | تم تحليل {report.analyzed_symbols}/{report.total_symbols}",
        "",
    ]
    if not report.items:
        return "\n".join(
            header
            + [
                "لا توجد الآن فرصة اجتازت معًا: قبول المدارس، اتجاه الفاصل، وهندسة الدخول والوقف والأهداف.",
                "<i>عدم ظهور نتيجة أفضل من تخفيف شروط المخاطر أو عرض قراءة غير قابلة للتنفيذ كفرصة.</i>",
            ]
        )

    item_blocks: list[list[str]] = []
    for index, item in enumerate(report.items[:10], 1):
        frame = item.frames[0]
        names = tuple(getattr(frame, "school_names", ()))
        item_blocks.append(
            [
                f"{index}. {'🟢' if frame.direction > 0 else '🔴'} <b>{html.escape(item.display_symbol)}</b> — {_direction_text(frame.direction)} | {html.escape(getattr(frame, 'signal_type', '') or frame.event)} | قوة {frame.confidence}/100",
                f"   مدارس {len(names)}: {html.escape(' + '.join(names[:4]))}",
                f"   دخول {_price(frame.entry)} | وقف {_price(frame.stop)} | T1 {_price(frame.targets[0])}",
            ]
        )
    footer = [
        "",
        "<i>افتح الرمز لرؤية جميع المدارس، الأهداف الثلاثة، المدة، وتوافق بقية الفواصل.</i>",
    ]
    lines = list(header)
    for block in item_blocks:
        candidate = "\n".join(lines + block + footer)
        if len(candidate) > 4096:
            break
        lines.extend(block)
    lines.extend(footer)
    return "\n".join(lines)
