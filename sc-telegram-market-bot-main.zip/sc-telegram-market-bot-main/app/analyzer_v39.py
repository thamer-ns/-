from __future__ import annotations

from .data_sources_v39 import (
    V39DirectProvider,
    V39MultiSourceProvider,
)
from .school_engine_v39 import VerifiedSchoolConsensusAnalyzer


class ProductionVerifiedAnalyzer(VerifiedSchoolConsensusAnalyzer):
    """Verified analyzer with V3.9 source coverage and fallback routing."""

    def __init__(
        self,
        timeout: float | None = None,
        cache_seconds: int | None = None,
    ) -> None:
        super().__init__(
            timeout=timeout,
            cache_seconds=cache_seconds,
        )
        self.providers = [V39MultiSourceProvider(self.timeout)]
        # The inherited lower-frame path calls this compatibility attribute.
        # V3.9 routes crypto 1m/5m/30m to Binance and all other fallback
        # requests to Yahoo.
        self._v38_yahoo = V39DirectProvider(self.timeout)


__all__ = ["ProductionVerifiedAnalyzer"]
