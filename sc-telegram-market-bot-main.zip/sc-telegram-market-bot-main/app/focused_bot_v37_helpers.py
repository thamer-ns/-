from __future__ import annotations

import os
from typing import Any

from .data_sources import SOURCE_CATALOG, reference_links
from .technical import normalize_symbol
from .universes import US_FOCUS_UNIVERSE

FRAME_ALIASES: dict[str, str | None] = {
    "15m": "15m", "15": "15m", "15د": "15m", "15دقيقة": "15m", "ربع": "15m",
    "1h": "1h", "60": "1h", "ساعة": "1h", "الساعة": "1h", "ساعي": "1h",
    "1d": "1d", "d": "1d", "daily": "1d", "يومي": "1d", "اليومي": "1d", "يوم": "1d",
    "all": None, "كل": None, "جميع": None,
}
FRAME_CALLBACK: dict[str, str | None] = {"A": None, "M": "15m", "H": "1h", "D": "1d"}

FOCUSED_HELP_TEXT = """<b>بوصلة الأسواق V3.7 — فرص مرتبة لا تختفي بعد الزناد</b>

<b>التحليل:</b> دخول قائم، إعادة اختبار، أو دخول مشروط مع الوقف والأهداف والمدة التقديرية.
<b>ذاكرة الفرصة:</b> يبقى الكسر الحديث ظاهرًا ما دام الوقف لم يُكسر ولم تكتمل الأهداف.

أمثلة:
<code>/analyze 2222</code> — جميع الفواصل
<code>/analyze 2222 1h</code> — الساعة
<code>/analyze AAPL 1d</code> — اليومي

/analyze SYMBOL [15m|1h|1d] — تحليل وخطة مرتبة
/filters — الفلاتر الفنية
/recommendations — أفضل الفرص السعودية
/options — اتجاهات CALL وPUT
/active — خطط TradingView القائمة
/uslist — الأسهم الأمريكية الـ51
/sources — مصادر البيانات
/status — حالة النظام
/help — المساعدة

<i>المدة تقديرية وليست ضمانًا، ولا ينفذ البوت صفقات.</i>"""


def build_main_menu(base_menu: dict[str, Any]) -> dict[str, Any]:
    rows = list(base_menu["inline_keyboard"])
    rows.insert(-1, [
        {"text": "📂 الخطط النشطة", "callback_data": "menu:active"},
        {"text": "📋 الأسهم الأمريكية الـ51", "callback_data": "menu:uslist"},
    ])
    return {"inline_keyboard": rows}


def build_analysis_buttons(symbol: str) -> dict[str, Any]:
    spec = normalize_symbol(symbol)
    ticker = spec.display_symbol
    rows: list[list[dict[str, str]]] = [
        [{"text": "🔄 كل الفواصل", "callback_data": f"a:{ticker}:A"}],
        [
            {"text": "15د", "callback_data": f"a:{ticker}:M"},
            {"text": "ساعة", "callback_data": f"a:{ticker}:H"},
            {"text": "يومي", "callback_data": f"a:{ticker}:D"},
        ],
    ]
    links = reference_links(spec)
    for index in range(0, len(links), 2):
        rows.append([{"text": f"↗️ {name}", "url": url} for name, url in links[index:index + 2]])
    rows.append([{"text": "🏠 الرئيسية", "callback_data": "menu:home"}])
    return {"inline_keyboard": rows}


def build_active_buttons(items: list[Any]) -> dict[str, Any]:
    rows = [[{
        "text": f"📊 {item.ticker} · {item.timeframe}",
        "callback_data": f"detail:{item.event_id}",
    }] for item in items[:10]]
    rows.append([{"text": "🏠 الرئيسية", "callback_data": "menu:home"}])
    return {"inline_keyboard": rows}


def provider_status_text() -> str:
    webull = "🟢 مُهيأ — يُثبت عند أول طلب" if os.getenv("WEBULL_APP_KEY") and os.getenv("WEBULL_APP_SECRET") else "⚪ غير مُهيأ"
    barchart = "🟢 مُهيأ — يُثبت عند أول طلب" if os.getenv("BARCHART_API_KEY") else "⚪ غير مُهيأ"
    return (
        "<b>Binance Spot:</b> ✅ مفعّل للرقمية\n"
        f"<b>Webull OpenAPI:</b> {webull}\n"
        f"<b>Barchart OnDemand:</b> {barchart}\n"
        "<b>Yahoo Finance:</b> ✅ احتياط"
    )


def sources_text() -> str:
    roles = {
        "feed": "مصدر آلي", "optional_feed": "مصدر آلي اختياري",
        "fallback_feed": "مصدر احتياطي", "reference": "مرجع خارجي",
        "reference_or_paid_api": "مرجع / API مدفوع",
    }
    configured = {
        "binance": "✅ يعمل دون مفتاح",
        "webull": "🟢 مُهيأ" if os.getenv("WEBULL_APP_KEY") and os.getenv("WEBULL_APP_SECRET") else "⚪ غير مُهيأ",
        "barchart": "🟢 مُهيأ" if os.getenv("BARCHART_API_KEY") else "⚪ غير مُهيأ",
        "yahoo": "✅ احتياط",
    }
    lines = ["🌐 <b>مصادر البيانات والتحقق — V3.7</b>", ""]
    for item in SOURCE_CATALOG:
        state = configured.get(item.source_id, "")
        lines.append(f"<b>{item.name}</b> — {roles.get(item.role, item.role)}" + (f" — {state}" if state else ""))
        lines.extend([item.note, ""])
    lines.append("<i>النجاح الفعلي للمصدر يظهر داخل نتيجة التحليل باسم مصدر الشموع.</i>")
    return "\n".join(lines)


def us_list_text() -> str:
    symbols = list(US_FOCUS_UNIVERSE)
    rows = [" • ".join(symbols[index:index + 6]) for index in range(0, len(symbols), 6)]
    return (
        "🇺🇸 <b>قائمة المسح الأمريكية المدققة</b>\n\n"
        + "\n".join(f"<code>{row}</code>" for row in rows)
        + f"\n\nالإجمالي: <b>{len(symbols)} سهمًا</b>."
        + "\n<i>/analyze يقبل أي رمز آخر يدويًا.</i>"
    )


def parse_symbol_frame(argument: str) -> tuple[str, str | None]:
    parts = [part for part in argument.strip().split() if part]
    if not parts:
        return "", None
    frame_key: str | None = None
    for token in parts[1:]:
        normalized = token.strip().lower()
        if normalized in FRAME_ALIASES:
            frame_key = FRAME_ALIASES[normalized]
    return parts[0].upper(), frame_key
