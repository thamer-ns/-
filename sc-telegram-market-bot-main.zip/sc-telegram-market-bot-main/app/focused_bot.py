from __future__ import annotations

from typing import Any

from .analyzer_v39 import ProductionVerifiedAnalyzer
from .focused_bot_v37_helpers import (
    provider_status_text,
    sources_text,
    us_list_text,
)
from .focused_bot_v40 import (
    FOCUSED_HELP_TEXT,
    LiveBotService as V40LiveBotService,
)
from .stored_presentation_v40 import active_plan_pages


class LiveBotService(V40LiveBotService):
    """Production V4.1 service with clear beginner-friendly results."""

    _provider_status_text = staticmethod(provider_status_text)
    _sources_text = staticmethod(sources_text)
    _us_list_text = staticmethod(us_list_text)

    @staticmethod
    def _main_menu() -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [
                    {"text": "📊 تحليل سهم أو رمز", "callback_data": "menu:analyze"},
                    {"text": "🔎 فرص مكتملة", "callback_data": "menu:scan"},
                ],
                [
                    {"text": "🟢 خطط شراء سعودية", "callback_data": "fpf:SAUDI:planup"},
                    {"text": "🔴 خطط هبوط سعودية", "callback_data": "fpf:SAUDI:plandn"},
                ],
                [
                    {"text": "🟢 فرص CALL", "callback_data": "quick:calls"},
                    {"text": "🔴 فرص PUT", "callback_data": "quick:puts"},
                ],
                [
                    {"text": "📂 خطط TradingView النشطة", "callback_data": "menu:active"},
                ],
                [
                    {"text": "🇸🇦 السوق السعودي", "callback_data": "market:SAUDI"},
                    {"text": "🇺🇸 السوق الأمريكي", "callback_data": "market:US"},
                ],
                [
                    {"text": "💱 العملات", "callback_data": "market:FOREX"},
                    {"text": "🪙 العملات الرقمية", "callback_data": "market:CRYPTO"},
                ],
                [
                    {"text": "🧰 جميع الفلاتر", "callback_data": "menu:filters"},
                    {"text": "🌐 مصادر البيانات", "callback_data": "menu:sources"},
                ],
                [
                    {"text": "🩺 حالة النظام", "callback_data": "system:status"},
                    {"text": "ℹ️ شرح الاستخدام", "callback_data": "menu:help"},
                ],
            ]
        }

    async def _send_active_plans(self, chat_id: int) -> None:
        items = await self.db.list_opportunities(
            market=None,
            horizon="ALL",
            direction=0,
            min_score=0,
            limit=20,
            active_only=True,
            fresh_only=False,
        )
        await self._send_pages(
            chat_id,
            active_plan_pages(items),
            self._active_buttons(items),
        )

    async def _handle_callback(self, callback: dict[str, Any]) -> None:
        callback_id = str(callback["id"])
        message = callback.get("message") or {}
        chat_id = int(message.get("chat", {}).get("id", 0))
        user_id = int(callback.get("from", {}).get("id", 0))
        data = str(callback.get("data", ""))
        if data == "menu:sources":
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "مصادر البيانات")
            await self.telegram.send_message(
                chat_id,
                sources_text().replace("V3.7", "V4.1").replace("V3.9", "V4.1").replace("V4.0", "V4.1"),
                self._main_menu(),
            )
            return
        await super()._handle_callback(callback)


AuditedMarketAnalyzer = ProductionVerifiedAnalyzer

__all__ = [
    "AuditedMarketAnalyzer",
    "FOCUSED_HELP_TEXT",
    "LiveBotService",
]
