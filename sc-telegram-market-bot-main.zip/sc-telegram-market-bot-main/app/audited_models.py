from __future__ import annotations

import math
import re
import time

from pydantic import field_validator, model_validator

from .models import AlertEvent, TradingViewAlert


class AuditedTradingViewAlert(TradingViewAlert):
    """Rejects impossible geometry and unsafe webhook values."""

    @field_validator("source", "timeframe")
    @classmethod
    def validate_short_text(cls, value: str) -> str:
        text = str(value).strip()
        if (
            not text
            or len(text) > 40
            or any(ord(char) < 32 or ord(char) == 127 for char in text)
        ):
            raise ValueError("invalid short text field")
        return text

    @field_validator("tickerid")
    @classmethod
    def validate_tickerid(cls, value: str) -> str:
        text = str(value).strip().upper()
        if re.fullmatch(r"[A-Z0-9.^=_:/-]{1,80}", text) is None:
            raise ValueError("invalid tickerid")
        return text

    @field_validator(
        "price", "entry", "stop", "target1", "target2", "target3"
    )
    @classmethod
    def validate_price(
        cls, value: float | None
    ) -> float | None:
        if value is None:
            return None
        numeric = float(value)
        if (
            not math.isfinite(numeric)
            or numeric <= 0
            or numeric > 1_000_000_000
        ):
            raise ValueError("invalid price")
        return numeric

    @field_validator("target_count", mode="before")
    @classmethod
    def validate_target_count_strict(cls, value: int) -> int:
        numeric = int(value)
        if numeric not in (1, 2, 3):
            raise ValueError("target_count must be between 1 and 3")
        return numeric

    @field_validator("event_time_ms")
    @classmethod
    def validate_event_time(
        cls, value: int | None
    ) -> int | None:
        if value is None:
            return None
        now_ms = int(time.time() * 1000)
        if value <= 0 or value > now_ms + 5 * 60_000:
            raise ValueError("invalid event time")
        return value

    @field_validator("score", "score_max")
    @classmethod
    def validate_scores(cls, value: int) -> int:
        numeric = int(value)
        if numeric < 0 or numeric > 100_000:
            raise ValueError("invalid score")
        return numeric

    @model_validator(mode="after")
    def validate_event_geometry(self) -> "AuditedTradingViewAlert":
        if self.score_max <= 0 or self.score > self.score_max:
            raise ValueError("invalid score geometry")
        if (
            self.event != AlertEvent.FAKEOUT
            and self.direction not in (-1, 1)
        ):
            raise ValueError(
                "direction is required for state-changing events"
            )
        if self.event not in {
            AlertEvent.NEW_LONG,
            AlertEvent.NEW_SHORT,
        }:
            return self

        required: list[float | None] = [
            self.entry,
            self.stop,
            self.target1,
        ]
        if self.target_count >= 2:
            required.append(self.target2)
        if self.target_count >= 3:
            required.append(self.target3)
        if any(value is None for value in required):
            raise ValueError(
                "new plan requires entry, stop and declared targets"
            )

        assert self.entry is not None
        assert self.stop is not None
        assert self.target1 is not None
        targets = [self.target1]
        if self.target_count >= 2 and self.target2 is not None:
            targets.append(self.target2)
        if self.target_count >= 3 and self.target3 is not None:
            targets.append(self.target3)

        if self.direction > 0:
            if not self.stop < self.entry:
                raise ValueError("long stop must be below entry")
            if not all(target > self.entry for target in targets):
                raise ValueError(
                    "long targets must be above entry"
                )
            if any(
                right <= left
                for left, right in zip(targets, targets[1:])
            ):
                raise ValueError(
                    "long targets must be strictly increasing"
                )
        else:
            if not self.stop > self.entry:
                raise ValueError("short stop must be above entry")
            if not all(target < self.entry for target in targets):
                raise ValueError(
                    "short targets must be below entry"
                )
            if any(
                right >= left
                for left, right in zip(targets, targets[1:])
            ):
                raise ValueError(
                    "short targets must be strictly decreasing"
                )
        return self
