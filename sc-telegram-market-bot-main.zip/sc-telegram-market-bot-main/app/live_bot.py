from __future__ import annotations

import html
from typing import Any

from .claim_feedback import FeedbackBotService
from .data_sources import reference_links, source_catalog_text
from .formatting import format_health, format_search_results, format_symbol_analysis
from .market_data import LiveMarketAnalyzer, format_analysis, format_scan
from .presets import (
    CATEGORIES,
    CATEGORY_BY_ID,
    PRESET_BY_ID,
    AdvancedPresetScanner,
    PresetReport,
    normalize_analysis,
    presets_for_category,
)
from .technical import MarketDataError, normalize_symbol


LIVE_HELP_TEXT = """<b>بوصلة الأسواق V3.4 — تحليل ومسح فني متقدم</b>

أرسل الرمز مباشرة:
<code>1120</code> أو <code>2222</code> للسعودي
<code>AAPL</code> أو <code>NVDA</code> للأمريكي
<code>EURUSD</code> للعملات
<code>BTCUSD</code> للعملات الرقمية

الأوامر:
/analyze SYMBOL — تحليل متعدد الفواصل
/filters — فلاتر فنية جاهزة محسوبة من الشموع المغلقة
/recommendations — أفضل الفرص الصاعدة في السوق السعودي
/options — اتجاهات CALL وPUT للأصول الأمريكية
/calls — أفضل فرص CALL
/puts — أفضل فرص PUT
/scan — اختيار السوق والفاصل والاتجاه
/sources — مصادر البيانات والتحقق
/status — حالة الخادم والبيانات
/help — المساعدة

الفلاتر المتقدمة تفرّق بين <b>ترتيب المتوسطات</b> و<b>التقاطع الحديث</b>، وتعرض سبب مطابقة كل رمز. لا ينفذ البوت أي صفقة."""


class LiveBotService(FeedbackBotService):
    def __init__(self, settings, database, telegram) -> None:
        super().__init__(settings, database, telegram)
        self.live = LiveMarketAnalyzer()
        self.scanner = AdvancedPresetScanner(self.live)

    @staticmethod
    def _main_menu() -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [
                    {"text": "🧰 فلاتر فنية متقدمة", "callback_data": "menu:filters"},
                    {"text": "📊 تحليل رمز", "callback_data": "menu:analyze"},
                ],
                [
                    {"text": "🇸🇦 أفضل فرص صاعدة", "callback_data": "quick:saudi_up"},
                    {"text": "🎯 خطط مؤكدة", "callback_data": "fc:SAUDI:plan"},
                ],
                [
                    {"text": "🟢 أوبشن CALL", "callback_data": "quick:calls"},
                    {"text": "🔴 أوبشن PUT", "callback_data": "quick:puts"},
                ],
                [
                    {"text": "🔎 مسح الأسواق", "callback_data": "menu:scan"},
                    {"text": "🌐 مصادر البيانات", "callback_data": "menu:sources"},
                ],
                [
                    {"text": "🇸🇦 السعودي", "callback_data": "market:SAUDI"},
                    {"text": "🇺🇸 الأمريكي", "callback_data": "market:US"},
                ],
                [
                    {"text": "💱 العملات", "callback_data": "market:FOREX"},
                    {"text": "🪙 العملات الرقمية", "callback_data": "market:CRYPTO"},
                ],
                [
                    {"text": "🩺 حالة النظام", "callback_data": "system:status"},
                    {"text": "ℹ️ المساعدة", "callback_data": "menu:help"},
                ],
            ]
        }

    @staticmethod
    def _market_menu() -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [
                    {"text": "🇸🇦 السعودي", "callback_data": "market:SAUDI"},
                    {"text": "🇺🇸 الأمريكي", "callback_data": "market:US"},
                ],
                [{"text": "🧩 أوبشن أمريكي", "callback_data": "options:US"}],
                [
                    {"text": "💱 العملات", "callback_data": "market:FOREX"},
                    {"text": "🪙 الرقمية", "callback_data": "market:CRYPTO"},
                ],
                [{"text": "⬅️ الرئيسية", "callback_data": "menu:home"}],
            ]
        }

    @staticmethod
    def _horizon_menu(market: str) -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [{"text": "⚡ ساعة", "callback_data": f"search:{market}:INTRADAY:0:55"}],
                [{"text": "🗓 يومي", "callback_data": f"search:{market}:DAILY:0:55"}],
                [{"text": "⬆️ صعود يومي", "callback_data": f"search:{market}:DAILY:1:60"}],
                [{"text": "⬇️ هبوط يومي", "callback_data": f"search:{market}:DAILY:-1:60"}],
                [{"text": "⭐ قوة فنية 70+", "callback_data": f"search:{market}:DAILY:0:70"}],
                [{"text": "🧰 فلاتر هذا السوق", "callback_data": f"fm:{market}"}],
                [{"text": "⬅️ الأسواق", "callback_data": "menu:scan"}],
            ]
        }

    @staticmethod
    def _filter_market_menu() -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [
                    {"text": "🇸🇦 السعودي", "callback_data": "fm:SAUDI"},
                    {"text": "🇺🇸 الأمريكي", "callback_data": "fm:US"},
                ],
                [
                    {"text": "💱 العملات", "callback_data": "fm:FOREX"},
                    {"text": "🪙 الرقمية", "callback_data": "fm:CRYPTO"},
                ],
                [{"text": "⬅️ الرئيسية", "callback_data": "menu:home"}],
            ]
        }

    @staticmethod
    def _filter_categories_menu(market: str) -> dict[str, Any]:
        rows: list[list[dict[str, str]]] = []
        for index in range(0, len(CATEGORIES), 2):
            rows.append([
                {"text": item.title, "callback_data": f"fc:{market}:{item.category_id}"}
                for item in CATEGORIES[index:index + 2]
            ])
        rows += [
            [{"text": "⚡ أسرع فلاتر", "callback_data": f"fq:{market}"}],
            [{"text": "⬅️ الأسواق", "callback_data": "menu:filters"}],
        ]
        return {"inline_keyboard": rows}

    @staticmethod
    def _quick_filters_menu(market: str) -> dict[str, Any]:
        quick = ("pathup", "pathdn", "rtup", "rtdn", "planup", "plandn", "volrise", "squeeze")
        rows: list[list[dict[str, str]]] = []
        for index in range(0, len(quick), 2):
            rows.append([
                {"text": PRESET_BY_ID[preset_id].title, "callback_data": f"fp:{market}:{preset_id}:D"}
                for preset_id in quick[index:index + 2]
            ])
        rows.append([{"text": "⬅️ التصنيفات", "callback_data": f"fm:{market}"}])
        return {"inline_keyboard": rows}

    @staticmethod
    def _preset_menu(market: str, category_id: str) -> dict[str, Any]:
        items = presets_for_category(category_id)
        rows: list[list[dict[str, str]]] = []
        for index in range(0, len(items), 2):
            rows.append([
                {"text": item.title, "callback_data": f"fp:{market}:{item.preset_id}:D"}
                for item in items[index:index + 2]
            ])
        rows.append([{"text": "⬅️ التصنيفات", "callback_data": f"fm:{market}"}])
        return {"inline_keyboard": rows}

    @staticmethod
    def _analysis_buttons(symbol: str) -> dict[str, Any]:
        spec = normalize_symbol(symbol)
        rows: list[list[dict[str, str]]] = [
            [{"text": "🔄 تحديث التحليل", "callback_data": f"symbol:{spec.display_symbol}"}]
        ]
        links = reference_links(spec)
        for index in range(0, len(links), 2):
            rows.append([
                {"text": f"↗️ {name}", "url": url}
                for name, url in links[index:index + 2]
            ])
        rows.append([{"text": "🏠 الرئيسية", "callback_data": "menu:home"}])
        return {"inline_keyboard": rows}

    @staticmethod
    def _scan_buttons(
        items: list[Any],
        market: str,
        horizon: str,
        direction: int,
        min_score: int,
        options_mode: bool = False,
    ) -> dict[str, Any]:
        rows: list[list[dict[str, str]]] = []
        for item in items[:10]:
            side = "CALL " if options_mode and item.direction > 0 else "PUT " if options_mode else ""
            rows.append([{
                "text": f"📊 {side}{item.display_symbol} · {item.confidence}%",
                "callback_data": f"symbol:{item.display_symbol}",
            }])
        prefix = "optionsearch" if options_mode else "search"
        rows += [
            [
                {"text": "⬆️ صعود" if not options_mode else "🟢 CALL", "callback_data": f"{prefix}:{market}:{horizon}:1:{min_score}"},
                {"text": "⬇️ هبوط" if not options_mode else "🔴 PUT", "callback_data": f"{prefix}:{market}:{horizon}:-1:{min_score}"},
                {"text": "↕️ الكل", "callback_data": f"{prefix}:{market}:{horizon}:0:{min_score}"},
            ],
            [
                {"text": "قوة 55+", "callback_data": f"{prefix}:{market}:{horizon}:{direction}:55"},
                {"text": "قوة 70+", "callback_data": f"{prefix}:{market}:{horizon}:{direction}:70"},
                {"text": "🧰 الفلاتر", "callback_data": f"fm:{'US' if options_mode else market}"},
            ],
            [{"text": "🏠 الرئيسية", "callback_data": "menu:home"}],
        ]
        return {"inline_keyboard": rows}

    @staticmethod
    def _preset_result_buttons(report: PresetReport, frame_code: str) -> dict[str, Any]:
        rows: list[list[dict[str, str]]] = []
        for match in report.items[:10]:
            item = match.analysis
            rows.append([{
                "text": f"📊 {item.display_symbol} · {item.confidence}%",
                "callback_data": f"symbol:{item.display_symbol}",
            }])
        other = "H" if frame_code == "D" else "D"
        other_text = "⚡ تطبيق على الساعة" if other == "H" else "🗓 تطبيق على اليومي"
        rows += [
            [{"text": other_text, "callback_data": f"fp:{report.market}:{report.preset.preset_id}:{other}"}],
            [
                {"text": "⬅️ نفس التصنيف", "callback_data": f"fc:{report.market}:{report.preset.category_id}"},
                {"text": "🏠 الرئيسية", "callback_data": "menu:home"},
            ],
        ]
        return {"inline_keyboard": rows}

    @staticmethod
    def _price(value: float) -> str:
        return f"{value:.5f}".rstrip("0").rstrip(".")

    @classmethod
    def _format_preset_report(cls, report: PresetReport, frame_code: str) -> str:
        frame_name = "يومي" if frame_code == "D" else "ساعة"
        lines = [
            f"🧰 <b>{html.escape(report.preset.title)}</b>",
            html.escape(report.preset.description),
            "",
            f"السوق: <b>{html.escape(report.universe_label)}</b>",
            f"الفاصل: <b>{frame_name}</b> — آخر شمعة مغلقة فقط",
            f"تم تحليل: <b>{report.analyzed_symbols}/{report.total_symbols}</b>",
            "",
        ]
        if not report.items:
            lines += [
                "لم يظهر رمز مطابق للشرط الآن.",
                "<i>عدم ظهور نتيجة أفضل من تخفيف تعريف الفلتر أو تسمية ترتيب متوسطات بأنه تقاطع.</i>",
            ]
        for index, match in enumerate(report.items, 1):
            item = match.analysis
            icon = "🟢" if item.direction > 0 else "🔴" if item.direction < 0 else "🟡"
            reason = "، ".join(html.escape(value) for value in match.reasons[:3]) or "مطابقة الشرط الفني"
            lines += [
                f"{index}. {icon} <b>{html.escape(item.display_symbol)}</b> — {cls._price(item.price)} — قوة {item.confidence}/100",
                f"   السبب: {reason}",
            ]
        if report.failed_symbols:
            lines += ["", f"تعذر جلب {report.failed_symbols} رمزًا في هذه الجولة."]
        lines += ["", "<i>مطابقة الفلتر ليست توصية تنفيذ؛ افتح الرمز لمراجعة الخطة والعوائق والفواصل.</i>"]
        return "\n".join(lines)

    async def _send_symbol_analysis(self, chat_id: int, symbol: str) -> None:
        clean = symbol.strip().upper()
        if not clean:
            await self.telegram.send_message(
                chat_id,
                "أرسل الرمز، مثال: <code>1120</code> أو <code>AAPL</code> أو <code>EURUSD</code>.",
            )
            return
        await self.telegram.send_message(
            chat_id,
            f"⏳ جاري تحليل <code>{html.escape(clean)}</code> من آخر الشموع المغلقة...",
        )
        try:
            result = normalize_analysis(await self.live.analyze(clean))
        except MarketDataError as exc:
            stored = await self.db.find_symbol(clean, limit=12)
            if stored:
                await self.telegram.send_message(
                    chat_id,
                    "⚠️ تعذر الجلب المباشر، وهذه آخر بيانات محفوظة:\n\n"
                    + format_symbol_analysis(clean, stored),
                    self._detail_buttons(stored[0]),
                )
                return
            await self.telegram.send_message(
                chat_id,
                "❌ <b>تعذر تحليل الرمز الآن.</b>\n\n"
                f"السبب: {html.escape(str(exc))}\n"
                "جرّب الرمز السعودي من دون لاحقة، مثل <code>1120</code>.",
                self._main_menu(),
            )
            return
        await self.telegram.send_message(
            chat_id,
            format_analysis(result),
            self._analysis_buttons(result.display_symbol),
        )

    async def _send_search(
        self,
        chat_id: int,
        market: str = "ALL",
        horizon: str = "ALL",
        direction: int = 0,
        min_score: int | None = None,
        options_mode: bool = False,
    ) -> None:
        threshold = self.settings.default_min_score if min_score is None else min_score
        selected = "US_OPTIONS" if options_mode else market
        if selected in {"SAUDI", "US", "US_OPTIONS", "FOREX", "CRYPTO"}:
            scope_text = (
                "أسهم السوق السعودي الرئيسي"
                if selected == "SAUDI"
                else "الأصول الأمريكية المؤهلة للأوبشن والأعلى سيولة"
                if selected == "US_OPTIONS"
                else "كون السوق المحدد"
            )
            await self.telegram.send_message(
                chat_id,
                f"⏳ جاري فحص <b>{scope_text}</b> من آخر شمعة مغلقة. قد تستغرق الجولة الأولى بعض الوقت...",
            )
            try:
                report = await self.scanner.scan_directional(
                    selected, horizon, direction, threshold, limit=10
                )
            except MarketDataError as exc:
                await self.telegram.send_message(
                    chat_id,
                    "❌ تعذر تنفيذ المسح الآن: " + html.escape(str(exc)),
                    self._main_menu(),
                )
                return
            await self.telegram.send_message(
                chat_id,
                format_scan(report),
                self._scan_buttons(
                    list(report.items), selected, horizon, direction, threshold,
                    options_mode=options_mode,
                ),
            )
            return
        stored = await self.db.list_opportunities(
            market=None,
            horizon=horizon,
            direction=direction,
            min_score=threshold,
            limit=12,
            active_only=True,
            fresh_only=True,
        )
        await self.telegram.send_message(
            chat_id,
            format_search_results(
                "تنبيهات TradingView المحفوظة", stored, market=market,
                horizon=horizon, min_score=threshold, options_mode=options_mode,
            ),
            self._result_buttons(
                stored, market, horizon, direction, threshold,
                options_mode=options_mode,
            ),
        )

    async def _send_preset(self, chat_id: int, market: str, preset_id: str, frame_code: str) -> None:
        preset = PRESET_BY_ID.get(preset_id)
        if preset is None:
            await self.telegram.send_message(chat_id, "❌ الفلتر غير معروف.", self._main_menu())
            return
        frame_name = "اليومي" if frame_code == "D" else "الساعة"
        await self.telegram.send_message(
            chat_id,
            f"⏳ تطبيق فلتر <b>{html.escape(preset.title)}</b> على {frame_name}...",
        )
        try:
            report = await self.scanner.scan_preset(market, preset_id, frame_code, limit=10)
        except MarketDataError as exc:
            await self.telegram.send_message(
                chat_id,
                "❌ تعذر تنفيذ الفلتر الآن: " + html.escape(str(exc)),
                self._filter_categories_menu(market),
            )
            return
        await self.telegram.send_message(
            chat_id,
            self._format_preset_report(report, frame_code),
            self._preset_result_buttons(report, frame_code),
        )

    async def _handle_text(self, chat_id: int, text: str) -> None:
        command = text.partition(" ")[0].split("@", 1)[0].lower()
        if command in {"/start", "/help"}:
            await self.telegram.send_message(chat_id, LIVE_HELP_TEXT, self._main_menu())
            return
        if command in {"/filters", "/presets", "/patterns"}:
            await self.telegram.send_message(
                chat_id, "<b>اختر السوق للفلاتر الفنية:</b>", self._filter_market_menu()
            )
            return
        if command == "/sources":
            await self.telegram.send_message(chat_id, source_catalog_text(), self._main_menu())
            return
        if command in {"/recommendations", "/top"}:
            await self._send_search(chat_id, "SAUDI", "DAILY", 1, 60)
            return
        if command == "/active":
            await self._send_search(chat_id, "SAUDI", min_score=55)
            return
        if command == "/calls":
            await self._send_search(chat_id, "US_OPTIONS", "INTRADAY", 1, 60, True)
            return
        if command == "/puts":
            await self._send_search(chat_id, "US_OPTIONS", "INTRADAY", -1, 60, True)
            return
        if command == "/options":
            await self._send_search(chat_id, "US_OPTIONS", "INTRADAY", 0, 60, True)
            return
        await super()._handle_text(chat_id, text)

    async def _handle_callback(self, callback: dict[str, Any]) -> None:
        callback_id = str(callback["id"])
        message = callback.get("message") or {}
        chat_id = int(message.get("chat", {}).get("id", 0))
        user_id = int(callback.get("from", {}).get("id", 0))
        data = str(callback.get("data", ""))
        if data in {"menu:home", "menu:help"}:
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "القائمة الرئيسية")
            await self.telegram.send_message(chat_id, LIVE_HELP_TEXT, self._main_menu())
            return
        if data == "menu:sources":
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "مصادر البيانات")
            await self.telegram.send_message(chat_id, source_catalog_text(), self._main_menu())
            return
        if data == "menu:filters":
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "الفلاتر الفنية")
            await self.telegram.send_message(
                chat_id, "<b>اختر السوق للفلاتر الفنية:</b>", self._filter_market_menu()
            )
            return
        if data.startswith("fm:"):
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            market = data.split(":", 1)[1]
            await self.telegram.answer_callback(callback_id, "اختر التصنيف")
            await self.telegram.send_message(
                chat_id,
                "<b>اختر تصنيف الفلتر:</b>\nكل نتيجة تُحسب من آخر شمعة مغلقة وتعرض سبب المطابقة.",
                self._filter_categories_menu(market),
            )
            return
        if data.startswith("fq:"):
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            market = data.split(":", 1)[1]
            await self.telegram.answer_callback(callback_id, "أسرع الفلاتر")
            await self.telegram.send_message(chat_id, "<b>فلاتر سريعة:</b>", self._quick_filters_menu(market))
            return
        if data.startswith("fc:"):
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            parts = data.split(":")
            if len(parts) != 3 or parts[2] not in CATEGORY_BY_ID:
                await self.telegram.answer_callback(callback_id, "تصنيف غير صالح")
                return
            market, category_id = parts[1], parts[2]
            category = CATEGORY_BY_ID[category_id]
            await self.telegram.answer_callback(callback_id, category.title)
            await self.telegram.send_message(
                chat_id,
                f"<b>{html.escape(category.title)}</b>\n{html.escape(category.description)}",
                self._preset_menu(market, category_id),
            )
            return
        if data.startswith("fp:"):
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            parts = data.split(":")
            if len(parts) != 4:
                await self.telegram.answer_callback(callback_id, "فلتر غير صالح")
                return
            market, preset_id, frame_code = parts[1], parts[2], parts[3]
            await self.telegram.answer_callback(callback_id, "بدأ الفحص")
            await self._send_preset(chat_id, market, preset_id, frame_code)
            return
        if data.startswith("quick:"):
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            action = data.split(":", 1)[1]
            await self.telegram.answer_callback(callback_id, "بدأ المسح")
            if action == "saudi_up":
                await self._send_search(chat_id, "SAUDI", "DAILY", 1, 60)
            elif action == "calls":
                await self._send_search(chat_id, "US_OPTIONS", "INTRADAY", 1, 60, True)
            elif action == "puts":
                await self._send_search(chat_id, "US_OPTIONS", "INTRADAY", -1, 60, True)
            return
        if data == "system:status":
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "حالة النظام")
            health = format_health(await self.db.health_snapshot())
            text = (
                health
                + "\n\n<b>محرك التحليل:</b> يعمل عند الطلب\n"
                + "<b>الفلاتر:</b> تقاطعات حديثة، شموع، مستويات، تذبذب وخطط مؤكدة\n"
                + "<b>السعودي:</b> أسهم السوق الرئيسي ضمن الكون المحلي\n"
                + "<b>الأوبشن الأمريكي:</b> اتجاه الأصل الأساسي فقط\n"
                + "<b>مصدر الشموع:</b> Yahoo Finance\n"
                + "<i>لا يختار عقد أوبشن ولا Greeks ولا ينفذ أوامر.</i>"
            )
            await self.telegram.send_message(chat_id, text, self._main_menu())
            return
        await super()._handle_callback(callback)
