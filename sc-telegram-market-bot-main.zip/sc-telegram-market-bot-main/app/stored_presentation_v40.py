from __future__ import annotations

import html

from .formatting import (
    direction_short,
    freshness_badge,
    human_age,
    price,
    score_percent,
    status_ar,
)
from .models import Opportunity
from .presentation_v40 import _pack_blocks


def _stored_block(index: int, item: Opportunity) -> list[str]:
    icon = "🟢" if item.direction > 0 else "🔴"
    targets = (item.target1, item.target2, item.target3)
    lines = [
        f"{index}. {icon} <b>{html.escape(item.tickerid)}</b> — {html.escape(direction_short(item.direction))}",
        f"الفاصل: <b>{html.escape(item.timeframe)}</b> | الحالة: <b>{html.escape(status_ar(item.status))}</b>",
        f"قوة التوافق الفنية: <b>{score_percent(item)}/100</b> | {freshness_badge(item)} — {html.escape(human_age(item.updated_at))}",
        f"الدخول المرجعي: <b>{price(item.entry)}</b>",
        f"🛑 وقف إلغاء الفكرة: <b>{price(item.stop)}</b>",
    ]
    for target_index, target in enumerate(targets, 1):
        if target is not None and target_index <= item.target_count:
            marker = "✅" if item.status in {"TARGET_1", "TARGET_2"} and target_index == 1 else "🎯"
            if item.status == "TARGET_2" and target_index <= 2:
                marker = "✅"
            lines.append(f"{marker} الهدف {target_index}: <b>{price(target)}</b>")
    return lines


def active_plan_pages(items: list[Opportunity]) -> tuple[str, ...]:
    header = [
        "📂 <b>خطط TradingView النشطة</b>",
        "هذه الخطط وصلت من تنبيهات TradingView وتبقى ظاهرة حتى الهدف الأخير أو الوقف أو الإلغاء.",
    ]
    if not items:
        return (
            "\n".join(
                header
                + [
                    "",
                    "لا توجد خطط TradingView نشطة حاليًا.",
                    "<i>التحليل المباشر والمسح يعملان بشكل مستقل عن هذه القائمة.</i>",
                ]
            ),
        )
    blocks = [_stored_block(index, item) for index, item in enumerate(items[:20], 1)]
    return _pack_blocks(
        header,
        blocks,
        [
            "",
            "<i>الخطة المخزنة لا تعني أن السعر ما زال داخل نطاق الدخول؛ افتح الرمز للحصول على تحليل مباشر محدث.</i>",
        ],
    )


__all__ = ["active_plan_pages"]
