from __future__ import annotations

import logging
import re
from typing import Any

import httpx

logger = logging.getLogger(__name__)


def _validate_reply_markup(reply_markup: dict[str, Any] | None) -> None:
    if not reply_markup:
        return
    rows = reply_markup.get("inline_keyboard")
    if rows is None:
        return
    if not isinstance(rows, list):
        raise ValueError("invalid Telegram inline keyboard")
    for row in rows:
        if not isinstance(row, list):
            raise ValueError("invalid Telegram keyboard row")
        for button in row:
            if not isinstance(button, dict):
                raise ValueError("invalid Telegram button")
            text = str(button.get("text", ""))
            if not text or len(text) > 128:
                raise ValueError("invalid Telegram button text")
            if "callback_data" in button:
                data = str(button["callback_data"])
                if not 1 <= len(data.encode("utf-8")) <= 64:
                    raise ValueError("Telegram callback_data exceeds 64 bytes")
            if "url" in button:
                url = str(button["url"])
                if not re.match(r"^https?://", url, re.IGNORECASE):
                    raise ValueError("invalid Telegram button URL")


def validate_telegram_payload(method: str, payload: dict[str, Any]) -> None:
    if method in {"sendMessage", "editMessageText"}:
        text = str(payload.get("text", ""))
        if not text or len(text) > 4096:
            raise ValueError("Telegram message must contain 1-4096 characters")
        _validate_reply_markup(payload.get("reply_markup"))
    elif method == "answerCallbackQuery":
        if len(str(payload.get("text", ""))) > 200:
            raise ValueError("Telegram callback answer exceeds 200 characters")
    elif method == "setMyCommands":
        commands = payload.get("commands")
        if not isinstance(commands, list) or not commands:
            raise ValueError("Telegram commands are missing")
        seen: set[str] = set()
        for item in commands:
            command = str(item.get("command", ""))
            description = str(item.get("description", ""))
            if re.fullmatch(r"[a-z0-9_]{1,32}", command) is None:
                raise ValueError("invalid Telegram command")
            if command in seen:
                raise ValueError("duplicate Telegram command")
            if not 1 <= len(description) <= 256:
                raise ValueError("invalid Telegram command description")
            seen.add(command)


class TelegramClient:
    def __init__(self, token: str):
        self.base_url = f"https://api.telegram.org/bot{token}"
        self.client = httpx.AsyncClient(timeout=20.0)

    async def close(self) -> None:
        await self.client.aclose()

    async def _call(self, method: str, payload: dict[str, Any]) -> dict[str, Any]:
        validate_telegram_payload(method, payload)
        response = await self.client.post(f"{self.base_url}/{method}", json=payload)
        response.raise_for_status()
        data = response.json()
        if not data.get("ok"):
            raise RuntimeError(f"Telegram API error: {data}")
        return data

    async def send_message(
        self,
        chat_id: int,
        text: str,
        reply_markup: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup
        return await self._call("sendMessage", payload)

    async def edit_message(
        self,
        chat_id: int,
        message_id: int,
        text: str,
        reply_markup: dict[str, Any] | None = None,
    ) -> None:
        payload: dict[str, Any] = {
            "chat_id": chat_id,
            "message_id": message_id,
            "text": text,
            "parse_mode": "HTML",
            "disable_web_page_preview": True,
        }
        if reply_markup:
            payload["reply_markup"] = reply_markup
        await self._call("editMessageText", payload)

    async def answer_callback(self, callback_query_id: str, text: str = "") -> None:
        await self._call(
            "answerCallbackQuery",
            {"callback_query_id": callback_query_id, "text": text},
        )

    async def configure_webhook(
        self,
        url: str,
        secret_token: str,
        drop_pending_updates: bool = False,
    ) -> None:
        payload: dict[str, Any] = {
            "url": url,
            "allowed_updates": ["message", "edited_message", "callback_query"],
            "drop_pending_updates": drop_pending_updates,
        }
        if secret_token:
            payload["secret_token"] = secret_token
        await self._call("setWebhook", payload)

    async def set_commands(self) -> None:
        await self._call(
            "setMyCommands",
            {
                "commands": [
                    {"command": "start", "description": "فتح القائمة الرئيسية"},
                    {"command": "analyze", "description": "تحليل مباشر لأي رمز"},
                    {"command": "filters", "description": "الفلاتر الفنية المتقدمة"},
                    {"command": "recommendations", "description": "أفضل الفرص الصاعدة السعودية"},
                    {"command": "options", "description": "أفضل اتجاهات CALL وPUT"},
                    {"command": "calls", "description": "أفضل فرص CALL الأمريكية"},
                    {"command": "puts", "description": "أفضل فرص PUT الأمريكية"},
                    {"command": "scan", "description": "اختيار السوق والفاصل والاتجاه"},
                    {"command": "saudi", "description": "مسح السوق السعودي الرئيسي"},
                    {"command": "us", "description": "مسح السوق الأمريكي"},
                    {"command": "forex", "description": "مسح العملات"},
                    {"command": "sources", "description": "مصادر البيانات والتحقق"},
                    {"command": "status", "description": "حالة الخادم والبيانات"},
                    {"command": "help", "description": "شرح الاستخدام"},
                ]
            },
        )
