from __future__ import annotations

from dataclasses import replace

from .audited_engine import _reference_levels, analyze_frame_audited
from .opportunity_v37 import enrich_frame_opportunity, opportunity_state_rank
from .risk_engine_v41 import build_adaptive_plan
from .school_engine_v38 import (
    FRAME_SPECS,
    SchoolConsensus,
    SchoolFrameAnalysis,
    SchoolSignal,
    _promote,
    _school_signals,
)
from .school_engine_v38_safe import SafeSchoolConsensusAnalyzer
from .technical import (
    Candle,
    FrameAnalysis,
    _atr,
    _round,
    normalize_symbol,
)


def _corrected_school_signals(
    candles: list[Candle],
    frame: FrameAnalysis,
    asset_class: str,
) -> list[SchoolSignal]:
    """Uses a level known before the trigger candle for breakout decisions."""

    signals = [
        signal
        for signal in _school_signals(candles, frame, asset_class)
        if signal.school != "الدعم والمقاومة"
    ]
    current, previous = candles[-1], candles[-2]
    price = current.close
    atr = max(_atr(candles), price * 0.0001)
    prior_support, prior_resistance, _ = _reference_levels(
        candles, price, atr
    )
    buffer = max(atr * 0.08, price * 0.0007)
    touch = max(atr * 0.20, price * 0.001)
    overshoot = max(atr * 0.65, price * 0.004)

    broke_up = (
        previous.close <= prior_resistance + buffer
        and current.close > prior_resistance + buffer
    )
    broke_down = (
        previous.close >= prior_support - buffer
        and current.close < prior_support - buffer
    )
    broke_up_recently = any(
        bar.close > prior_resistance + buffer
        for bar in candles[-7:-1]
    )
    broke_down_recently = any(
        bar.close < prior_support - buffer
        for bar in candles[-7:-1]
    )
    retest_up = (
        broke_up_recently
        and prior_resistance - overshoot
        <= current.low
        <= prior_resistance + touch
        and current.close > prior_resistance + buffer * 0.25
    )
    retest_down = (
        broke_down_recently
        and prior_support - touch
        <= current.high
        <= prior_support + overshoot
        and current.close < prior_support - buffer * 0.25
    )

    spread = max(current.high - current.low, 1e-12)
    close_location = (current.close - current.low) / spread
    near_support = abs(price - frame.support) <= 0.45 * atr
    near_resistance = abs(price - frame.resistance) <= 0.45 * atr

    if retest_up:
        signals.append(
            SchoolSignal(
                "الدعم والمقاومة",
                1,
                92,
                "ارتداد",
                "إعادة اختبار صاعدة لمقاومة مخترقة مع إغلاق فوقها",
                True,
            )
        )
    elif retest_down:
        signals.append(
            SchoolSignal(
                "الدعم والمقاومة",
                -1,
                92,
                "ارتداد",
                "إعادة اختبار هابطة لدعم مكسور مع إغلاق تحته",
                True,
            )
        )
    elif broke_up:
        signals.append(
            SchoolSignal(
                "الدعم والمقاومة",
                1,
                90,
                "اختراق",
                "إغلاق مؤكد فوق مقاومة معروفة قبل شمعة الزناد",
                True,
            )
        )
    elif broke_down:
        signals.append(
            SchoolSignal(
                "الدعم والمقاومة",
                -1,
                90,
                "اختراق",
                "إغلاق مؤكد تحت دعم معروف قبل شمعة الزناد",
                True,
            )
        )
    elif near_support and current.close > current.open and close_location >= 0.65:
        signals.append(
            SchoolSignal(
                "الدعم والمقاومة",
                1,
                75,
                "ارتداد",
                "رفض سعري صاعد من دعم قريب",
                True,
            )
        )
    elif near_resistance and current.close < current.open and close_location <= 0.35:
        signals.append(
            SchoolSignal(
                "الدعم والمقاومة",
                -1,
                75,
                "ارتداد",
                "رفض سعري هابط من مقاومة قريبة",
                True,
            )
        )

    strongest: dict[str, SchoolSignal] = {}
    for signal in signals:
        previous_signal = strongest.get(signal.school)
        if previous_signal is None or signal.strength > previous_signal.strength:
            strongest[signal.school] = signal
    return list(strongest.values())



_SCHOOL_AXES = {
    "داو والبنية السعرية": "البنية والمستويات",
    "الدعم والمقاومة": "البنية والمستويات",
    "وايكوف المبسط (عرض وطلب)": "البنية والمستويات",
    "السلوك السعري والشموع": "السلوك السعري",
    "اتباع الاتجاه والمتوسطات": "الاتجاه",
    "الزخم (MACD وRSI)": "الزخم",
    "الحجم وVSA": "الحجم",
    "بولنجر والتذبذب": "التذبذب",
    "فيبوناتشي": "فيبوناتشي",
}


def _school_axis(signal: SchoolSignal) -> str:
    return _SCHOOL_AXES.get(signal.school, signal.school)


def _axis_best(signals: list[SchoolSignal]) -> dict[str, SchoolSignal]:
    result: dict[str, SchoolSignal] = {}
    for signal in signals:
        axis = _school_axis(signal)
        previous = result.get(axis)
        if previous is None or signal.strength > previous.strength:
            result[axis] = signal
    return result


def _axis_score(signals: list[SchoolSignal]) -> float:
    strengths = sorted(
        (signal.strength for signal in _axis_best(signals).values()),
        reverse=True,
    )
    weights = (1.0, 0.65, 0.40, 0.25, 0.15)
    return sum(value * weights[index] for index, value in enumerate(strengths[: len(weights)]))

def evaluate_school_consensus_final(
    candles: list[Candle],
    frame: FrameAnalysis,
    asset_class: str,
) -> SchoolConsensus:
    """Evaluates independent evidence axes instead of double-counting related schools."""

    signals = _corrected_school_signals(candles, frame, asset_class)
    long_signals = sorted(
        (signal for signal in signals if signal.direction > 0 and signal.strength >= 55),
        key=lambda signal: signal.strength,
        reverse=True,
    )
    short_signals = sorted(
        (signal for signal in signals if signal.direction < 0 and signal.strength >= 55),
        key=lambda signal: signal.strength,
        reverse=True,
    )
    long_score = _axis_score(long_signals)
    short_score = _axis_score(short_signals)
    long_best = long_signals[0].strength if long_signals else 0
    short_best = short_signals[0].strength if short_signals else 0

    if not long_signals and not short_signals:
        return SchoolConsensus(0, False, 0, "محايد", (), (), False, ())
    if abs(long_score - short_score) < 6 and abs(long_best - short_best) < 5:
        return SchoolConsensus(
            0,
            False,
            round(max(long_score, short_score)),
            "محايد",
            (),
            tuple(sorted(signals, key=lambda item: item.strength, reverse=True)[:4]),
            False,
            (),
        )

    direction = 1 if long_score > short_score else -1
    aligned = long_signals if direction > 0 else short_signals
    opposing = short_signals if direction > 0 else long_signals
    aligned_axes = _axis_best(aligned)
    opposing_axes = _axis_best(opposing)
    axis_signals = sorted(aligned_axes.values(), key=lambda item: item.strength, reverse=True)
    strongest = axis_signals[0] if axis_signals else None
    opposing_best = max((item.strength for item in opposing_axes.values()), default=0)
    aligned_score = _axis_score(aligned)
    opposing_score = _axis_score(opposing)

    strong_single = bool(
        len(aligned_axes) == 1
        and strongest
        and strongest.strength >= 86
        and strongest.actionable
        and strongest.strength >= opposing_best + 12
        and aligned_score >= opposing_score + 10
    )
    multiple = bool(
        len(axis_signals) >= 2
        and axis_signals[0].strength >= 60
        and axis_signals[1].strength >= 58
    )
    opposition_veto = bool(
        opposing_axes
        and (
            opposing_best >= 84
            or opposing_best >= (strongest.strength if strongest else 0) + 8
            or opposing_score >= aligned_score * 0.86
        )
    )
    qualified = (strong_single or multiple) and not opposition_veto
    selected = tuple(aligned) if qualified else tuple(aligned[:2])
    independent_axes = tuple(
        axis
        for axis, _ in sorted(
            aligned_axes.items(),
            key=lambda item: item[1].strength,
            reverse=True,
        )
    )
    strength_basis = axis_signals[:4]
    average = round(
        sum(signal.strength for signal in strength_basis)
        / max(len(strength_basis), 1)
    )
    strength = min(
        96,
        average + (6 if len(strength_basis) >= 3 else 3 if len(strength_basis) == 2 else 0),
    )
    priorities = {
        "انعكاس": 7,
        "ارتداد": 6,
        "اختراق": 5,
        "اختراق تذبذب": 5,
        "تأكيد طلب": 4,
        "تأكيد عرض": 4,
        "تأكيد زخم": 2,
        "استمرار اتجاه": 1,
    }
    signal_type = (
        max(selected, key=lambda signal: priorities.get(signal.signal_type, 0)).signal_type
        if selected
        else "محايد"
    )
    return SchoolConsensus(
        direction if qualified else 0,
        qualified,
        strength if qualified else average,
        signal_type,
        selected,
        tuple(opposing[:3]),
        strong_single,
        independent_axes,
    )


def _direct_school_plan(
    candles: list[Candle],
    frame: SchoolFrameAnalysis,
    consensus: SchoolConsensus,
) -> SchoolFrameAnalysis:
    if not consensus.qualified or consensus.direction == 0:
        return frame
    if frame.entry is not None and frame.stop is not None and frame.targets:
        return frame
    if consensus.signal_type not in {
        "انعكاس",
        "ارتداد",
        "تأكيد طلب",
        "تأكيد عرض",
    }:
        return frame
    if not any(signal.actionable for signal in consensus.signals):
        return frame

    direction = consensus.direction
    price = candles[-1].close
    anchor = frame.support if direction > 0 else frame.resistance
    plan = build_adaptive_plan(
        candles=candles,
        frame_name=frame.frame,
        direction=direction,
        event_level=anchor,
        market=frame.market,
        entry_override=price,
    )
    if not plan.valid or plan.entry is None or plan.stop is None:
        reason = plan.rejection_reason or "هندسة الوقف والأهداف لم تجتز شروط الفاصل"
        return replace(
            frame,
            warnings=tuple(
                dict.fromkeys((*frame.warnings, *plan.warnings, reason))
            ),
        )

    qualifier = (
        "مدرسة واحدة قوية"
        if consensus.strong_single
        else f"توافق {len(consensus.independent_axes)} محاور مستقلة"
    )
    reasons = tuple(
        dict.fromkeys(
            (
                *frame.reasons,
                f"سبب الرأي: {qualifier}",
                *(
                    f"مدرسة {signal.school}: {signal.reason}"
                    for signal in consensus.signals
                ),
                "تقدم الخطة: 0/3",
            )
        )
    )
    return replace(
        frame,
        event=f"{consensus.signal_type} بتأكيد مدارس",
        plan_state=f"فرصة {consensus.signal_type} محتملة — {qualifier}",
        entry=plan.entry,
        stop=plan.stop,
        targets=plan.targets,
        risk_reward=plan.first_rr,
        reasons=reasons,
        warnings=tuple(dict.fromkeys((*frame.warnings, *plan.warnings))),
        risk_atr=plan.risk_atr,
        target_atr=plan.target_atr,
        duration_low_bars=plan.duration_low_bars,
        duration_high_bars=plan.duration_high_bars,
        duration_samples=plan.duration_samples,
        duration_success_rate=plan.duration_success_rate,
        duration_method=plan.duration_method,
        plan_profile=plan.profile,
    )


def apply_school_consensus_final(
    candles: list[Candle],
    frame: FrameAnalysis,
    asset_class: str,
) -> SchoolFrameAnalysis:
    consensus = evaluate_school_consensus_final(
        candles, frame, asset_class
    )
    promoted = _promote(frame, consensus)
    if not consensus.qualified:
        if consensus.opposing:
            return replace(
                promoted,
                warnings=tuple(
                    dict.fromkeys(
                        (
                            *promoted.warnings,
                            "لا توجد فرصة مدارس مكتملة؛ الإشارات متعارضة أو غير كافية",
                        )
                    )
                ),
            )
        return promoted

    direction = consensus.direction
    evidence = consensus.strength
    if len(consensus.signals) >= 2:
        school_reason = (
            f"توافق المدارس: {len(consensus.independent_axes)} محاور مستقلة — "
            + " + ".join(consensus.school_names)
        )
    else:
        school_reason = (
            f"مدرسة واحدة قوية: {consensus.school_names[0]}"
        )
    score = (
        max(promoted.score, min(100, 50 + round(evidence * 0.45)))
        if direction > 0
        else min(promoted.score, max(0, 50 - round(evidence * 0.45)))
    )
    updated = replace(
        promoted,
        direction=direction,
        trend="صاعد" if direction > 0 else "هابط",
        confidence=min(96, evidence),
        score=score,
        reasons=tuple(
            dict.fromkeys(
                (
                    school_reason,
                    *(
                        f"مدرسة {signal.school} (قوة {signal.strength}/100): "
                        f"{signal.reason}"
                        for signal in consensus.signals
                    ),
                    *promoted.reasons,
                )
            )
        ),
        warnings=tuple(
            dict.fromkeys(
                (
                    *promoted.warnings,
                    *(
                        (
                            "توجد مدرسة معاكسة قوية؛ لا تُدمج الإشارات دون وقف",
                        )
                        if consensus.opposing
                        else ()
                    ),
                )
            )
        ),
    )
    # Discard the legacy frame plan before constructing the production plan;
    # V4.1 owns all entry/stop/target geometry.
    clean = replace(
        updated,
        entry=None,
        stop=None,
        targets=(),
        risk_reward=None,
        risk_atr=None,
        target_atr=(),
        duration_low_bars=None,
        duration_high_bars=None,
        duration_samples=0,
        duration_success_rate=None,
        duration_method="",
        plan_profile="",
    )
    enriched = enrich_frame_opportunity(candles, clean)
    direct = _direct_school_plan(candles, clean, consensus)
    direct_valid = (
        direct.entry is not None
        and direct.stop is not None
        and len(direct.targets) == 3
    )
    # A current actionable reversal/retest should not be hidden behind a
    # future breakout condition.  Already-active historical plans remain
    # visible so target progress is not lost.
    if direct_valid and (
        opportunity_state_rank(enriched) < 30
        or "فرصة مشروطة" in enriched.plan_state
    ):
        return direct
    if opportunity_state_rank(enriched) >= 30:
        return enriched
    return direct


class FinalSchoolConsensusAnalyzer(SafeSchoolConsensusAnalyzer):
    """Production analyzer with corrected levels and risk anchors."""

    async def _analyze_frame(
        self, symbol: str, frame_key: str
    ) -> tuple[SchoolFrameAnalysis, dict, str]:
        spec = normalize_symbol(symbol)
        candles, metadata, provider_id = await self._fetch(
            symbol, frame_key
        )
        frame = analyze_frame_audited(
            candles,
            FRAME_SPECS[frame_key].label,
            spec.asset_class,
        )
        frame = replace(frame, market=spec.market, frame_key=frame_key)
        return (
            apply_school_consensus_final(
                candles, frame, spec.asset_class
            ),
            metadata,
            provider_id,
        )
