from __future__ import annotations

from typing import Any

from .data_sources import reference_links
from .school_engine_v38 import FRAME_SPECS
from .technical import normalize_symbol


FRAME_ALIASES_V38: dict[str, str | None] = {
    "1m": "1m", "1": "1m", "دقيقة": "1m", "الدقيقة": "1m",
    "5m": "5m", "5": "5m", "5د": "5m", "خمس": "5m",
    "15m": "15m", "15": "15m", "15د": "15m", "ربع": "15m",
    "30m": "30m", "30": "30m", "30د": "30m", "نصف": "30m",
    "1h": "1h", "60": "1h", "ساعة": "1h", "ساعي": "1h",
    "4h": "4h", "240": "4h", "4س": "4h", "أربع": "4h",
    "1d": "1d", "d": "1d", "يومي": "1d", "يوم": "1d",
    "1w": "1w", "w": "1w", "أسبوعي": "1w", "اسبوعي": "1w", "أسبوع": "1w",
    "1mo": "1mo", "mo": "1mo", "شهري": "1mo", "شهر": "1mo",
    "all": None, "كل": None, "جميع": None,
}
FRAME_CALLBACK_V38: dict[str, str | None] = {
    "A": None, "1": "1m", "5": "5m", "15": "15m", "30": "30m",
    "H": "1h", "4H": "4h", "D": "1d", "W": "1w", "MO": "1mo",
}

FOCUSED_HELP_TEXT_V38 = """<b>بوصلة الأسواق V3.8 — توافق المدارس من دقيقة إلى شهر</b>

تظهر الفرصة عندما:
• تتوافق مدرستان مستقلتان في الاتجاه نفسه، أو
• تظهر مدرسة واحدة قوية وقابلة للتنفيذ.

يذكر البوت عدد المدارس وأسماءها، نوع الفرصة، منطقة الدخول، الوقف، الأهداف، والفاصل الأنسب.

أمثلة:
<code>/analyze 2222</code> — من دقيقة إلى شهر
<code>/analyze 2222 1m</code> — دقيقة
<code>/analyze AAPL 4h</code> — 4 ساعات
<code>/analyze 1120 1w</code> — أسبوعي
<code>/analyze NVDA 1mo</code> — شهري

/scan — اختر السوق ثم الفاصل
/filters — الفلاتر الفنية
/recommendations — أفضل الفرص السعودية
/options — اتجاهات CALL وPUT حسب الأصل
/active — خطط TradingView القائمة
/status — حالة النظام

<i>التحليل احتمالي ولا ينفذ صفقات. الوقف هو إلغاء الفكرة.</i>"""


def parse_symbol_frame_v38(argument: str) -> tuple[str, str | None]:
    parts = [part for part in argument.strip().split() if part]
    if not parts:
        return "", None
    frame: str | None = None
    for token in parts[1:]:
        key = token.lower().strip()
        if key in FRAME_ALIASES_V38:
            frame = FRAME_ALIASES_V38[key]
    return parts[0].upper(), frame


def build_analysis_buttons_v38(symbol: str) -> dict[str, Any]:
    spec = normalize_symbol(symbol)
    ticker = spec.display_symbol
    rows: list[list[dict[str, str]]] = [
        [{"text": "🔄 كل الفواصل", "callback_data": f"a38:{ticker}:A"}],
        [
            {"text": "1د", "callback_data": f"a38:{ticker}:1"},
            {"text": "5د", "callback_data": f"a38:{ticker}:5"},
            {"text": "15د", "callback_data": f"a38:{ticker}:15"},
        ],
        [
            {"text": "30د", "callback_data": f"a38:{ticker}:30"},
            {"text": "ساعة", "callback_data": f"a38:{ticker}:H"},
            {"text": "4س", "callback_data": f"a38:{ticker}:4H"},
        ],
        [
            {"text": "يومي", "callback_data": f"a38:{ticker}:D"},
            {"text": "أسبوعي", "callback_data": f"a38:{ticker}:W"},
            {"text": "شهري", "callback_data": f"a38:{ticker}:MO"},
        ],
    ]
    links = reference_links(spec)
    for index in range(0, len(links), 2):
        rows.append([{"text": f"↗️ {name}", "url": url} for name, url in links[index:index + 2]])
    rows.append([{"text": "🏠 الرئيسية", "callback_data": "menu:home"}])
    return {"inline_keyboard": rows}


def build_frame_menu_v38(market: str) -> dict[str, Any]:
    return {
        "inline_keyboard": [
            [
                {"text": "1 دقيقة", "callback_data": f"sf:{market}:1m:0:60"},
                {"text": "5 دقائق", "callback_data": f"sf:{market}:5m:0:60"},
                {"text": "15 دقيقة", "callback_data": f"sf:{market}:15m:0:60"},
            ],
            [
                {"text": "30 دقيقة", "callback_data": f"sf:{market}:30m:0:60"},
                {"text": "ساعة", "callback_data": f"sf:{market}:1h:0:60"},
                {"text": "4 ساعات", "callback_data": f"sf:{market}:4h:0:60"},
            ],
            [
                {"text": "يومي", "callback_data": f"sf:{market}:1d:0:60"},
                {"text": "أسبوعي", "callback_data": f"sf:{market}:1w:0:60"},
                {"text": "شهري", "callback_data": f"sf:{market}:1mo:0:60"},
            ],
            [{"text": "⬅️ الأسواق", "callback_data": "menu:scan"}],
        ]
    }


def build_frame_scan_buttons_v38(items: list[Any], market: str, frame_key: str, direction: int, min_score: int) -> dict[str, Any]:
    rows: list[list[dict[str, str]]] = []
    for item in items[:7]:
        rows.append([{"text": f"📊 {item.display_symbol}", "callback_data": f"a38:{item.display_symbol}:A"}])
    rows += [
        [
            {"text": "⬆️ صعود", "callback_data": f"sf:{market}:{frame_key}:1:{min_score}"},
            {"text": "⬇️ هبوط", "callback_data": f"sf:{market}:{frame_key}:-1:{min_score}"},
            {"text": "↕️ الكل", "callback_data": f"sf:{market}:{frame_key}:0:{min_score}"},
        ],
        [
            {"text": "قوة 60+", "callback_data": f"sf:{market}:{frame_key}:{direction}:60"},
            {"text": "قوة 70+", "callback_data": f"sf:{market}:{frame_key}:{direction}:70"},
            {"text": "قوة 80+", "callback_data": f"sf:{market}:{frame_key}:{direction}:80"},
        ],
        [
            {"text": "🔄 تحديث", "callback_data": f"sf:{market}:{frame_key}:{direction}:{min_score}"},
            {"text": "🕒 الفواصل", "callback_data": f"market:{market}"},
            {"text": "🏠 الرئيسية", "callback_data": "menu:home"},
        ],
    ]
    return {"inline_keyboard": rows}


def frame_label(frame_key: str | None) -> str:
    return FRAME_SPECS[frame_key].label if frame_key in FRAME_SPECS else "جميع الفواصل من دقيقة إلى شهر"
