from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from typing import Any

from .audited_runtime import AuditedDatabase
from .market import classify_market
from .models import AlertEvent, TradingViewAlert


_ACTIVE_STATUSES = {"ACTIVE", "TARGET_1", "TARGET_2"}
_TARGET_RANK = {
    AlertEvent.TARGET_1: 1,
    AlertEvent.TARGET_2: 2,
    AlertEvent.TARGET_3: 3,
}
_STATUS_RANK = {
    "ACTIVE": 0,
    "TARGET_1": 1,
    "TARGET_2": 2,
    "COMPLETED": 3,
}


class VerifiedDatabase(AuditedDatabase):
    """SQLite runtime with durable Telegram input and monotonic plans."""

    async def record_alert(
        self, payload: TradingViewAlert
    ) -> tuple[int, bool, str]:
        if payload.event_time_ms is None:
            bucket_ms = int(time.time() // 60 * 60_000)
            payload = payload.model_copy(update={"event_time_ms": bucket_ms})
        async with self._lock:
            return await asyncio.to_thread(self._record_verified_sync, payload)

    @staticmethod
    def _event_uid(payload: TradingViewAlert) -> tuple[str, str]:
        raw = payload.model_dump_json(by_alias=False)
        return hashlib.sha256(raw.encode()).hexdigest(), raw

    def _record_verified_sync(
        self, payload: TradingViewAlert
    ) -> tuple[int, bool, str]:
        uid, raw = self._event_uid(payload)
        market = classify_market(payload.tickerid, payload.instrument_type)
        now = self._now()
        event_ms = int(payload.event_time_ms or 0)
        key = f"{payload.tickerid}|{payload.timeframe}|{payload.direction}"

        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            try:
                cursor = conn.execute(
                    "INSERT INTO events(uid,received_at,market,tickerid,timeframe,raw_json) "
                    "VALUES(?,?,?,?,?,?)",
                    (uid, now, market, payload.tickerid, payload.timeframe, raw),
                )
                event_id = int(cursor.lastrowid)
            except sqlite3.IntegrityError:
                row = conn.execute(
                    "SELECT id FROM events WHERE uid=?", (uid,)
                ).fetchone()
                return int(row["id"]), False, market

            if payload.event == AlertEvent.FAKEOUT:
                return event_id, True, market

            current = conn.execute(
                "SELECT * FROM opportunities WHERE key=?", (key,)
            ).fetchone()

            if payload.event in {AlertEvent.NEW_LONG, AlertEvent.NEW_SHORT}:
                if current and event_ms < int(current["event_time_ms"] or 0):
                    return event_id, False, market
                conn.execute(
                    """UPDATE opportunities
                    SET status='CANCELLED',last_event='SUPERSEDED',updated_at=?,event_time_ms=?
                    WHERE tickerid=? AND timeframe=? AND direction<>?
                      AND status IN ('ACTIVE','TARGET_1','TARGET_2')
                      AND event_time_ms<=?""",
                    (
                        now,
                        event_ms,
                        payload.tickerid,
                        payload.timeframe,
                        payload.direction,
                        event_ms,
                    ),
                )
                conn.execute(
                    """INSERT INTO opportunities(
                        key,event_id,market,tickerid,ticker,timeframe,source,direction,
                        entry,stop,target1,target2,target3,target_count,score,score_max,
                        counter_trend,status,last_event,opened_at,updated_at,event_time_ms
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(key) DO UPDATE SET
                        event_id=excluded.event_id,market=excluded.market,
                        tickerid=excluded.tickerid,ticker=excluded.ticker,
                        timeframe=excluded.timeframe,source=excluded.source,
                        direction=excluded.direction,entry=excluded.entry,
                        stop=excluded.stop,target1=excluded.target1,
                        target2=excluded.target2,target3=excluded.target3,
                        target_count=excluded.target_count,score=excluded.score,
                        score_max=excluded.score_max,
                        counter_trend=excluded.counter_trend,status='ACTIVE',
                        last_event=excluded.last_event,opened_at=excluded.opened_at,
                        updated_at=excluded.updated_at,event_time_ms=excluded.event_time_ms""",
                    (
                        key,
                        event_id,
                        market,
                        payload.tickerid,
                        payload.ticker,
                        payload.timeframe,
                        payload.source,
                        payload.direction,
                        payload.entry,
                        payload.stop,
                        payload.target1,
                        payload.target2,
                        payload.target3,
                        payload.target_count,
                        payload.score,
                        payload.score_max,
                        int(payload.counter_trend),
                        "ACTIVE",
                        payload.event.value,
                        now,
                        now,
                        event_ms,
                    ),
                )
                return event_id, True, market

            if not current or str(current["status"]) not in _ACTIVE_STATUSES:
                return event_id, False, market
            if event_ms < int(current["event_time_ms"] or 0):
                return event_id, False, market

            if payload.event in _TARGET_RANK:
                target_rank = _TARGET_RANK[payload.event]
                declared = int(current["target_count"])
                current_rank = _STATUS_RANK.get(str(current["status"]), -1)
                if target_rank > declared or target_rank <= current_rank:
                    return event_id, False, market
                new_status = (
                    "COMPLETED"
                    if target_rank >= declared
                    else f"TARGET_{target_rank}"
                )
            elif payload.event == AlertEvent.STOP:
                new_status = "STOPPED"
            elif payload.event == AlertEvent.CANCELLED:
                new_status = "CANCELLED"
            else:
                return event_id, False, market

            conn.execute(
                """UPDATE opportunities
                SET event_id=?,status=?,last_event=?,updated_at=?,event_time_ms=?
                WHERE key=?""",
                (
                    event_id,
                    new_status,
                    payload.event.value,
                    now,
                    event_ms,
                    key,
                ),
            )
            return event_id, True, market

    # ------------------------------------------------------------------
    # Durable Telegram inbox.  The webhook acknowledges only after the
    # update has been committed to SQLite; a restart can then retry safely.
    async def enqueue_telegram_update(
        self, update_id: int, payload: dict[str, Any]
    ) -> bool:
        async with self._lock:
            return await asyncio.to_thread(
                self._enqueue_telegram_update_sync, update_id, payload
            )

    def _enqueue_telegram_update_sync(
        self, update_id: int, payload: dict[str, Any]
    ) -> bool:
        now = self._now()
        raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        with self._connect() as conn:
            try:
                conn.execute(
                    """INSERT INTO telegram_inbox(
                        update_id,payload_json,status,attempts,next_attempt_at,
                        received_at,updated_at
                    ) VALUES(?,?,'PENDING',0,?,?,?)""",
                    (update_id, raw, now, now, now),
                )
                return True
            except sqlite3.IntegrityError:
                return False

    async def pending_telegram_updates(
        self, limit: int = 10
    ) -> list[dict[str, Any]]:
        async with self._lock:
            return await asyncio.to_thread(
                self._pending_telegram_updates_sync, limit
            )

    def _pending_telegram_updates_sync(
        self, limit: int
    ) -> list[dict[str, Any]]:
        now = self._now()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            rows = conn.execute(
                """SELECT update_id,payload_json,attempts
                FROM telegram_inbox
                WHERE status='PENDING' AND next_attempt_at<=?
                ORDER BY update_id LIMIT ?""",
                (now, max(1, min(100, limit))),
            ).fetchall()
            for row in rows:
                conn.execute(
                    "UPDATE telegram_inbox SET status='PROCESSING',updated_at=? "
                    "WHERE update_id=?",
                    (now, int(row["update_id"])),
                )
            return [
                {
                    "update_id": int(row["update_id"]),
                    "payload": json.loads(str(row["payload_json"])),
                    "attempts": int(row["attempts"]),
                }
                for row in rows
            ]

    async def mark_telegram_update_done(self, update_id: int) -> None:
        async with self._lock:
            await asyncio.to_thread(
                self._mark_telegram_update_done_sync, update_id
            )

    def _mark_telegram_update_done_sync(self, update_id: int) -> None:
        now = self._now()
        with self._connect() as conn:
            conn.execute(
                "UPDATE telegram_inbox SET status='DONE',updated_at=?,last_error=NULL "
                "WHERE update_id=?",
                (now, update_id),
            )
            # Keep the durable inbox bounded without deleting pending or failed
            # updates that may still need operator attention.
            if update_id % 250 == 0:
                cutoff = (
                    datetime.now(timezone.utc) - timedelta(days=14)
                ).isoformat()
                conn.execute(
                    "DELETE FROM telegram_inbox "
                    "WHERE status='DONE' AND updated_at<?",
                    (cutoff,),
                )

    async def mark_telegram_update_failed(
        self, update_id: int, attempts: int, error: str
    ) -> None:
        async with self._lock:
            await asyncio.to_thread(
                self._mark_telegram_update_failed_sync,
                update_id,
                attempts,
                error,
            )

    def _mark_telegram_update_failed_sync(
        self, update_id: int, attempts: int, error: str
    ) -> None:
        retry_at = datetime.now(timezone.utc) + timedelta(
            seconds=min(300, 2 ** min(attempts, 8))
        )
        status = "FAILED" if attempts >= 10 else "PENDING"
        with self._connect() as conn:
            conn.execute(
                """UPDATE telegram_inbox
                SET status=?,attempts=?,next_attempt_at=?,updated_at=?,last_error=?
                WHERE update_id=?""",
                (
                    status,
                    attempts,
                    retry_at.isoformat(),
                    self._now(),
                    error[:500],
                    update_id,
                ),
            )

    async def claim_first_admin(self, user_id: int, chat_id: int) -> bool:
        async with self._lock:
            return await asyncio.to_thread(
                self._claim_first_admin_sync, user_id, chat_id
            )

    def _claim_first_admin_sync(self, user_id: int, chat_id: int) -> bool:
        now = self._now()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            if conn.execute("SELECT 1 FROM admins LIMIT 1").fetchone():
                return False
            conn.execute(
                "INSERT INTO admins(user_id,chat_id,created_at,last_seen_at) "
                "VALUES(?,?,?,?)",
                (user_id, chat_id, now, now),
            )
            return True

    def _health_sync(self) -> dict[str, Any]:
        snapshot = super()._health_sync()
        with self._connect() as conn:
            pending = conn.execute(
                "SELECT COUNT(*) FROM telegram_inbox WHERE status='PENDING'"
            ).fetchone()[0]
            failed = conn.execute(
                "SELECT COUNT(*) FROM telegram_inbox WHERE status='FAILED'"
            ).fetchone()[0]
        return {
            **snapshot,
            "pending_telegram_updates": int(pending),
            "failed_telegram_updates": int(failed),
        }


__all__ = ["VerifiedDatabase"]
