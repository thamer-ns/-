from __future__ import annotations

import re

from .opportunity_format import (
    format_analysis_v37 as _base_format_analysis,
    format_scan_v37,
    prioritize_scan_report,
    select_primary_frame,
)
from .technical import LiveAnalysis


_ENTRY_SECTION = re.compile(
    r"شرط الدخول: <b>.*?</b>\n"
    r"(?:منطقة التنفيذ: <code>.*?</code>\n)?",
    flags=re.DOTALL,
)


def format_analysis_v37(item: LiveAnalysis) -> str:
    """Removes fresh-entry language from plans already in target tracking."""

    primary = select_primary_frame(item)
    text = _base_format_analysis(item)
    if "فرصة قائمة للمتابعة" not in primary.plan_state:
        return text

    text = text.replace(
        "<b>🎯 خطة الصفقة</b>",
        "<b>🎯 خطة المتابعة</b>",
        1,
    )
    text = _ENTRY_SECTION.sub(
        "الحالة: <b>الخطة للمتابعة وليست دخولًا جديدًا؛ "
        "راقب الهدف التالي ووقف الإلغاء.</b>\n",
        text,
        count=1,
    )
    text = text.replace(
        "الدخول: <b>",
        "الدخول الأصلي: <b>",
        1,
    )
    return text


__all__ = [
    "format_analysis_v37",
    "format_scan_v37",
    "prioritize_scan_report",
    "select_primary_frame",
]
