from __future__ import annotations

import html
import math
import re
from dataclasses import replace
from datetime import timezone

from .market_data import ScanReport
from .opportunity_v37 import opportunity_state_rank, select_primary_frame
from .technical import FrameAnalysis, LiveAnalysis


def _price(value: float | None) -> str:
    if value is None:
        return "—"
    return f"{value:.5f}".rstrip("0").rstrip(".")


def _percent(from_value: float, to_value: float) -> float:
    if from_value <= 0:
        return 0.0
    return (to_value - from_value) / from_value * 100.0


def _progress_count(frame: FrameAnalysis) -> int:
    for value in frame.reasons:
        match = re.search(r"تقدم الخطة:\s*(\d+)/3", value)
        if match:
            return max(0, min(3, int(match.group(1))))
    match = re.search(r"تحقق الهدف\s+(\d)", frame.plan_state)
    return int(match.group(1)) if match else 0


def _state_icon(frame: FrameAnalysis) -> str:
    state = frame.plan_state
    if "فرصة قائمة" in state or "دخول قائم" in state:
        return "🚀"
    if "إعادة اختبار" in state:
        return "🔄"
    if "فرصة مشروطة" in state:
        return "⏳"
    if "الخطة قائمة" in state:
        return "📌"
    if "مكتملة" in state:
        return "✅"
    if "منتهية" in state:
        return "🛑"
    if frame.direction > 0:
        return "🟢"
    if frame.direction < 0:
        return "🔴"
    return "🟡"


def _action_text(frame: FrameAnalysis) -> str:
    if frame.direction > 0:
        return "شراء فني / صعود"
    if frame.direction < 0:
        return "هبوط / بيع فني"
    return "محايد"


def _entry_condition(frame: FrameAnalysis) -> str:
    side = "فوق" if frame.direction > 0 else "تحت"
    if "فرصة مشروطة" in frame.plan_state:
        return (
            f"إغلاق شمعة {frame.frame} {side} {_price(frame.entry)}"
        )
    if "الخطة قائمة — الدخول الجديد متأخر" in frame.plan_state:
        return (
            f"انتظار عودة السعر إلى قرب {_price(frame.entry)} "
            "بدل المطاردة"
        )
    return f"منطقة دخول مرجعية قرب {_price(frame.entry)}"


def _entry_zone(frame: FrameAnalysis) -> tuple[float, float] | None:
    if frame.entry is None:
        return None
    width = max(frame.atr * 0.15, frame.entry * 0.0008)
    if frame.direction > 0:
        return frame.entry, frame.entry + width
    return frame.entry - width, frame.entry


def _bars_for_distance(
    distance: float, atr: float
) -> tuple[int, int]:
    units = max(0.25, distance / max(atr, 1e-9))
    lower = max(1, math.ceil(units * 1.5))
    upper = max(lower + 1, math.ceil(units * 4.5))
    return lower, upper


def _sessions_from_bars(
    frame_name: str, bars: tuple[int, int]
) -> tuple[float, float]:
    if frame_name == "15 دقيقة":
        per_session = 26.0
    elif frame_name == "ساعة":
        per_session = 6.0
    else:
        per_session = 1.0
    return bars[0] / per_session, bars[1] / per_session


def _human_window(sessions: tuple[float, float]) -> str:
    lower, upper = sessions
    if upper <= 0.5:
        return "عدة ساعات"
    if upper <= 1.25:
        return "خلال جلسة تقريبًا"
    if upper <= 3:
        return (
            f"نحو {max(1, math.floor(lower))}-"
            f"{math.ceil(upper)} جلسات"
        )
    if upper <= 12:
        days_low = max(1, math.floor(lower))
        days_high = math.ceil(upper)
        weeks_high = max(1, math.ceil(days_high / 5))
        return (
            f"نحو {days_low}-{days_high} جلسات "
            f"(حتى قرابة {weeks_high} أسبوع)"
        )
    weeks_low = max(1, math.floor(lower / 5))
    weeks_high = max(weeks_low + 1, math.ceil(upper / 5))
    return f"نحو {weeks_low}-{weeks_high} أسابيع"


def duration_estimate(frame: FrameAnalysis) -> str:
    if frame.entry is None or not frame.targets or frame.atr <= 0:
        return "لا تتوفر مدة تقديرية قبل اكتمال الخطة السعرية"
    progress = _progress_count(frame)
    next_index = min(progress, len(frame.targets) - 1)
    conditional = "فرصة مشروطة" in frame.plan_state
    reference = frame.entry if conditional else frame.price
    next_distance = abs(frame.targets[next_index] - reference)
    full_distance = abs(frame.targets[-1] - reference)
    next_window = _human_window(
        _sessions_from_bars(
            frame.frame,
            _bars_for_distance(next_distance, frame.atr),
        )
    )
    full_window = _human_window(
        _sessions_from_bars(
            frame.frame,
            _bars_for_distance(full_distance, frame.atr),
        )
    )
    if next_index == len(frame.targets) - 1:
        return f"الهدف المتبقي: {full_window} إذا استمر الزخم"
    return (
        f"الهدف التالي: {next_window} | "
        f"اكتمال الخطة: {full_window} إذا استمر الزخم"
    )


def _frame_line(frame: FrameAnalysis) -> str:
    if frame.direction > 0:
        icon = "🟢"
    elif frame.direction < 0:
        icon = "🔴"
    else:
        icon = "🟡"
    plan = ""
    if frame.entry is not None:
        if "فرصة مشروطة" in frame.plan_state:
            plan = f" | زناد {_price(frame.entry)}"
        elif opportunity_state_rank(frame) >= 50:
            plan = f" | خطة قائمة من {_price(frame.entry)}"
    return (
        f"• {icon} <b>{html.escape(frame.frame)}</b>: "
        f"{html.escape(frame.trend)} ({frame.confidence}%) | "
        f"دعم {_price(frame.support)} | "
        f"مقاومة {_price(frame.resistance)}{plan}"
    )


def _target_lines(frame: FrameAnalysis) -> list[str]:
    progress = _progress_count(frame)
    lines: list[str] = []
    for index, target in enumerate(frame.targets, 1):
        marker = "✅" if index <= progress else "🎯"
        change = _percent(frame.entry or target, target)
        lines.append(
            f"{marker} الهدف {index}: <b>{_price(target)}</b> "
            f"({change:+.2f}%)"
        )
    return lines


def _compact_analysis(
    item: LiveAnalysis, primary: FrameAnalysis
) -> str:
    lines = [
        f"📊 <b>{html.escape(item.display_symbol)}</b>",
        f"السعر: <b>{_price(item.price)} "
        f"{html.escape(item.currency)}</b>",
        f"{_state_icon(primary)} "
        f"<b>{html.escape(primary.plan_state)}</b>",
        f"الفاصل: <b>{html.escape(primary.frame)}</b> | "
        f"قوة التوافق: <b>{primary.confidence}/100</b>",
    ]
    if (
        primary.entry is not None
        and primary.stop is not None
        and primary.targets
    ):
        lines.extend(
            [
                f"الدخول: <b>{_price(primary.entry)}</b>",
                f"الوقف: <b>{_price(primary.stop)}</b>",
                "الأهداف: "
                + " • ".join(
                    _price(target) for target in primary.targets
                ),
                f"المدة: {html.escape(duration_estimate(primary))}",
            ]
        )
    lines.append(
        "<i>المدة تقريبية والخطة تُلغى بالوقف.</i>"
    )
    return "\n".join(lines)


def format_analysis_v37(item: LiveAnalysis) -> str:
    primary = select_primary_frame(item)
    if item.direction > 0:
        overall_icon = "🟢"
    elif item.direction < 0:
        overall_icon = "🔴"
    else:
        overall_icon = "🟡"
    lines = [
        f"📊 <b>{html.escape(item.display_symbol)} — "
        f"{html.escape(item.name)}</b>",
        f"السعر الحالي: <b>{_price(item.price)} "
        f"{html.escape(item.currency)}</b>",
        "",
        "<b>الخلاصة التنفيذية</b>",
        f"{_state_icon(primary)} "
        f"<b>{html.escape(primary.plan_state)}</b>",
        f"الاتجاه: <b>{html.escape(_action_text(primary))}</b> "
        f"على فاصل <b>{html.escape(primary.frame)}</b>",
        f"قوة التوافق: <b>{primary.confidence}/100</b> | "
        f"الاتجاه العام: {overall_icon} "
        f"{html.escape(item.recommendation)}",
        f"توافق الفواصل: <b>{html.escape(item.alignment)}</b>",
        "",
    ]

    if (
        primary.entry is not None
        and primary.stop is not None
        and primary.targets
    ):
        zone = _entry_zone(primary)
        risk_percent = abs(
            _percent(primary.entry, primary.stop)
        )
        final_rr = abs(
            primary.targets[-1] - primary.entry
        ) / max(abs(primary.entry - primary.stop), 1e-9)
        lines.extend(
            [
                "<b>🎯 خطة الصفقة</b>",
                f"شرط الدخول: "
                f"<b>{html.escape(_entry_condition(primary))}</b>",
            ]
        )
        if zone:
            lines.append(
                f"منطقة التنفيذ: <code>{_price(zone[0])} - "
                f"{_price(zone[1])}</code>"
            )
        lines.extend(
            [
                f"وقف الإلغاء: <b>{_price(primary.stop)}</b> "
                f"(مخاطرة سعرية تقارب {risk_percent:.2f}%)",
                *_target_lines(primary),
                f"العائد/المخاطرة: الهدف الأول "
                f"{primary.risk_reward or 0:.2f}R | "
                f"الهدف الثالث {final_rr:.2f}R",
                f"⏱ <b>المدة التقديرية:</b> "
                f"{html.escape(duration_estimate(primary))}",
                "",
            ]
        )
    else:
        lines.extend(
            [
                "<b>🎯 خطة الصفقة</b>",
                "لا توجد حاليًا خطة رقمية مؤهلة بدخول ووقف "
                "وأهداف؛ تُعرض المستويات للمراقبة فقط.",
                f"الدعم الأقرب: <b>{_price(primary.support)}</b> | "
                f"المقاومة الأقرب: "
                f"<b>{_price(primary.resistance)}</b>",
                "",
            ]
        )

    lines.append("<b>🧭 قراءة الفواصل</b>")
    lines.extend(_frame_line(frame) for frame in item.frames)

    reasons = list(dict.fromkeys(primary.reasons))[:5]
    warnings = list(dict.fromkeys(primary.warnings))[:4]
    if reasons:
        lines.extend(
            [
                "",
                "<b>لماذا ظهرت الفرصة؟</b>",
                "• "
                + "\n• ".join(
                    html.escape(value) for value in reasons
                ),
            ]
        )
    if warnings:
        lines.extend(
            [
                "",
                "<b>⚠️ ملاحظات المخاطر</b>",
                "• "
                + "\n• ".join(
                    html.escape(value) for value in warnings
                ),
            ]
        )

    updated = item.updated_at.astimezone(timezone.utc).strftime(
        "%Y-%m-%d %H:%M UTC"
    )
    lines.extend(
        [
            "",
            f"مصدر الشموع: <b>{html.escape(item.feed_source)}</b> | "
            f"آخر إغلاق: <code>{updated}</code>",
            "<i>المدة تقدير تقريبي مبني على الفاصل والمسافة "
            "وATR، وليست موعدًا أو ضمانًا. الخطة تُلغى بالوقف "
            "وتبقى قائمة ما لم تتحقق أو تُلغَ.</i>",
        ]
    )
    message = "\n".join(lines)
    return (
        message
        if len(message) <= 4096
        else _compact_analysis(item, primary)
    )


def prioritize_scan_report(report: ScanReport) -> ScanReport:
    items = sorted(
        report.items,
        key=lambda item: (
            opportunity_state_rank(select_primary_frame(item)),
            item.confidence,
            abs(item.score - 50),
        ),
        reverse=True,
    )
    return replace(report, items=tuple(items))


def _short_state(frame: FrameAnalysis) -> str:
    state = frame.plan_state
    for prefix in (
        "فرصة قائمة",
        "دخول قائم",
        "إعادة اختبار",
        "الخطة قائمة",
        "فرصة مشروطة",
    ):
        if prefix in state:
            return prefix
    return state.split("—", 1)[0].strip()


def format_scan_v37(report: ScanReport) -> str:
    report = prioritize_scan_report(report)
    names = {
        "SAUDI": "أفضل فرص السوق السعودي",
        "US": "أفضل فرص السوق الأمريكي",
        "US_OPTIONS": "فرص الأوبشن الأمريكي CALL / PUT",
        "FOREX": "أفضل فرص العملات",
        "CRYPTO": "أفضل فرص العملات الرقمية",
    }
    frame_name = (
        "ساعة"
        if report.horizon in {"INTRADAY", "SWING"}
        else "يومي"
    )
    if report.direction > 0:
        direction_name = "صاعدة"
    elif report.direction < 0:
        direction_name = "هابطة"
    else:
        direction_name = "صاعدة وهابطة"
    lines = [
        f"🔎 <b>{names.get(report.market, report.market)}</b>",
        f"النطاق: <b>{html.escape(report.universe_label)}</b>",
        f"الفاصل: <b>{frame_name}</b> | "
        f"الاتجاه: <b>{direction_name}</b>",
        f"تم تحليل: "
        f"<b>{report.analyzed_symbols}/{report.total_symbols}</b>",
        "",
    ]
    if not report.items:
        lines.extend(
            [
                "لا توجد الآن خطة دخول أو فرصة مشروطة "
                "اجتازت الحد المطلوب.",
                "عدم ظهور نتيجة أفضل من اختراع صفقة ضعيفة.",
            ]
        )
    for index, item in enumerate(report.items[:10], 1):
        frame = select_primary_frame(item)
        if frame.direction > 0:
            icon = "🟢"
        elif frame.direction < 0:
            icon = "🔴"
        else:
            icon = "🟡"
        option_side = ""
        if report.market == "US_OPTIONS":
            option_side = " CALL" if frame.direction > 0 else " PUT"
        lines.append(
            f"{index}. {icon}<b>{option_side} "
            f"{html.escape(item.display_symbol)}</b> — "
            f"{html.escape(_short_state(frame))} | "
            f"{frame.frame} | قوة {frame.confidence}/100"
        )
        if (
            frame.entry is not None
            and frame.stop is not None
            and frame.targets
        ):
            lines.append(
                f"   دخول {_price(frame.entry)} | "
                f"وقف {_price(frame.stop)} | "
                f"T1 {_price(frame.targets[0])}"
            )
        else:
            lines.append(
                f"   دعم {_price(frame.support)} | "
                f"مقاومة {_price(frame.resistance)}"
            )
    if report.failed_symbols:
        lines.extend(
            [
                "",
                f"تعذر جلب {report.failed_symbols} رمزًا "
                "من المصدر في هذه الجولة.",
            ]
        )
    lines.extend(
        [
            "",
            "<i>الترتيب يقدّم الخطط القائمة ثم إعادة الاختبار "
            "ثم الفرص المشروطة. افتح الرمز لرؤية جميع "
            "الأهداف والمدة وتوافق الفواصل.</i>",
        ]
    )
    message = "\n".join(lines)
    if len(message) <= 4096:
        return message
    compact = [*lines[:5]]
    compact.extend(lines[5:25])
    compact.append("<i>عُرضت أعلى النتائج بسبب حد طول Telegram.</i>")
    return "\n".join(compact)
