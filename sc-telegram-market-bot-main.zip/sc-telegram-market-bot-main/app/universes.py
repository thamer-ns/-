from __future__ import annotations

import csv
import io
import re
import time

import httpx

# Main Market equity symbols collected from the Saudi Exchange issuer directory.
# REITs, ETFs, CEFs and Nomu symbols are intentionally excluded from the stock scan.
SAUDI_MAIN_MARKET: tuple[str, ...] = tuple(dict.fromkeys(
    """
1010 1020 1030 1050 1060 1080 1111 1120 1140 1150 1180 1182 1183
1201 1202 1210 1211 1212 1213 1214 1301 1302 1303 1304 1320 1321 1322
1323 1324 1810 1820 1830 1831 1832 1833 1834 1835 2001 2010 2020 2030
2040 2050 2060 2070 2080 2081 2082 2083 2084 2090 2100 2110 2120 2130
2140 2150 2160 2170 2180 2190 2200 2210 2220 2222 2223 2230 2240 2250
2270 2280 2281 2282 2283 2284 2285 2286 2287 2288 2290 2300 2310 2320
2330 2340 2350 2360 2370 2380 2381 2382 3002 3003 3004 3005 3007 3008
3010 3020 3030 3040 3050 3060 3080 3090 3091 3092 4001 4002 4003 4004
4005 4006 4007 4008 4009 4011 4012 4013 4014 4015 4016 4017 4018 4019
4020 4021 4030 4031 4040 4050 4051 4061 4070 4071 4072 4080 4081 4082
4083 4084 4090 4100 4110 4130 4140 4141 4142 4143 4144 4145 4146 4147
4148 4150 4160 4161 4162 4163 4164 4165 4170 4180 4190 4191 4192 4193
4194 4200 4210 4220 4230 4240 4250 4260 4261 4262 4263 4264 4265 4270
4280 4290 4291 4292 4300 4310 4320 4321 4322 4323 4324 4325 4326 4327
5110 6001 6002 6004 6010 6012 6013 6014 6015 6016 6017 6018 6019 6020
6040 6050 6060 6070 6090 7010 7020 7030 7040 7200 7201 7202 7203 7204
7205 7211 8010 8012 8020 8030 8040 8050 8060 8070 8100 8120 8150 8160
8170 8180 8190 8200 8210 8230 8240 8250 8260 8280 8300 8310 8311 8313
""".split()
))

# Focused U.S. universe requested by the user from the attached Finviz screen:
# USA mega-cap, optionable names priced above $70. The bot scans only these
# symbols for U.S. stock and option-underlying searches. Direct /analyze still
# accepts any valid symbol and is not restricted to this list.
US_FOCUS_UNIVERSE: tuple[str, ...] = tuple(dict.fromkeys(
    """
AAPL ABBV AMAT AMD AMZN ANET AVGO AXP BRK-B C CAT COST CSCO CVX DELL GE GEV
GOOG GOOGL GS HD INTC JNJ JPM KLAC KO LLY LRCX MA META MRK MS MSFT MU NVDA
ORCL PANW PG PLTR PM RTX SNDK SPCX TMUS TSLA TXN UNH V WFC WMT XOM
""".split()
))

# Backwards-compatible name used by the status endpoints.
US_OPTIONS_PRIORITY: tuple[str, ...] = US_FOCUS_UNIVERSE

FOREX_UNIVERSE: tuple[str, ...] = (
    "EURUSD", "GBPUSD", "USDJPY", "USDCHF", "AUDUSD", "USDCAD", "NZDUSD",
)
CRYPTO_UNIVERSE: tuple[str, ...] = (
    "BTCUSD", "ETHUSD", "SOLUSD", "XRPUSD", "BNBUSD", "ADAUSD",
)

CBOE_UNDERLYING_CSV = (
    "https://cdn.cboe.com/data/us/options/market_statistics/"
    "symbol_reference/cone-underlying.csv"
)
_SYMBOL_RE = re.compile(r"^[A-Z][A-Z0-9.\-/]{0,11}$")


def _cboe_symbol(symbol: str) -> str:
    # Yahoo/Finviz commonly use BRK-B while option reference files commonly use BRK.B.
    return symbol.upper().replace("-", ".").replace("/", ".")


class UniverseCatalog:
    """Provides focused scan universes with a resilient Cboe eligibility check."""

    def __init__(self, timeout: float = 12.0, cache_seconds: int = 21_600) -> None:
        self.timeout = timeout
        self.cache_seconds = cache_seconds
        self._cboe_cache: tuple[float, frozenset[str]] | None = None
        self._cboe_failure_until = 0.0

    @staticmethod
    def _parse_cboe_symbols(text: str) -> frozenset[str]:
        symbols: set[str] = set()
        reader = csv.reader(io.StringIO(text))
        for row_index, row in enumerate(reader):
            for cell in row[:5]:
                value = cell.strip().upper().replace(" ", "")
                if row_index == 0 and value in {
                    "SYMBOL", "UNDERLYING", "UNDERLYINGSYMBOL", "ROOT",
                }:
                    continue
                if _SYMBOL_RE.fullmatch(value):
                    symbols.add(_cboe_symbol(value))
        return frozenset(symbols)

    async def cboe_option_underlyings(self) -> frozenset[str]:
        now = time.monotonic()
        if self._cboe_cache and now - self._cboe_cache[0] <= self.cache_seconds:
            return self._cboe_cache[1]
        if now < self._cboe_failure_until:
            return frozenset()
        try:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                response = await client.get(
                    CBOE_UNDERLYING_CSV,
                    headers={"User-Agent": "SC-Market-Compass/4.1"},
                )
                response.raise_for_status()
            parsed = self._parse_cboe_symbols(response.text)
            if len(parsed) >= 100:
                self._cboe_cache = (now, parsed)
                return parsed
        except (httpx.HTTPError, ValueError, csv.Error):
            pass
        # Avoid hammering Cboe on every scan while it is temporarily down.
        self._cboe_failure_until = now + min(900, self.cache_seconds)
        return frozenset()

    async def symbols(self, market: str) -> tuple[str, ...]:
        normalized = market.upper()
        if normalized == "SAUDI":
            return SAUDI_MAIN_MARKET
        if normalized == "US":
            return US_FOCUS_UNIVERSE
        if normalized == "US_OPTIONS":
            eligible = await self.cboe_option_underlyings()
            if eligible:
                filtered = tuple(
                    symbol for symbol in US_FOCUS_UNIVERSE
                    if _cboe_symbol(symbol) in eligible
                )
                if filtered:
                    return filtered
            # Cboe verification is a safety enhancement, not a single point of failure.
            # The curated Finviz list was already selected as optionable.
            return US_FOCUS_UNIVERSE
        if normalized == "FOREX":
            return FOREX_UNIVERSE
        if normalized == "CRYPTO":
            return CRYPTO_UNIVERSE
        return ()


UNIVERSE_LABELS = {
    "SAUDI": "أسهم السوق السعودي الرئيسي",
    "US": "القائمة الأمريكية المركزة — 51 سهمًا",
    "US_OPTIONS": "نفس القائمة الأمريكية المركزة مع تحقق أهلية Cboe للأوبشن",
    "FOREX": "أزواج العملات الرئيسية",
    "CRYPTO": "العملات الرقمية الرئيسية",
}
