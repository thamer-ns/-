from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx

from .db import Database
from .models import Opportunity, TradingViewAlert
from .telegram import TelegramClient, validate_telegram_payload

logger = logging.getLogger(__name__)


class AuditedDatabase(Database):
    """Keeps retries idempotent and resolves old event buttons to current plans."""

    async def record_alert(
        self, payload: TradingViewAlert
    ) -> tuple[int, bool, str]:
        if payload.event_time_ms is None:
            bucket_ms = int(time.time() // 60 * 60_000)
            payload = payload.model_copy(
                update={"event_time_ms": bucket_ms}
            )
        return await super().record_alert(payload)

    async def claim_telegram_update(self, update_id: int) -> bool:
        claimed = await super().claim_telegram_update(update_id)
        if claimed and update_id % 250 == 0:
            await asyncio.to_thread(self._cleanup_telegram_updates_sync)
        return claimed

    def _cleanup_telegram_updates_sync(self) -> None:
        cutoff = (
            datetime.now(timezone.utc) - timedelta(days=14)
        ).isoformat()
        with self._connect() as conn:
            conn.execute(
                "DELETE FROM telegram_updates WHERE received_at<?",
                (cutoff,),
            )

    async def get_opportunity_by_event(
        self, event_id: int
    ) -> Opportunity | None:
        return await asyncio.to_thread(
            self._get_current_opportunity_sync, event_id
        )

    def _get_current_opportunity_sync(
        self, event_id: int
    ) -> Opportunity | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM opportunities WHERE event_id=?",
                (event_id,),
            ).fetchone()
            if row:
                return self._op(row)
            event = conn.execute(
                "SELECT raw_json FROM events WHERE id=?",
                (event_id,),
            ).fetchone()
            if not event:
                return None
            try:
                payload = TradingViewAlert.model_validate_json(
                    event["raw_json"]
                )
            except (ValueError, TypeError):
                return None
            if payload.direction not in (-1, 1):
                return None
            key = (
                f"{payload.tickerid}|{payload.timeframe}|"
                f"{payload.direction}"
            )
            current = conn.execute(
                "SELECT * FROM opportunities WHERE key=?",
                (key,),
            ).fetchone()
            return self._op(current) if current else None


class ReliableTelegramClient(TelegramClient):
    """Retries transient Telegram failures and keeps secrets out of logs."""

    async def _call(
        self, method: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        validate_telegram_payload(method, payload)
        last_error: Exception | None = None
        for attempt in range(3):
            try:
                response = await self.client.post(
                    f"{self.base_url}/{method}", json=payload
                )
                if response.status_code == 429:
                    try:
                        body = response.json()
                        retry_after = float(
                            (
                                (body.get("parameters") or {}).get(
                                    "retry_after"
                                )
                                or 1
                            )
                        )
                    except (ValueError, TypeError):
                        retry_after = 1.0
                    await asyncio.sleep(
                        min(5.0, max(0.5, retry_after))
                    )
                    continue
                if 500 <= response.status_code < 600:
                    await asyncio.sleep(0.5 * (2**attempt))
                    continue
                response.raise_for_status()
                data = response.json()
                if not data.get("ok"):
                    raise RuntimeError(
                        "Telegram API rejected "
                        f"{method}: {data.get('description', 'unknown error')}"
                    )
                return data
            except (
                httpx.TimeoutException,
                httpx.NetworkError,
                httpx.RemoteProtocolError,
            ) as exc:
                last_error = exc
                await asyncio.sleep(0.5 * (2**attempt))
            except Exception as exc:
                last_error = exc
                break
        raise RuntimeError(
            f"Telegram API call failed for {method}"
        ) from last_error

    async def set_commands(self) -> None:
        await self._call(
            "setMyCommands",
            {
                "commands": [
                    {
                        "command": "start",
                        "description": "فتح القائمة الرئيسية",
                    },
                    {
                        "command": "analyze",
                        "description": "تحليل رمز مع فاصل اختياري",
                    },
                    {
                        "command": "filters",
                        "description": "الفلاتر الفنية المتقدمة",
                    },
                    {
                        "command": "recommendations",
                        "description": "أفضل الفرص الصاعدة السعودية",
                    },
                    {
                        "command": "options",
                        "description": "أفضل اتجاهات CALL وPUT",
                    },
                    {
                        "command": "calls",
                        "description": "أفضل فرص CALL الأمريكية",
                    },
                    {
                        "command": "puts",
                        "description": "أفضل فرص PUT الأمريكية",
                    },
                    {
                        "command": "active",
                        "description": "خطط TradingView القائمة",
                    },
                    {
                        "command": "uslist",
                        "description": "عرض الأسهم الأمريكية الـ51",
                    },
                    {
                        "command": "scan",
                        "description": "اختيار السوق والفاصل والاتجاه",
                    },
                    {
                        "command": "saudi",
                        "description": "مسح السوق السعودي الرئيسي",
                    },
                    {
                        "command": "us",
                        "description": "مسح القائمة الأمريكية المركزة",
                    },
                    {
                        "command": "forex",
                        "description": "مسح العملات",
                    },
                    {
                        "command": "sources",
                        "description": "مصادر البيانات والتحقق",
                    },
                    {
                        "command": "status",
                        "description": "حالة الخادم والبيانات",
                    },
                    {
                        "command": "help",
                        "description": "شرح الاستخدام",
                    },
                ]
            },
        )
