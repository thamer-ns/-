from __future__ import annotations

import base64
import hashlib
import hmac
import math
import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Protocol
from urllib.parse import quote, quote_plus

import httpx

from .technical import Candle, MarketDataError, SymbolSpec


@dataclass(frozen=True, slots=True)
class ProviderResult:
    candles: list[Candle]
    metadata: dict[str, Any]
    provider_id: str


@dataclass(frozen=True, slots=True)
class SourceInfo:
    source_id: str
    name: str
    role: str
    coverage: str
    note: str


SOURCE_CATALOG = (
    SourceInfo(
        "binance",
        "Binance Spot",
        "feed",
        "العملات الرقمية الرئيسية",
        "مصدر الشموع الأول للعملات الرقمية عبر واجهة Spot الرسمية العامة، مع Yahoo كاحتياط.",
    ),
    SourceInfo(
        "webull",
        "Webull OpenAPI",
        "optional_feed",
        "الأسهم الأمريكية وبيانات الأوبشن",
        "مصدر رسمي اختياري؛ يحتاج WEBULL_APP_KEY وWEBULL_APP_SECRET واشتراك بيانات OpenAPI المناسب.",
    ),
    SourceInfo(
        "barchart",
        "Barchart OnDemand",
        "optional_feed",
        "الأسهم الأمريكية والشموع التاريخية",
        "مصدر رسمي اختياري؛ يحتاج BARCHART_API_KEY وصلاحية getHistory ضمن الاشتراك.",
    ),
    SourceInfo(
        "yahoo",
        "Yahoo Finance",
        "fallback_feed",
        "أسهم سعودية وأمريكية وعملات ومؤشرات ورقمية",
        "مصدر احتياطي مجاني وغير رسمي؛ قد يتأخر أو يتوقف مؤقتًا.",
    ),
    SourceInfo(
        "finviz",
        "Finviz",
        "reference_or_paid_api",
        "NASDAQ وNYSE وAMEX",
        "مرجع وفرز للقائمة الأمريكية المركزة؛ لم يُستخدم scraping.",
    ),
    SourceInfo(
        "tickerchart",
        "TickerChart",
        "reference",
        "السوق السعودي والأسواق الإقليمية",
        "مرجع سعودي؛ البيانات اللحظية مرتبطة بالاشتراك أو الوسيط ولا توجد API عامة موثقة للبوت.",
    ),
)


class CandleProvider(Protocol):
    provider_id: str

    async def fetch(self, spec: SymbolSpec, period: str, interval: str) -> ProviderResult:
        ...


def _finite_candle(
    timestamp: int,
    open_value: Any,
    high_value: Any,
    low_value: Any,
    close_value: Any,
    volume_value: Any = 0,
) -> Candle | None:
    try:
        candle = Candle(
            int(timestamp),
            float(open_value),
            float(high_value),
            float(low_value),
            float(close_value),
            float(volume_value or 0),
        )
    except (TypeError, ValueError):
        return None
    values = (candle.open, candle.high, candle.low, candle.close, candle.volume)
    return candle if all(math.isfinite(value) for value in values) else None


def _parse_timestamp(value: Any) -> int:
    if isinstance(value, (int, float)):
        numeric = float(value)
        return int(numeric / 1000 if numeric > 10_000_000_000 else numeric)
    text = str(value or "").strip()
    if not text:
        raise ValueError("empty timestamp")
    if text.isdigit():
        numeric = int(text)
        return numeric // 1000 if numeric > 10_000_000_000 else numeric
    parsed = datetime.fromisoformat(text.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return int(parsed.timestamp())


def _interval_seconds(interval: str) -> int:
    return {"15m": 900, "1h": 3600, "1d": 86400}.get(interval, 0)


class _BinanceSpotProvider:
    provider_id = "binance"

    def __init__(self, timeout: float) -> None:
        self.timeout = timeout
        self.base_url = os.getenv("BINANCE_API_BASE", "https://api.binance.com").rstrip("/")

    async def fetch(self, spec: SymbolSpec, period: str, interval: str) -> ProviderResult:
        if spec.asset_class != "crypto":
            raise MarketDataError("السوق غير مدعوم في Binance")
        pair = spec.display_symbol.replace("-", "").replace("/", "").upper()
        if pair.endswith("USD"):
            pair = pair[:-3] + "USDT"
        if interval not in {"15m", "1h", "1d"}:
            raise MarketDataError("الفاصل غير مدعوم في Binance")
        try:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                response = await client.get(
                    f"{self.base_url}/api/v3/klines",
                    params={"symbol": pair, "interval": interval, "limit": 1000},
                    headers={"User-Agent": "SC-Market-Compass/3.5"},
                )
                response.raise_for_status()
                rows = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise MarketDataError("تعذر جلب شموع Binance") from exc
        if not isinstance(rows, list):
            raise MarketDataError("استجابة Binance غير صالحة")
        candles: list[Candle] = []
        for row in rows:
            if not isinstance(row, list) or len(row) < 6:
                continue
            candle = _finite_candle(int(row[0]) // 1000, row[1], row[2], row[3], row[4], row[5])
            if candle:
                candles.append(candle)
        # Binance includes the currently forming bar. Remove it inside the provider,
        # including the daily bar because crypto trades continuously.
        seconds = _interval_seconds(interval)
        now = int(datetime.now(timezone.utc).timestamp())
        if candles and seconds and now < candles[-1].timestamp + seconds:
            candles.pop()
        if not candles:
            raise MarketDataError("لم تصل شموع صالحة من Binance")
        base_asset = pair.removesuffix("USDT")
        return ProviderResult(
            candles=candles,
            metadata={
                "longName": f"{base_asset}/USDT",
                "shortName": pair,
                "exchangeName": "Binance Spot",
                "currency": "USDT",
                "continuousMarket": True,
            },
            provider_id=self.provider_id,
        )


class _BarchartProvider:
    provider_id = "barchart"

    def __init__(self, api_key: str, timeout: float) -> None:
        self.api_key = api_key
        self.timeout = timeout
        self.disabled = False

    @staticmethod
    def _symbol(spec: SymbolSpec) -> str:
        return spec.display_symbol.replace("-", ".")

    async def fetch(self, spec: SymbolSpec, period: str, interval: str) -> ProviderResult:
        if self.disabled or spec.market != "US" or spec.asset_class != "stock":
            raise MarketDataError("السوق غير مدعوم أو Barchart غير مفعّل")
        now = datetime.now(timezone.utc)
        days = 730 if period.endswith("y") else int(period.removesuffix("d") or "60")
        history_type = "daily" if interval == "1d" else "minutes"
        params: dict[str, Any] = {
            "apikey": self.api_key,
            "symbol": self._symbol(spec),
            "type": history_type,
            "startDate": (now - timedelta(days=days + 10)).strftime("%Y%m%d%H%M%S"),
            "endDate": now.strftime("%Y%m%d") if interval == "1d" else now.strftime("%Y%m%d%H%M%S"),
            "maxRecords": 1200,
            "order": "asc",
            "splits": "true",
            "dividends": "true",
        }
        if interval != "1d":
            params["interval"] = 60 if interval == "1h" else 15
        try:
            async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                response = await client.get(
                    "https://ondemand.websol.barchart.com/getHistory.json",
                    params=params,
                    headers={"User-Agent": "SC-Market-Compass/3.5"},
                )
                if response.status_code in {401, 403}:
                    self.disabled = True
                response.raise_for_status()
                payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise MarketDataError("تعذر جلب شموع Barchart") from exc
        status = payload.get("status") or {}
        if int(status.get("code") or 0) != 200:
            raise MarketDataError(str(status.get("message") or "رفض Barchart الطلب"))
        candles: list[Candle] = []
        for row in payload.get("results") or []:
            try:
                timestamp = _parse_timestamp(row.get("timestamp") or row.get("tradingDay"))
            except ValueError:
                continue
            candle = _finite_candle(
                timestamp,
                row.get("open"),
                row.get("high"),
                row.get("low"),
                row.get("close"),
                row.get("volume"),
            )
            if candle:
                candles.append(candle)
        if not candles:
            raise MarketDataError("لم تصل شموع صالحة من Barchart")
        return ProviderResult(
            candles=sorted(candles, key=lambda item: item.timestamp),
            metadata={
                "longName": spec.display_symbol,
                "shortName": spec.display_symbol,
                "exchangeName": "Barchart OnDemand",
                "currency": "USD",
            },
            provider_id=self.provider_id,
        )


class _WebullProvider:
    provider_id = "webull"

    def __init__(self, app_key: str, app_secret: str, timeout: float) -> None:
        self.app_key = app_key
        self.app_secret = app_secret
        self.timeout = timeout
        self.host = os.getenv("WEBULL_API_HOST", "api.webull.com").strip().removeprefix("https://").rstrip("/")
        self.disabled = False

    def _headers(self, path: str, params: dict[str, str]) -> dict[str, str]:
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        nonce = uuid.uuid4().hex
        signing = {
            **params,
            "host": self.host,
            "x-app-key": self.app_key,
            "x-signature-algorithm": "HMAC-SHA1",
            "x-signature-nonce": nonce,
            "x-signature-version": "1.0",
            "x-timestamp": timestamp,
        }
        joined = "&".join(f"{key}={signing[key]}" for key in sorted(signing))
        encoded = quote(f"{path}&{joined}", safe="")
        signature = base64.b64encode(
            hmac.new(
                f"{self.app_secret}&".encode(),
                encoded.encode(),
                hashlib.sha1,
            ).digest()
        ).decode()
        return {
            "Accept": "application/json",
            "x-app-key": self.app_key,
            "x-timestamp": timestamp,
            "x-signature": signature,
            "x-signature-algorithm": "HMAC-SHA1",
            "x-signature-version": "1.0",
            "x-signature-nonce": nonce,
            "x-version": "v2",
        }

    async def fetch(self, spec: SymbolSpec, period: str, interval: str) -> ProviderResult:
        if self.disabled or spec.market != "US" or spec.asset_class != "stock":
            raise MarketDataError("السوق غير مدعوم أو Webull غير مفعّل")
        path = "/openapi/market-data/stock/bars"
        timespan = {"15m": "M15", "1h": "M60", "1d": "D"}.get(interval)
        if not timespan:
            raise MarketDataError("الفاصل غير مدعوم في Webull")
        base_params = {
            "symbol": spec.display_symbol,
            "category": "US_STOCK",
            "count": "1200",
            "real_time_required": "false",
        }
        payload: Any = None
        last_error: Exception | None = None
        # The dedicated Data API documents timespan, while another official
        # OpenAPI surface names the same field interval. Try both safely.
        for field in ("timespan", "interval"):
            params = {**base_params, field: timespan}
            headers = self._headers(path, params)
            try:
                async with httpx.AsyncClient(timeout=self.timeout, follow_redirects=True) as client:
                    response = await client.get(
                        f"https://{self.host}{path}",
                        params=params,
                        headers=headers,
                    )
                    if response.status_code in {401, 403}:
                        self.disabled = True
                    response.raise_for_status()
                    payload = response.json()
                    break
            except (httpx.HTTPError, ValueError) as exc:
                last_error = exc
        if payload is None:
            raise MarketDataError("تعذر جلب شموع Webull") from last_error
        if isinstance(payload, list):
            payload = payload[0] if payload else {}
        rows = payload.get("result") or payload.get("data") or []
        candles: list[Candle] = []
        for row in rows:
            try:
                timestamp = _parse_timestamp(row.get("time") or row.get("timestamp"))
            except ValueError:
                continue
            candle = _finite_candle(
                timestamp,
                row.get("open"),
                row.get("high"),
                row.get("low"),
                row.get("close"),
                row.get("volume"),
            )
            if candle:
                candles.append(candle)
        if not candles:
            raise MarketDataError("لم تصل شموع صالحة من Webull")
        return ProviderResult(
            candles=sorted(candles, key=lambda item: item.timestamp),
            metadata={
                "longName": spec.display_symbol,
                "shortName": spec.display_symbol,
                "exchangeName": "Webull OpenAPI",
                "currency": "USD",
            },
            provider_id=self.provider_id,
        )


class _YahooFinanceProvider:
    provider_id = "yahoo"

    def __init__(self, timeout: float = 12.0) -> None:
        self.timeout = timeout
        self.headers = {
            "User-Agent": "Mozilla/5.0 SC-Market-Compass/3.5",
            "Accept": "application/json,text/plain,*/*",
        }

    async def fetch(self, spec: SymbolSpec, period: str, interval: str) -> ProviderResult:
        params = {
            "range": period,
            "interval": interval,
            "includePrePost": "false",
            "events": "div,splits",
        }
        encoded = quote(spec.yahoo_symbol, safe="")
        payload: dict[str, Any] | None = None
        last_error: Exception | None = None
        async with httpx.AsyncClient(timeout=self.timeout, headers=self.headers, follow_redirects=True) as client:
            for host in ("query1.finance.yahoo.com", "query2.finance.yahoo.com"):
                try:
                    response = await client.get(f"https://{host}/v8/finance/chart/{encoded}", params=params)
                    response.raise_for_status()
                    payload = response.json()
                    break
                except (httpx.HTTPError, ValueError) as exc:
                    last_error = exc
        if payload is None:
            raise MarketDataError("تعذر الاتصال بمصدر Yahoo Finance") from last_error
        chart = payload.get("chart") or {}
        results = chart.get("result") or []
        error = chart.get("error")
        if error or not results:
            message = error.get("description") if isinstance(error, dict) else None
            raise MarketDataError(message or "لم يُعثر على الرمز في Yahoo Finance")
        result = results[0]
        timestamps = result.get("timestamp") or []
        quote_data = ((result.get("indicators") or {}).get("quote") or [{}])[0]
        columns = [quote_data.get(name) or [] for name in ("open", "high", "low", "close", "volume")]
        candles: list[Candle] = []
        for index, timestamp in enumerate(timestamps):
            if timestamp is None or any(index >= len(column) for column in columns[:4]):
                continue
            values = [column[index] for column in columns[:4]]
            if any(value is None for value in values):
                continue
            candle = _finite_candle(
                int(timestamp),
                values[0],
                values[1],
                values[2],
                values[3],
                columns[4][index] if index < len(columns[4]) else 0,
            )
            if candle:
                candles.append(candle)
        if not candles:
            raise MarketDataError("لم تصل شموع صالحة من Yahoo Finance")
        return ProviderResult(candles=candles, metadata=result.get("meta") or {}, provider_id=self.provider_id)


class YahooChartProvider:
    """Compatibility facade that selects official feeds then falls back to Yahoo."""

    provider_id = "multi-source"

    def __init__(self, timeout: float = 12.0) -> None:
        self.timeout = timeout
        self.yahoo = _YahooFinanceProvider(timeout)
        self.binance = _BinanceSpotProvider(timeout)
        webull_key = os.getenv("WEBULL_APP_KEY", "").strip()
        webull_secret = os.getenv("WEBULL_APP_SECRET", "").strip()
        barchart_key = os.getenv("BARCHART_API_KEY", "").strip()
        self.webull = _WebullProvider(webull_key, webull_secret, timeout) if webull_key and webull_secret else None
        self.barchart = _BarchartProvider(barchart_key, timeout) if barchart_key else None

    async def fetch(self, spec: SymbolSpec, period: str, interval: str) -> ProviderResult:
        if spec.asset_class == "crypto":
            providers: list[CandleProvider] = [self.binance, self.yahoo]
        elif spec.market == "US" and spec.asset_class == "stock":
            providers = [
                provider for provider in (self.webull, self.barchart, self.yahoo)
                if provider is not None
            ]
        else:
            providers = [self.yahoo]
        errors: list[str] = []
        for provider in providers:
            try:
                return await provider.fetch(spec, period, interval)
            except MarketDataError as exc:
                errors.append(f"{provider.provider_id}: {exc}")
        raise MarketDataError(" | ".join(errors) or "لم يعمل أي مصدر بيانات")


def _google_symbol(spec: SymbolSpec) -> str:
    if spec.market == "SAUDI":
        return f"{spec.display_symbol}:TADAWUL"
    if spec.asset_class == "forex":
        return f"{spec.display_symbol[:3]}-{spec.display_symbol[3:]}"
    return spec.display_symbol


def reference_links(spec: SymbolSpec) -> list[tuple[str, str]]:
    symbol = quote_plus(spec.display_symbol)
    if spec.market == "US" and spec.asset_class == "stock":
        barchart_symbol = quote(spec.display_symbol.replace("-", "."), safe=".")
        return [
            ("Yahoo", f"https://finance.yahoo.com/quote/{quote(spec.yahoo_symbol, safe='')}"),
            ("Finviz", f"https://finviz.com/quote.ashx?t={symbol}"),
            ("Barchart", f"https://www.barchart.com/stocks/quotes/{barchart_symbol}/overview"),
            ("Webull", "https://www.webull.com/quote"),
        ]
    if spec.asset_class == "crypto":
        pair = spec.display_symbol.replace("USD", "_USDT")
        return [
            ("Binance", f"https://www.binance.com/en/trade/{quote(pair, safe='_')}"),
            ("Yahoo", f"https://finance.yahoo.com/quote/{quote(spec.yahoo_symbol, safe='')}"),
            ("Investing", f"https://www.investing.com/search/?q={symbol}"),
        ]
    links: list[tuple[str, str]] = [
        ("Yahoo", f"https://finance.yahoo.com/quote/{quote(spec.yahoo_symbol, safe='')}"),
        ("Google", f"https://www.google.com/finance/quote/{quote(_google_symbol(spec), safe=':-')}"),
        ("Investing", f"https://www.investing.com/search/?q={symbol}"),
    ]
    if spec.market == "SAUDI":
        links.append(("TickerChart", "https://www.tickerchart.com/"))
    return links


def source_catalog_text() -> str:
    lines = ["🌐 <b>مصادر البيانات والتحقق</b>", ""]
    role_ar = {
        "feed": "مصدر آلي",
        "optional_feed": "مصدر آلي اختياري",
        "fallback_feed": "مصدر احتياطي",
        "reference": "مرجع خارجي",
        "reference_or_paid_api": "مرجع / API مدفوع",
    }
    enabled = {
        "binance": True,
        "webull": bool(os.getenv("WEBULL_APP_KEY") and os.getenv("WEBULL_APP_SECRET")),
        "barchart": bool(os.getenv("BARCHART_API_KEY")),
        "yahoo": True,
    }
    for item in SOURCE_CATALOG:
        state = " — ✅ مفعّل" if enabled.get(item.source_id) else " — ⚪ يحتاج مفاتيح" if item.source_id in enabled else ""
        lines.append(f"<b>{item.name}</b> — {role_ar.get(item.role, item.role)}{state}")
        lines.append(item.note)
        lines.append("")
    lines.append(
        "<i>ترتيب الجلب: Binance ثم Yahoo للعملات الرقمية؛ Webull ثم Barchart ثم Yahoo للأسهم الأمريكية عند توفر المفاتيح. لا يستخدم البوت scraping.</i>"
    )
    return "\n".join(lines)
