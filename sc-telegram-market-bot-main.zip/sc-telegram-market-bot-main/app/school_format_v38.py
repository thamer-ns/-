from __future__ import annotations

import html
import math
import re
from datetime import timezone

from .market_data import ScanReport
from .opportunity_v37 import opportunity_state_rank
from .school_engine_v38 import FRAME_SPECS
from .technical import FrameAnalysis, LiveAnalysis


FRAME_PRIORITY = {
    "1 دقيقة": 1,
    "5 دقائق": 2,
    "15 دقيقة": 3,
    "30 دقيقة": 4,
    "ساعة": 5,
    "4 ساعات": 6,
    "يومي": 7,
    "أسبوعي": 8,
    "شهري": 9,
}


def _price(value: float | None) -> str:
    if value is None:
        return "—"
    return f"{value:.5f}".rstrip("0").rstrip(".")


def _progress(frame: FrameAnalysis) -> int:
    for reason in frame.reasons:
        match = re.search(r"تقدم الخطة:\s*(\d+)/3", reason)
        if match:
            return max(0, min(3, int(match.group(1))))
    match = re.search(r"تحقق الهدف\s+(\d)", frame.plan_state)
    return int(match.group(1)) if match else 0


def select_primary_frame_v38(item: LiveAnalysis) -> FrameAnalysis:
    return max(
        item.frames,
        key=lambda frame: (
            opportunity_state_rank(frame),
            getattr(frame, "school_count", 0),
            getattr(frame, "consensus_strength", 0),
            frame.confidence,
            FRAME_PRIORITY.get(frame.frame, 0),
        ),
    )


def _direction_text(direction: int) -> str:
    if direction > 0:
        return "صعود"
    if direction < 0:
        return "هبوط"
    return "محايد"


def _state_icon(frame: FrameAnalysis) -> str:
    state = frame.plan_state
    if "إعادة اختبار" in state:
        return "🔄"
    if "مشروطة" in state:
        return "⏳"
    if "دخول قائم" in state or "فرصة" in state:
        return "🚀"
    if frame.direction > 0:
        return "🟢"
    if frame.direction < 0:
        return "🔴"
    return "🟡"


def _entry_zone(frame: FrameAnalysis) -> tuple[float, float] | None:
    if frame.entry is None:
        return None
    width = max(frame.atr * 0.15, frame.entry * 0.0008)
    if frame.direction > 0:
        return frame.entry, frame.entry + width
    return frame.entry - width, frame.entry


def _duration(frame: FrameAnalysis) -> str:
    if frame.entry is None or not frame.targets or frame.atr <= 0:
        return "لا تتوفر مدة قبل اكتمال الخطة"
    progress = _progress(frame)
    target = frame.targets[min(progress, len(frame.targets) - 1)]
    reference = frame.entry if "مشروطة" in frame.plan_state else frame.price
    atr_units = abs(target - reference) / max(frame.atr, 1e-9)
    bars_low = max(1, math.ceil(atr_units * 1.5))
    bars_high = max(bars_low + 1, math.ceil(atr_units * 4.5))
    label = frame.frame
    if label == "1 دقيقة":
        return f"نحو {max(5, bars_low)}–{max(10, bars_high)} دقيقة تداول"
    if label == "5 دقائق":
        return f"نحو {bars_low * 5}–{bars_high * 5} دقيقة تداول"
    if label == "15 دقيقة":
        return (
            f"نحو {max(1, math.ceil(bars_low / 26))}–"
            f"{max(1, math.ceil(bars_high / 26))} جلسات"
        )
    if label == "30 دقيقة":
        return (
            f"نحو {max(1, math.ceil(bars_low / 13))}–"
            f"{max(1, math.ceil(bars_high / 13))} جلسات"
        )
    if label == "ساعة":
        return (
            f"نحو {max(1, math.ceil(bars_low / 6))}–"
            f"{max(1, math.ceil(bars_high / 6))} جلسات"
        )
    if label == "4 ساعات":
        return (
            f"نحو {max(1, math.ceil(bars_low / 2))}–"
            f"{max(1, math.ceil(bars_high / 2))} جلسات تداول"
        )
    if label == "يومي":
        return (
            f"نحو {max(1, math.ceil(bars_low / 5))}–"
            f"{max(1, math.ceil(bars_high / 5))} أسابيع"
        )
    if label == "أسبوعي":
        return f"نحو {bars_low}–{bars_high} أسابيع"
    return f"نحو {bars_low}–{bars_high} أشهر"


def _school_lines(frame: FrameAnalysis) -> list[str]:
    names = tuple(getattr(frame, "school_names", ()))
    details = tuple(getattr(frame, "school_details", ()))
    strong_single = bool(getattr(frame, "strong_single_school", False))
    if not names:
        return [
            "لا توجد مدرسة واحدة قوية أو مدرستان متوافقتان على هذا الفاصل."
        ]
    if strong_single:
        headline = (
            f"<b>مدرسة واحدة قوية:</b> {html.escape(names[0])}"
        )
    else:
        headline = (
            f"<b>عدد المدارس المتوافقة:</b> {len(names)} — "
            f"{html.escape(' + '.join(names))}"
        )
    return [
        headline,
        *(f"• {html.escape(detail)}" for detail in details[:4]),
    ]


def _frame_line(frame: FrameAnalysis) -> str:
    names = tuple(getattr(frame, "school_names", ()))
    schools = " + ".join(names[:2]) if names else "لا توافق كافٍ"
    if frame.direction > 0:
        icon = "🟢"
    elif frame.direction < 0:
        icon = "🔴"
    else:
        icon = "🟡"
    plan = f" | دخول {_price(frame.entry)}" if frame.entry is not None else ""
    return (
        f"• {icon} <b>{html.escape(frame.frame)}</b>: "
        f"{_direction_text(frame.direction)} | قوة {frame.confidence}/100 | "
        f"مدارس {len(names)} ({html.escape(schools)}){plan}"
    )


def _compact(item: LiveAnalysis, frame: FrameAnalysis) -> str:
    names = tuple(getattr(frame, "school_names", ()))
    lines = [
        f"📊 <b>{html.escape(item.display_symbol)} — "
        f"{html.escape(item.name)}</b>",
        f"السعر: <b>{_price(item.price)} "
        f"{html.escape(item.currency)}</b>",
        f"{_state_icon(frame)} <b>{html.escape(frame.plan_state)}</b>",
        f"الفاصل: <b>{html.escape(frame.frame)}</b> | "
        f"الاتجاه: {_direction_text(frame.direction)} | "
        f"قوة التوافق: {frame.confidence}/100",
        f"المدارس: <b>{len(names)}</b> — "
        f"{html.escape(' + '.join(names) if names else 'لا توافق كافٍ')}",
    ]
    if frame.entry is not None and frame.stop is not None and frame.targets:
        lines.extend(
            [
                f"الدخول: <b>{_price(frame.entry)}</b> | "
                f"الوقف: <b>{_price(frame.stop)}</b>",
                "الأهداف: "
                + " • ".join(_price(target) for target in frame.targets),
                f"المدة: {_duration(frame)}",
            ]
        )
    return "\n".join(lines)


def format_analysis_v38(item: LiveAnalysis) -> str:
    primary = select_primary_frame_v38(item)
    signal_type = str(
        getattr(primary, "signal_type", "") or primary.event
    )
    lines = [
        f"📊 <b>{html.escape(item.display_symbol)} — "
        f"{html.escape(item.name)}</b>",
        f"السعر الحالي: <b>{_price(item.price)} "
        f"{html.escape(item.currency)}</b>",
        "",
        "<b>الخلاصة التنفيذية</b>",
        f"{_state_icon(primary)} "
        f"<b>{html.escape(primary.plan_state)}</b>",
        f"الرأي: <b>{_direction_text(primary.direction)}</b> | "
        f"النوع: <b>{html.escape(signal_type)}</b>",
        f"الفاصل الأنسب للفرصة: "
        f"<b>{html.escape(primary.frame)}</b> | "
        f"قوة التوافق: <b>{primary.confidence}/100</b>",
        f"توافق الفواصل: <b>{html.escape(item.alignment)}</b>",
        "",
        "<b>🧠 المدارس والأسباب</b>",
        *_school_lines(primary),
        "",
    ]
    if (
        primary.entry is not None
        and primary.stop is not None
        and primary.targets
    ):
        zone = _entry_zone(primary)
        risk_pct = (
            abs(primary.entry - primary.stop)
            / max(primary.entry, 1e-9)
            * 100
        )
        lines.append("<b>🎯 خطة الفرصة</b>")
        if "مشروطة" in primary.plan_state:
            side = "فوق" if primary.direction > 0 else "تحت"
            lines.append(
                f"شرط التفعيل: إغلاق شمعة "
                f"{html.escape(primary.frame)} {side} "
                f"<b>{_price(primary.entry)}</b>"
            )
        else:
            lines.append(
                f"منطقة الدخول المرجعية: <b>{_price(primary.entry)}</b>"
            )
        if zone:
            lines.append(
                f"نطاق التنفيذ: <code>{_price(zone[0])} - "
                f"{_price(zone[1])}</code>"
            )
        lines.append(
            f"وقف الإلغاء: <b>{_price(primary.stop)}</b> "
            f"(مخاطرة سعرية {risk_pct:.2f}%)"
        )
        progress = _progress(primary)
        for index, target in enumerate(primary.targets, 1):
            marker = "✅" if index <= progress else "🎯"
            lines.append(
                f"{marker} الهدف {index}: <b>{_price(target)}</b>"
            )
        lines.extend(
            [
                f"⏱ المدة الاحتمالية: "
                f"<b>{html.escape(_duration(primary))}</b>",
                "",
            ]
        )
    else:
        lines.extend(
            [
                "<b>🎯 خطة الفرصة</b>",
                "لا توجد حاليًا هندسة دخول ووقف وأهداف صالحة؛ "
                "الرأي للمراقبة فقط.",
                f"الدعم: <b>{_price(primary.support)}</b> | "
                f"المقاومة: <b>{_price(primary.resistance)}</b>",
                "",
            ]
        )
    lines.append("<b>🧭 تحليل الفواصل من دقيقة إلى شهر</b>")
    lines.extend(_frame_line(frame) for frame in item.frames)
    warnings = list(dict.fromkeys(primary.warnings))[:4]
    if warnings:
        lines.extend(
            [
                "",
                "<b>⚠️ ملاحظات المخاطر</b>",
                *(f"• {html.escape(value)}" for value in warnings),
            ]
        )
    updated = item.updated_at.astimezone(timezone.utc).strftime(
        "%Y-%m-%d %H:%M UTC"
    )
    lines.extend(
        [
            "",
            f"مصدر الشموع: <b>{html.escape(item.feed_source)}</b> | "
            f"آخر إغلاق: <code>{updated}</code>",
            "<i>يكفي توافق مدرستين مستقلتين أو مدرسة واحدة قوية "
            "قابلة للتنفيذ. التحليل احتمالي، والوقف هو إلغاء الفكرة.</i>",
        ]
    )
    message = "\n".join(lines)
    return message if len(message) <= 4096 else _compact(item, primary)


def format_scan_v38(report: ScanReport) -> str:
    frame_label = (
        FRAME_SPECS[report.horizon].label
        if report.horizon in FRAME_SPECS
        else report.horizon
    )
    title = {
        "SAUDI": "السوق السعودي",
        "US": "السوق الأمريكي",
        "US_OPTIONS": "الأوبشن الأمريكي حسب الأصل",
        "FOREX": "العملات",
        "CRYPTO": "العملات الرقمية",
    }.get(report.market, report.market)
    lines = [
        f"🔎 <b>فرص توافق المدارس — {html.escape(title)}</b>",
        f"الفاصل: <b>{html.escape(frame_label)}</b> | "
        f"تم تحليل {report.analyzed_symbols}/{report.total_symbols}",
        "",
    ]
    if not report.items:
        lines.append(
            "لا توجد الآن مدرسة واحدة قوية أو مدرستان متوافقتان "
            "اجتازتا شروط المخاطر."
        )
    for index, item in enumerate(report.items[:10], 1):
        frame = item.frames[0]
        names = tuple(getattr(frame, "school_names", ()))
        icon = "🟢" if frame.direction > 0 else "🔴"
        signal_type = str(
            getattr(frame, "signal_type", "") or frame.event
        )
        lines.append(
            f"{index}. {icon} <b>{html.escape(item.display_symbol)}</b> — "
            f"{_direction_text(frame.direction)} | "
            f"{html.escape(signal_type)} | قوة {frame.confidence}/100"
        )
        lines.append(
            f"   مدارس {len(names)}: "
            f"{html.escape(' + '.join(names[:3]))}"
        )
        if frame.entry is not None and frame.stop is not None and frame.targets:
            lines.append(
                f"   دخول {_price(frame.entry)} | "
                f"وقف {_price(frame.stop)} | "
                f"T1 {_price(frame.targets[0])}"
            )
    lines.extend(
        [
            "",
            "<i>افتح الرمز لرؤية جميع المدارس، منطقة الدخول، الوقف، "
            "الأهداف، وتوافق الفواصل.</i>",
        ]
    )
    message = "\n".join(lines)
    if len(message) <= 4096:
        return message
    return "\n".join(lines[:40])
