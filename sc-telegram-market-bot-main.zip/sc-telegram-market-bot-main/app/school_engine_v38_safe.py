from __future__ import annotations

import time
from datetime import datetime, time as clock_time, timezone
from typing import Any

from .audited_engine import AuditedMarketAnalyzer
from .market_safety_v37 import sanitize_candles
from .school_engine_v38 import (
    FRAME_SPECS,
    SchoolConsensusAnalyzer,
    _timezone,
    resample_candles,
)
from .technical import Candle, MarketDataError, normalize_symbol


def _last_4h_bucket_closed(
    candles: list[Candle],
    *,
    market: str,
    metadata: dict[str, Any],
    target_seconds: int,
    now_utc: datetime | None = None,
) -> bool:
    """Return whether the latest 4-hour aggregate is safe to analyze.

    Equity sessions can end with a shorter final bucket.  That partial bucket
    becomes complete when the exchange session closes, not four hours after
    its start. Continuous markets still use the exact four-hour boundary.
    """

    if not candles:
        return False
    now_utc = now_utc or datetime.now(timezone.utc)
    zone = _timezone(metadata, market)
    last_local = datetime.fromtimestamp(
        candles[-1].timestamp, tz=timezone.utc
    ).astimezone(zone)
    now_local = now_utc.astimezone(zone)
    if last_local.date() < now_local.date():
        return True
    if last_local.date() > now_local.date():
        return False
    if market == "SAUDI":
        return now_local.time() >= clock_time(15, 21)
    if market in {"US", "US_OPTIONS"}:
        return now_local.time() >= clock_time(16, 5)
    return int(now_utc.timestamp()) >= candles[-1].timestamp + target_seconds


class SafeSchoolConsensusAnalyzer(SchoolConsensusAnalyzer):
    """Adds conservative fallback and session closure checks to V3.8."""

    async def _fetch(
        self, symbol: str, frame_key: str
    ) -> tuple[list[Candle], dict[str, Any], str]:
        spec = normalize_symbol(symbol)
        frame_spec = FRAME_SPECS.get(frame_key)
        if frame_spec is None:
            raise MarketDataError("الفاصل المطلوب غير مدعوم")
        try:
            candles, metadata, provider_id = await super()._fetch(
                symbol, frame_key
            )
        except MarketDataError as first_error:
            fallback = await self._v38_yahoo.fetch(
                spec, frame_spec.period, frame_spec.source_interval
            )
            raw = AuditedMarketAnalyzer._remove_incomplete_audited(
                spec,
                sanitize_candles(fallback.candles),
                frame_spec.source_seconds,
                fallback.metadata,
            )
            candles = sanitize_candles(
                resample_candles(
                    raw, frame_key, spec.market, fallback.metadata
                )
            )
            if len(candles) < frame_spec.minimum:
                raise first_error
            metadata, provider_id = fallback.metadata, fallback.provider_id

        if frame_key == "4h" and candles and not _last_4h_bucket_closed(
            candles,
            market=spec.market,
            metadata=metadata,
            target_seconds=frame_spec.target_seconds,
        ):
            candles = candles[:-1]
            if len(candles) < frame_spec.minimum:
                raise MarketDataError(
                    f"وصلت {len(candles)} شمعة مغلقة فقط لفاصل "
                    f"{frame_spec.label} بعد حذف تجميع 4 ساعات الجاري"
                )

        key = (spec.yahoo_symbol, f"v38:{frame_key}")
        self._cache[key] = (
            time.monotonic(),
            candles,
            metadata,
            provider_id,
        )
        self._prune_data_cache()
        return candles, metadata, provider_id
