from __future__ import annotations

import asyncio
import hashlib
import json
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from .market import classify_market, is_fresh, timeframe_horizon
from .models import AlertEvent, Opportunity, TradingViewAlert


class Database:
    def __init__(self, path: Path):
        self.path = path
        self._lock = asyncio.Lock()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path, timeout=20)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        return conn

    async def initialize(self) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        await asyncio.to_thread(self._initialize_sync)

    def _initialize_sync(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS events(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    uid TEXT UNIQUE NOT NULL,
                    received_at TEXT NOT NULL,
                    market TEXT NOT NULL,
                    tickerid TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    raw_json TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS opportunities(
                    key TEXT PRIMARY KEY,
                    event_id INTEGER NOT NULL,
                    market TEXT NOT NULL,
                    tickerid TEXT NOT NULL,
                    ticker TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    source TEXT NOT NULL,
                    direction INTEGER NOT NULL,
                    entry REAL, stop REAL, target1 REAL, target2 REAL, target3 REAL,
                    target_count INTEGER NOT NULL,
                    score INTEGER NOT NULL,
                    score_max INTEGER NOT NULL,
                    counter_trend INTEGER NOT NULL,
                    status TEXT NOT NULL,
                    last_event TEXT NOT NULL,
                    opened_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    event_time_ms INTEGER NOT NULL DEFAULT 0
                );
                CREATE TABLE IF NOT EXISTS notifications(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id INTEGER NOT NULL,
                    chat_id INTEGER NOT NULL,
                    status TEXT NOT NULL DEFAULT 'PENDING',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    next_attempt_at TEXT NOT NULL,
                    last_error TEXT,
                    created_at TEXT NOT NULL,
                    sent_at TEXT,
                    UNIQUE(event_id, chat_id)
                );
                CREATE TABLE IF NOT EXISTS admins(
                    user_id INTEGER PRIMARY KEY,
                    chat_id INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS subscribers(
                    chat_id INTEGER PRIMARY KEY,
                    user_id INTEGER NOT NULL,
                    chat_type TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS telegram_updates(
                    update_id INTEGER PRIMARY KEY,
                    received_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS telegram_inbox(
                    update_id INTEGER PRIMARY KEY,
                    payload_json TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'PENDING',
                    attempts INTEGER NOT NULL DEFAULT 0,
                    next_attempt_at TEXT NOT NULL,
                    received_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_error TEXT
                );
                CREATE TABLE IF NOT EXISTS mutes(
                    chat_id INTEGER NOT NULL,
                    tickerid TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY(chat_id, tickerid)
                );
                """
            )
            opportunity_columns = {
                str(row["name"])
                for row in conn.execute("PRAGMA table_info(opportunities)")
            }
            if "event_time_ms" not in opportunity_columns:
                conn.execute(
                    "ALTER TABLE opportunities ADD COLUMN "
                    "event_time_ms INTEGER NOT NULL DEFAULT 0"
                )
            conn.executescript(
                """
                CREATE INDEX IF NOT EXISTS idx_opportunities_active
                    ON opportunities(status, market, direction, updated_at);
                CREATE INDEX IF NOT EXISTS idx_opportunities_symbol
                    ON opportunities(tickerid, timeframe, direction);
                CREATE INDEX IF NOT EXISTS idx_notifications_pending
                    ON notifications(status, next_attempt_at, id);
                CREATE INDEX IF NOT EXISTS idx_events_symbol
                    ON events(tickerid, timeframe, id);
                CREATE INDEX IF NOT EXISTS idx_telegram_inbox_pending
                    ON telegram_inbox(status, next_attempt_at, update_id);
                """
            )
            conn.execute("UPDATE notifications SET status='PENDING' WHERE status='SENDING'")
            conn.execute("UPDATE telegram_inbox SET status='PENDING' WHERE status='PROCESSING'")

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    async def record_alert(self, payload: TradingViewAlert) -> tuple[int, bool, str]:
        async with self._lock:
            return await asyncio.to_thread(self._record_alert_sync, payload)

    def _record_alert_sync(self, payload: TradingViewAlert) -> tuple[int, bool, str]:
        raw = payload.model_dump_json(by_alias=False)
        uid = hashlib.sha256(raw.encode()).hexdigest()
        market = classify_market(payload.tickerid, payload.instrument_type)
        now = self._now()
        with self._connect() as conn:
            try:
                cur = conn.execute(
                    "INSERT INTO events(uid,received_at,market,tickerid,timeframe,raw_json) VALUES(?,?,?,?,?,?)",
                    (uid, now, market, payload.tickerid, payload.timeframe, raw),
                )
                event_id = int(cur.lastrowid)
            except sqlite3.IntegrityError:
                row = conn.execute("SELECT id FROM events WHERE uid=?", (uid,)).fetchone()
                return int(row["id"]), False, market

            if payload.event != AlertEvent.FAKEOUT:
                key = f"{payload.tickerid}|{payload.timeframe}|{payload.direction}"
                status = {
                    AlertEvent.NEW_LONG: "ACTIVE",
                    AlertEvent.NEW_SHORT: "ACTIVE",
                    AlertEvent.TARGET_1: "TARGET_1",
                    AlertEvent.TARGET_2: "TARGET_2",
                    AlertEvent.TARGET_3: "COMPLETED",
                    AlertEvent.STOP: "STOPPED",
                    AlertEvent.CANCELLED: "CANCELLED",
                }[payload.event]
                if status == "ACTIVE":
                    conn.execute(
                        "UPDATE opportunities SET status='CANCELLED',last_event='SUPERSEDED',updated_at=? WHERE tickerid=? AND timeframe=? AND direction<>? AND status IN ('ACTIVE','TARGET_1','TARGET_2')",
                        (now, payload.tickerid, payload.timeframe, payload.direction),
                    )
                old = conn.execute("SELECT opened_at FROM opportunities WHERE key=?", (key,)).fetchone()
                opened = now if old is None or status == "ACTIVE" else old["opened_at"]
                conn.execute(
                    """INSERT INTO opportunities(key,event_id,market,tickerid,ticker,timeframe,source,direction,entry,stop,target1,target2,target3,target_count,score,score_max,counter_trend,status,last_event,opened_at,updated_at)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(key) DO UPDATE SET event_id=excluded.event_id,market=excluded.market,tickerid=excluded.tickerid,ticker=excluded.ticker,timeframe=excluded.timeframe,source=excluded.source,direction=excluded.direction,entry=COALESCE(excluded.entry,opportunities.entry),stop=COALESCE(excluded.stop,opportunities.stop),target1=COALESCE(excluded.target1,opportunities.target1),target2=COALESCE(excluded.target2,opportunities.target2),target3=COALESCE(excluded.target3,opportunities.target3),target_count=excluded.target_count,score=excluded.score,score_max=excluded.score_max,counter_trend=excluded.counter_trend,status=excluded.status,last_event=excluded.last_event,opened_at=excluded.opened_at,updated_at=excluded.updated_at""",
                    (key,event_id,market,payload.tickerid,payload.ticker,payload.timeframe,payload.source,payload.direction,payload.entry,payload.stop,payload.target1,payload.target2,payload.target3,payload.target_count,payload.score,payload.score_max,int(payload.counter_trend),status,payload.event.value,opened,now),
                )
            return event_id, True, market

    async def subscriber_chat_ids(self, defaults: tuple[int, ...]) -> list[int]:
        rows = await asyncio.to_thread(self._subscriber_chat_ids_sync)
        return sorted(set(defaults) | set(rows))

    def _subscriber_chat_ids_sync(self) -> list[int]:
        with self._connect() as conn:
            return [int(r[0]) for r in conn.execute("SELECT chat_id FROM subscribers WHERE enabled=1")]

    async def enqueue_notifications(self, event_id: int, chat_ids: list[int]) -> None:
        if not chat_ids:
            return
        await asyncio.to_thread(self._enqueue_notifications_sync, event_id, chat_ids)

    def _enqueue_notifications_sync(self, event_id: int, chat_ids: list[int]) -> None:
        now = self._now()
        with self._connect() as conn:
            conn.executemany(
                "INSERT OR IGNORE INTO notifications(event_id,chat_id,next_attempt_at,created_at) VALUES(?,?,?,?)",
                [(event_id, chat_id, now, now) for chat_id in chat_ids],
            )

    async def pending_notifications(self, limit: int = 20) -> list[dict[str, Any]]:
        return await asyncio.to_thread(self._pending_notifications_sync, limit)

    def _pending_notifications_sync(self, limit: int) -> list[dict[str, Any]]:
        now = self._now()
        with self._connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            rows = conn.execute(
                """SELECT n.id notification_id,n.chat_id,n.attempts,e.id event_id,e.market,e.raw_json
                FROM notifications n JOIN events e ON e.id=n.event_id
                WHERE n.status='PENDING' AND n.next_attempt_at<=? ORDER BY n.id LIMIT ?""",
                (now, limit),
            ).fetchall()
            for row in rows:
                conn.execute("UPDATE notifications SET status='SENDING' WHERE id=?", (row["notification_id"],))
            return [dict(r) for r in rows]

    async def mark_notification_sent(self, notification_id: int) -> None:
        await asyncio.to_thread(self._notification_update, notification_id, "SENT", None, None)

    async def mark_notification_skipped(self, notification_id: int) -> None:
        await asyncio.to_thread(self._notification_update, notification_id, "SKIPPED", None, None)

    def _notification_update(self, notification_id: int, status: str, attempts: int | None, error: str | None) -> None:
        with self._connect() as conn:
            conn.execute(
                "UPDATE notifications SET status=?,attempts=COALESCE(?,attempts),last_error=?,sent_at=? WHERE id=?",
                (status, attempts, error, self._now() if status in {'SENT','SKIPPED'} else None, notification_id),
            )

    async def mark_notification_failed(self, notification_id: int, attempts: int, error: str) -> None:
        await asyncio.to_thread(self._mark_failed_sync, notification_id, attempts, error)

    def _mark_failed_sync(self, notification_id: int, attempts: int, error: str) -> None:
        next_at = datetime.now(timezone.utc) + timedelta(seconds=min(300, 2 ** min(attempts, 8)))
        with self._connect() as conn:
            conn.execute(
                "UPDATE notifications SET status=?,attempts=?,next_attempt_at=?,last_error=? WHERE id=?",
                ("FAILED" if attempts >= 10 else "PENDING", attempts, next_at.isoformat(), error[:500], notification_id),
            )

    async def list_opportunities(self, market: str | None = None, horizon: str = "ALL", direction: int = 0, min_score: int = 0, limit: int = 20, active_only: bool = True, fresh_only: bool = False) -> list[Opportunity]:
        rows = await asyncio.to_thread(self._list_sync, market, direction, min_score, max(limit * 5, 50), active_only)
        result: list[Opportunity] = []
        for op in rows:
            if horizon != "ALL" and timeframe_horizon(op.timeframe) != horizon:
                continue
            if fresh_only and not is_fresh(op.timeframe, op.updated_at):
                continue
            result.append(op)
            if len(result) >= limit:
                break
        return result

    def _list_sync(self, market: str | None, direction: int, min_score: int, limit: int, active_only: bool) -> list[Opportunity]:
        clauses = []
        params: list[Any] = []
        if active_only:
            clauses.append("status IN ('ACTIVE','TARGET_1','TARGET_2')")
        if market and market != "ALL":
            clauses.append("market=?"); params.append(market)
        if direction in (-1, 1):
            clauses.append("direction=?"); params.append(direction)
        clauses.append("CASE WHEN score_max>0 THEN score*100.0/score_max ELSE 0 END>=?"); params.append(min_score)
        params.append(limit)
        where = " WHERE " + " AND ".join(clauses)
        with self._connect() as conn:
            rows = conn.execute(f"SELECT * FROM opportunities{where} ORDER BY CASE WHEN score_max>0 THEN score*1.0/score_max ELSE 0 END DESC,updated_at DESC LIMIT ?", params).fetchall()
            return [self._op(r) for r in rows]

    async def find_symbol(self, query: str, limit: int = 10) -> list[Opportunity]:
        return await asyncio.to_thread(self._find_symbol_sync, query, limit)

    def _find_symbol_sync(self, query: str, limit: int) -> list[Opportunity]:
        like = f"%{query.strip().upper()}%"
        with self._connect() as conn:
            rows = conn.execute("SELECT * FROM opportunities WHERE UPPER(tickerid) LIKE ? OR UPPER(ticker) LIKE ? ORDER BY CASE WHEN status IN ('ACTIVE','TARGET_1','TARGET_2') THEN 0 ELSE 1 END,updated_at DESC LIMIT ?", (like, like, limit)).fetchall()
            return [self._op(r) for r in rows]

    async def get_opportunity_by_event(self, event_id: int) -> Opportunity | None:
        return await asyncio.to_thread(self._get_op_sync, event_id)

    def _get_op_sync(self, event_id: int) -> Opportunity | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM opportunities WHERE event_id=?", (event_id,)).fetchone()
            return self._op(row) if row else None

    async def register_admin(self, user_id: int, chat_id: int) -> None:
        await asyncio.to_thread(self._register_admin_sync, user_id, chat_id)

    def _register_admin_sync(self, user_id: int, chat_id: int) -> None:
        now = self._now()
        with self._connect() as conn:
            conn.execute("INSERT INTO admins(user_id,chat_id,created_at,last_seen_at) VALUES(?,?,?,?) ON CONFLICT(user_id) DO UPDATE SET chat_id=excluded.chat_id,last_seen_at=excluded.last_seen_at", (user_id, chat_id, now, now))

    async def register_subscriber(self, chat_id: int, user_id: int, chat_type: str) -> None:
        await asyncio.to_thread(self._register_subscriber_sync, chat_id, user_id, chat_type)

    def _register_subscriber_sync(self, chat_id: int, user_id: int, chat_type: str) -> None:
        now = self._now()
        with self._connect() as conn:
            conn.execute("INSERT INTO subscribers(chat_id,user_id,chat_type,enabled,created_at,last_seen_at) VALUES(?,?,?,1,?,?) ON CONFLICT(chat_id) DO UPDATE SET user_id=excluded.user_id,chat_type=excluded.chat_type,enabled=1,last_seen_at=excluded.last_seen_at", (chat_id,user_id,chat_type,now,now))

    async def is_admin(self, user_id: int) -> bool:
        return await asyncio.to_thread(self._exists, "SELECT 1 FROM admins WHERE user_id=?", (user_id,))

    async def has_any_admin(self) -> bool:
        return await asyncio.to_thread(self._exists, "SELECT 1 FROM admins LIMIT 1", ())

    def _exists(self, sql: str, params: tuple[Any, ...]) -> bool:
        with self._connect() as conn:
            return conn.execute(sql, params).fetchone() is not None

    async def claim_telegram_update(self, update_id: int) -> bool:
        return await asyncio.to_thread(self._claim_update_sync, update_id)

    def _claim_update_sync(self, update_id: int) -> bool:
        with self._connect() as conn:
            try:
                conn.execute("INSERT INTO telegram_updates(update_id,received_at) VALUES(?,?)", (update_id,self._now()))
                return True
            except sqlite3.IntegrityError:
                return False

    async def is_muted(self, chat_id: int, tickerid: str) -> bool:
        return await asyncio.to_thread(self._exists, "SELECT 1 FROM mutes WHERE chat_id=? AND tickerid=?", (chat_id,tickerid))

    async def set_mute(self, chat_id: int, tickerid: str, muted: bool) -> None:
        await asyncio.to_thread(self._set_mute_sync, chat_id, tickerid, muted)

    def _set_mute_sync(self, chat_id: int, tickerid: str, muted: bool) -> None:
        with self._connect() as conn:
            if muted:
                conn.execute("INSERT OR IGNORE INTO mutes(chat_id,tickerid,created_at) VALUES(?,?,?)", (chat_id,tickerid,self._now()))
            else:
                conn.execute("DELETE FROM mutes WHERE chat_id=? AND tickerid=?", (chat_id,tickerid))

    async def health_snapshot(self) -> dict[str, Any]:
        return await asyncio.to_thread(self._health_sync)

    def _health_sync(self) -> dict[str, Any]:
        with self._connect() as conn:
            last = conn.execute("SELECT received_at,tickerid,timeframe FROM events ORDER BY id DESC LIMIT 1").fetchone()
            counts = conn.execute("SELECT market,COUNT(*) total FROM opportunities WHERE status IN ('ACTIVE','TARGET_1','TARGET_2') GROUP BY market").fetchall()
            pending = conn.execute("SELECT COUNT(*) total FROM notifications WHERE status='PENDING'").fetchone()[0]
            subscribers = conn.execute("SELECT COUNT(*) total FROM subscribers WHERE enabled=1").fetchone()[0]
            return {"last_event": dict(last) if last else None,"active_by_market": {r['market']: int(r['total']) for r in counts},"pending_notifications": int(pending),"subscribers": int(subscribers)}

    @staticmethod
    def _op(row: sqlite3.Row) -> Opportunity:
        data = dict(row)
        data["counter_trend"] = bool(data["counter_trend"])
        return Opportunity.model_validate(data)
