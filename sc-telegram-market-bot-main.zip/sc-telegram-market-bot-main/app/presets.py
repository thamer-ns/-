from __future__ import annotations

import asyncio
import math
import time
from dataclasses import dataclass, replace
from statistics import median, pstdev
from typing import Any

from .market_data import ScanReport
from .technical import Candle, FrameAnalysis, LiveAnalysis, MarketDataError


@dataclass(frozen=True, slots=True)
class PresetCategory:
    category_id: str
    title: str
    description: str


@dataclass(frozen=True, slots=True)
class PresetDefinition:
    preset_id: str
    category_id: str
    title: str
    description: str
    required_all: tuple[str, ...] = ()
    required_any: tuple[str, ...] = ()
    direction: int = 0
    min_confidence: int = 0
    require_plan: bool = False
    default_frame: str = "D"


@dataclass(frozen=True, slots=True)
class SignalSnapshot:
    tags: frozenset[str]
    reasons: tuple[tuple[str, str], ...]
    volume_ratio: float | None
    rank_bonus: int

    def reason(self, tag: str) -> str:
        return dict(self.reasons).get(tag, tag)


@dataclass(frozen=True, slots=True)
class PresetMatch:
    analysis: LiveAnalysis
    reasons: tuple[str, ...]
    rank: float


@dataclass(frozen=True, slots=True)
class PresetReport:
    market: str
    frame_key: str
    universe_label: str
    total_symbols: int
    analyzed_symbols: int
    failed_symbols: int
    preset: PresetDefinition
    items: tuple[PresetMatch, ...]


CATEGORIES: tuple[PresetCategory, ...] = (
    PresetCategory("trend", "📈 المسار والاتجاه", "الاتجاه المتماسك، الارتفاعات المتتالية والقمم أو القيعان الجديدة."),
    PresetCategory("cross", "🔀 التقاطعات والزخم", "تقاطعات مؤكدة بين متوسطات أو MACD وRSI على شمعة مغلقة."),
    PresetCategory("levels", "⭐ الدعم والمقاومة", "قرب المستويات، الكسر المؤكد وإعادة الاختبار بدل الاعتماد على مستوى خام فقط."),
    PresetCategory("candle", "🕯 الشموع والسلوك", "نماذج شموع مع سياقها السعري لتقليل الإشارات العشوائية."),
    PresetCategory("vol", "🌪 التذبذب والسيولة", "بولنجر، انكماش التذبذب، اتساع المدى وارتفاع المشاركة."),
    PresetCategory("plan", "🎯 الخطط المؤكدة", "نتائج اجتازت زناد الدخول وهندسة الوقف والعائق الأول."),
)
CATEGORY_BY_ID = {item.category_id: item for item in CATEGORIES}


def _preset(
    preset_id: str,
    category_id: str,
    title: str,
    description: str,
    *,
    all_tags: tuple[str, ...] = (),
    any_tags: tuple[str, ...] = (),
    direction: int = 0,
    confidence: int = 0,
    plan: bool = False,
) -> PresetDefinition:
    return PresetDefinition(
        preset_id=preset_id,
        category_id=category_id,
        title=title,
        description=description,
        required_all=all_tags,
        required_any=any_tags,
        direction=direction,
        min_confidence=confidence,
        require_plan=plan,
    )


PRESETS: tuple[PresetDefinition, ...] = (
    _preset("pathup", "trend", "مسار صاعد متماسك", "السعر فوق EMA20 وEMA20 فوق EMA50 مع بنية وزخم صاعدين.", all_tags=("above20", "ema20gt50", "structure_up", "macd_pos"), direction=1, confidence=55),
    _preset("pathdn", "trend", "مسار هابط متماسك", "السعر تحت EMA20 وEMA20 تحت EMA50 مع بنية وزخم هابطين.", all_tags=("below20", "ema20lt50", "structure_down", "macd_neg"), direction=-1, confidence=55),
    _preset("up3", "trend", "ثلاث إغلاقات صاعدة", "ثلاث شموع مغلقة متتالية كل إغلاق أعلى من السابق.", all_tags=("up3",)),
    _preset("dn3", "trend", "ثلاث إغلاقات هابطة", "ثلاث شموع مغلقة متتالية كل إغلاق أدنى من السابق.", all_tags=("dn3",)),
    _preset("hi20", "trend", "قمة 20 شمعة", "إغلاق جديد أعلى من أعلى عشرين شمعة سابقة.", all_tags=("high20",)),
    _preset("lo20", "trend", "قاع 20 شمعة", "إغلاق جديد أدنى من أدنى عشرين شمعة سابقة.", all_tags=("low20",)),
    _preset("e720u", "cross", "تقاطع EMA7 فوق EMA20", "تقاطع صاعد حدث على آخر شمعة مغلقة، وليس مجرد بقاء المتوسط فوق الآخر.", all_tags=("ema7x20_up",)),
    _preset("e720d", "cross", "تقاطع EMA7 تحت EMA20", "تقاطع هابط حدث على آخر شمعة مغلقة.", all_tags=("ema7x20_down",)),
    _preset("e712u", "cross", "تقاطع EMA7 فوق EMA12", "تقاطع زخم قصير صاعد على آخر شمعة مغلقة.", all_tags=("ema7x12_up",)),
    _preset("e712d", "cross", "تقاطع EMA7 تحت EMA12", "تقاطع زخم قصير هابط على آخر شمعة مغلقة.", all_tags=("ema7x12_down",)),
    _preset("e50100u", "cross", "تقاطع EMA50 فوق EMA100", "تحول متوسط المدى إلى الصعود على شمعة مغلقة.", all_tags=("ema50x100_up",)),
    _preset("e50100d", "cross", "تقاطع EMA50 تحت EMA100", "تحول متوسط المدى إلى الهبوط على شمعة مغلقة.", all_tags=("ema50x100_down",)),
    _preset("e50200u", "cross", "تقاطع EMA50 فوق EMA200", "تقاطع اتجاه رئيسي صاعد حديث.", all_tags=("ema50x200_up",)),
    _preset("e50200d", "cross", "تقاطع EMA50 تحت EMA200", "تقاطع اتجاه رئيسي هابط حديث.", all_tags=("ema50x200_down",)),
    _preset("macdu", "cross", "تقاطع MACD صاعد", "خط MACD عبر خط الإشارة صعودًا على آخر شمعة مغلقة.", all_tags=("macd_cross_up",)),
    _preset("macdd", "cross", "تقاطع MACD هابط", "خط MACD عبر خط الإشارة هبوطًا على آخر شمعة مغلقة.", all_tags=("macd_cross_down",)),
    _preset("r50u", "cross", "RSI يعبر 50 صعودًا", "انتقال RSI من أسفل 50 إلى أعلاها.", all_tags=("rsi50_up",)),
    _preset("r50d", "cross", "RSI يعبر 50 هبوطًا", "انتقال RSI من أعلى 50 إلى أسفلها.", all_tags=("rsi50_down",)),
    _preset("r30u", "cross", "ارتداد RSI من 30", "RSI عاد فوق 30 بعد وجوده دونها.", all_tags=("rsi30_up",)),
    _preset("r70d", "cross", "رفض RSI من 70", "RSI عاد دون 70 بعد وجوده فوقها.", all_tags=("rsi70_down",)),
    _preset("nearsup", "levels", "قريب من دعم مؤكد", "الإغلاق ضمن 0.35 ATR من الدعم المجمع متعدد اللمسات.", all_tags=("near_support",)),
    _preset("nearres", "levels", "قريب من مقاومة مؤكدة", "الإغلاق ضمن 0.35 ATR من المقاومة المجمعّة.", all_tags=("near_resistance",)),
    _preset("brkup", "levels", "كسر مقاومة مؤكد", "الإغلاق اخترق المقاومة بعد أن كان الإغلاق السابق دونها.", all_tags=("break_up",), direction=1),
    _preset("brkdn", "levels", "كسر دعم مؤكد", "الإغلاق كسر الدعم بعد أن كان الإغلاق السابق فوقه.", all_tags=("break_down",), direction=-1),
    _preset("rtup", "levels", "إعادة اختبار صاعدة", "اختراق حديث ثم اختبار المستوى والإغلاق فوقه.", all_tags=("retest_up",), direction=1),
    _preset("rtdn", "levels", "إعادة اختبار هابطة", "كسر حديث ثم اختبار المستوى والإغلاق دونه.", all_tags=("retest_down",), direction=-1),
    _preset("above200", "levels", "فوق EMA200", "السعر أعلى المتوسط الطويل؛ شرط سياق لا يُعد دخولًا منفردًا.", all_tags=("above200",)),
    _preset("below200", "levels", "تحت EMA200", "السعر أسفل المتوسط الطويل؛ شرط سياق لا يُعد دخولًا منفردًا.", all_tags=("below200",)),
    _preset("bulleng", "candle", "ابتلاع صاعد قرب دعم", "ابتلاع صاعد مع قرب السعر من دعم، لتجنب نموذج بلا سياق.", all_tags=("bull_engulf", "near_support")),
    _preset("beareng", "candle", "ابتلاع هابط قرب مقاومة", "ابتلاع هابط مع قرب السعر من مقاومة.", all_tags=("bear_engulf", "near_resistance")),
    _preset("hammer", "candle", "مطرقة عند دعم", "ظل سفلي طويل وإغلاق علوي نسبيًا قرب دعم.", all_tags=("hammer", "near_support")),
    _preset("shoot", "candle", "شهاب عند مقاومة", "ظل علوي طويل وإغلاق سفلي نسبيًا قرب مقاومة.", all_tags=("shooting_star", "near_resistance")),
    _preset("doji", "candle", "شمعة حيرة Doji", "جسم صغير جدًا مقارنة بمدى الشمعة.", all_tags=("doji",)),
    _preset("inside", "candle", "Inside Bar", "مدى الشمعة الأخيرة داخل مدى الشمعة السابقة.", all_tags=("inside_bar",)),
    _preset("strongu", "candle", "شمعة اندفاع صاعدة", "جسم صاعد يساوي 70% على الأقل من المدى.", all_tags=("strong_bull",)),
    _preset("strongd", "candle", "شمعة اندفاع هابطة", "جسم هابط يساوي 70% على الأقل من المدى.", all_tags=("strong_bear",)),
    _preset("bbup", "vol", "إغلاق فوق بولنجر العلوي", "إغلاق فوق الحد العلوي لبولينجر 20، مع عرضه الحالي.", all_tags=("bb_above",)),
    _preset("bbdn", "vol", "إغلاق تحت بولنجر السفلي", "إغلاق تحت الحد السفلي لبولينجر 20.", all_tags=("bb_below",)),
    _preset("squeeze", "vol", "انكماش بولنجر", "عرض بولنجر ضمن أدنى 20% من آخر النوافذ؛ حالة استعداد وليست اتجاهًا.", all_tags=("bb_squeeze",)),
    _preset("atrexp", "vol", "اتساع مدى الشمعة", "المدى الحقيقي للشمعة الأخيرة أكبر من 1.5 ATR.", all_tags=("atr_expansion",)),
    _preset("volsurge", "vol", "ارتفاع حجم قوي", "الحجم 1.8 ضعف وسيط آخر 20 شمعة أو أكثر.", all_tags=("volume_surge",)),
    _preset("volrise", "vol", "حجم مع ارتفاع السعر", "إغلاق صاعد وحجم 1.2 ضعف الوسيط أو أكثر.", all_tags=("volume_on_rise",)),
    _preset("planup", "plan", "خطة شراء مؤكدة", "زناد صاعد مؤكد مع وقف وأهداف صالحين.", direction=1, confidence=55, plan=True),
    _preset("plandn", "plan", "خطة هبوط مؤكدة", "زناد هابط مؤكد مع وقف وأهداف صالحين.", direction=-1, confidence=55, plan=True),
    _preset("planrtu", "plan", "خطة إعادة اختبار صاعدة", "خطة شراء مصدرها إعادة اختبار وليست مطاردة كسر.", all_tags=("retest_up",), direction=1, confidence=55, plan=True),
    _preset("planrtd", "plan", "خطة إعادة اختبار هابطة", "خطة هبوط مصدرها إعادة اختبار.", all_tags=("retest_down",), direction=-1, confidence=55, plan=True),
    _preset("planbru", "plan", "خطة كسر صاعدة", "خطة شراء بعد كسر مقاومة مؤكد.", all_tags=("break_up",), direction=1, confidence=55, plan=True),
    _preset("planbrd", "plan", "خطة كسر هابطة", "خطة هبوط بعد كسر دعم مؤكد.", all_tags=("break_down",), direction=-1, confidence=55, plan=True),
    _preset("plan70u", "plan", "خطة شراء بقوة 70+", "خطة صاعدة مؤكدة مع قوة توافق لا تقل عن 70/100.", direction=1, confidence=70, plan=True),
    _preset("plan70d", "plan", "خطة هبوط بقوة 70+", "خطة هابطة مؤكدة مع قوة توافق لا تقل عن 70/100.", direction=-1, confidence=70, plan=True),
)
PRESET_BY_ID = {item.preset_id: item for item in PRESETS}


def presets_for_category(category_id: str) -> tuple[PresetDefinition, ...]:
    return tuple(item for item in PRESETS if item.category_id == category_id)


def _ema(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    seed_len = min(period, len(values))
    seed = sum(values[:seed_len]) / seed_len
    result = [seed] * seed_len
    alpha = 2.0 / (period + 1.0)
    for value in values[seed_len:]:
        result.append(alpha * value + (1.0 - alpha) * result[-1])
    return result[: len(values)]


def _rsi(values: list[float], period: int = 14) -> float:
    if len(values) <= period:
        return 50.0
    changes = [cur - prev for prev, cur in zip(values, values[1:])]
    gains = [max(value, 0.0) for value in changes]
    losses = [max(-value, 0.0) for value in changes]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for gain, loss in zip(gains[period:], losses[period:]):
        avg_gain = (avg_gain * (period - 1) + gain) / period
        avg_loss = (avg_loss * (period - 1) + loss) / period
    if avg_loss == 0:
        return 100.0 if avg_gain else 50.0
    return 100.0 - 100.0 / (1.0 + avg_gain / avg_loss)


def _cross_up(a: list[float], b: list[float]) -> bool:
    return len(a) >= 2 and len(b) >= 2 and a[-2] <= b[-2] and a[-1] > b[-1]


def _cross_down(a: list[float], b: list[float]) -> bool:
    return len(a) >= 2 and len(b) >= 2 and a[-2] >= b[-2] and a[-1] < b[-1]


def _normal_recommendation(direction: int, confidence: int) -> str:
    if direction > 0 and confidence >= 70:
        return "إيجابي قوي — لا تعتمد إلا زنادًا مؤكدًا"
    if direction > 0:
        return "إيجابي — مراقبة وتأكيد"
    if direction < 0 and confidence >= 70:
        return "سلبي قوي — لا تعتمد إلا كسرًا أو اختبارًا مؤكدًا"
    if direction < 0:
        return "سلبي — مراقبة وتأكيد"
    return "محايد/انتقالي — لا توجد أفضلية اتجاهية كافية"


def normalize_analysis(item: LiveAnalysis) -> LiveAnalysis:
    """Prevents a mild aggregate score from inventing a direction not passed by frames."""
    frames = item.frames
    if not frames:
        return replace(item, direction=0, recommendation=_normal_recommendation(0, item.confidence))
    if len(frames) == 1:
        frame = frames[0]
        return replace(
            item,
            direction=frame.direction,
            score=frame.score,
            confidence=frame.confidence,
            alignment=f"قراءة فاصل واحد: {frame.frame}",
            recommendation=_normal_recommendation(frame.direction, frame.confidence),
        )
    daily = next((frame for frame in frames if frame.frame == "يومي"), None)
    hourly = next((frame for frame in frames if frame.frame == "ساعة"), None)
    if (
        daily
        and hourly
        and daily.direction
        and hourly.direction
        and daily.direction != hourly.direction
        and daily.confidence >= 60
        and hourly.confidence >= 60
    ):
        return replace(
            item,
            direction=0,
            confidence=max(0, item.confidence - 15),
            alignment="تعارض قوي بين اليومي والساعة",
            recommendation="محايد — يمنع فتح خطة جديدة حتى ينخفض تعارض الفواصل",
        )
    weights = {"يومي": 0.50, "ساعة": 0.35, "15 دقيقة": 0.15}
    directional = [frame for frame in frames if frame.direction]
    if not directional:
        direction = 0
        alignment = "الفواصل لم تجتز شروط اتجاه مؤكد"
    else:
        signed = sum(frame.direction * frame.confidence * weights.get(frame.frame, 0.10) for frame in directional)
        strength = sum(frame.confidence * weights.get(frame.frame, 0.10) for frame in directional)
        ratio = signed / max(strength, 1.0)
        direction = 1 if ratio >= 0.25 else -1 if ratio <= -0.25 else 0
        signs = {frame.direction for frame in directional}
        alignment = "توافق الفواصل" if len(signs) == 1 else "توافق جزئي/مرحلة انتقال"
    return replace(
        item,
        direction=direction,
        alignment=alignment,
        recommendation=_normal_recommendation(direction, item.confidence),
    )


def build_signal_snapshot(candles: list[Candle], frame: FrameAnalysis) -> SignalSnapshot:
    if len(candles) < 60:
        raise MarketDataError("البيانات غير كافية للفلاتر المتقدمة")
    closes = [item.close for item in candles]
    current, previous = candles[-1], candles[-2]
    tags: set[str] = set()
    reasons: dict[str, str] = {}

    def add(tag: str, reason: str) -> None:
        tags.add(tag)
        reasons[tag] = reason

    emas = {period: _ema(closes, period) for period in (7, 12, 20, 50, 100, 200)}
    if current.close > emas[20][-1]:
        add("above20", "الإغلاق فوق EMA20")
    else:
        add("below20", "الإغلاق تحت EMA20")
    if emas[20][-1] > emas[50][-1]:
        add("ema20gt50", "EMA20 أعلى EMA50")
    else:
        add("ema20lt50", "EMA20 أدنى EMA50")
    if len(closes) >= 200:
        if current.close > emas[200][-1]:
            add("above200", "الإغلاق فوق EMA200")
        else:
            add("below200", "الإغلاق تحت EMA200")
    for tag, left, right in (
        ("ema7x20", 7, 20),
        ("ema7x12", 7, 12),
        ("ema50x100", 50, 100),
        ("ema50x200", 50, 200),
    ):
        if len(closes) < right:
            continue
        if _cross_up(emas[left], emas[right]):
            add(f"{tag}_up", f"EMA{left} تقاطع فوق EMA{right} على آخر إغلاق")
        if _cross_down(emas[left], emas[right]):
            add(f"{tag}_down", f"EMA{left} تقاطع تحت EMA{right} على آخر إغلاق")

    ema12, ema26 = _ema(closes, 12), _ema(closes, 26)
    macd = [left - right for left, right in zip(ema12, ema26)]
    signal = _ema(macd, 9)
    if macd[-1] > signal[-1]:
        add("macd_pos", "MACD أعلى خط الإشارة")
    else:
        add("macd_neg", "MACD أدنى خط الإشارة")
    if _cross_up(macd, signal):
        add("macd_cross_up", "تقاطع MACD صاعد حديث")
    if _cross_down(macd, signal):
        add("macd_cross_down", "تقاطع MACD هابط حديث")

    rsi_now = _rsi(closes)
    rsi_prev = _rsi(closes[:-1])
    if rsi_prev < 50 <= rsi_now:
        add("rsi50_up", f"RSI عبر 50 صعودًا ({rsi_now:.1f})")
    if rsi_prev > 50 >= rsi_now:
        add("rsi50_down", f"RSI عبر 50 هبوطًا ({rsi_now:.1f})")
    if rsi_prev < 30 <= rsi_now:
        add("rsi30_up", f"RSI ارتد فوق 30 ({rsi_now:.1f})")
    if rsi_prev > 70 >= rsi_now:
        add("rsi70_down", f"RSI عاد دون 70 ({rsi_now:.1f})")

    if frame.structure == "قمم وقيعان صاعدة":
        add("structure_up", "بنية قمم وقيعان صاعدة")
    elif frame.structure == "قمم وقيعان هابطة":
        add("structure_down", "بنية قمم وقيعان هابطة")

    if all(closes[index] > closes[index - 1] for index in range(len(closes) - 2, len(closes))):
        add("up3", "ثلاثة إغلاقات متتالية صاعدة")
    if all(closes[index] < closes[index - 1] for index in range(len(closes) - 2, len(closes))):
        add("dn3", "ثلاثة إغلاقات متتالية هابطة")
    if current.close > max(item.high for item in candles[-21:-1]):
        add("high20", "إغلاق جديد أعلى من أعلى 20 شمعة")
    if current.close < min(item.low for item in candles[-21:-1]):
        add("low20", "إغلاق جديد أدنى من أدنى 20 شمعة")

    atr = max(frame.atr, current.close * 0.0001)
    if abs(current.close - frame.support) <= 0.35 * atr:
        add("near_support", f"الإغلاق قريب من الدعم {frame.support:g}")
    if abs(current.close - frame.resistance) <= 0.35 * atr:
        add("near_resistance", f"الإغلاق قريب من المقاومة {frame.resistance:g}")
    buffer = max(0.05 * atr, current.close * 0.0005)
    tolerance = max(0.18 * atr, current.close * 0.001)
    break_up = previous.close <= frame.resistance + buffer and current.close > frame.resistance + buffer
    break_down = previous.close >= frame.support - buffer and current.close < frame.support - buffer
    broke_up_recently = any(item.close > frame.resistance + buffer for item in candles[-5:-1])
    broke_down_recently = any(item.close < frame.support - buffer for item in candles[-5:-1])
    retest_up = broke_up_recently and current.low <= frame.resistance + tolerance and current.close > frame.resistance
    retest_down = broke_down_recently and current.high >= frame.support - tolerance and current.close < frame.support
    if retest_up:
        add("retest_up", "اختراق حديث ثم إعادة اختبار والإغلاق فوق المقاومة")
    elif break_up:
        add("break_up", "كسر مقاومة مؤكد بالإغلاق")
    if retest_down:
        add("retest_down", "كسر حديث ثم إعادة اختبار والإغلاق دون الدعم")
    elif break_down:
        add("break_down", "كسر دعم مؤكد بالإغلاق")

    candle_range = max(current.high - current.low, current.close * 1e-8)
    body = abs(current.close - current.open)
    upper_wick = current.high - max(current.open, current.close)
    lower_wick = min(current.open, current.close) - current.low
    if previous.close < previous.open and current.close > current.open and current.open <= previous.close and current.close >= previous.open:
        add("bull_engulf", "ابتلاع صاعد مكتمل")
    if previous.close > previous.open and current.close < current.open and current.open >= previous.close and current.close <= previous.open:
        add("bear_engulf", "ابتلاع هابط مكتمل")
    if body / candle_range <= 0.12:
        add("doji", "جسم الشمعة لا يتجاوز 12% من مداها")
    if current.high < previous.high and current.low > previous.low:
        add("inside_bar", "الشمعة داخل مدى الشمعة السابقة")
    if current.close > current.open and body / candle_range >= 0.70:
        add("strong_bull", "جسم صاعد قوي ≥70% من المدى")
    if current.close < current.open and body / candle_range >= 0.70:
        add("strong_bear", "جسم هابط قوي ≥70% من المدى")
    if lower_wick >= max(2.0 * body, 0.35 * candle_range) and upper_wick <= max(body, 0.18 * candle_range) and current.close >= current.low + 0.60 * candle_range:
        add("hammer", "ظل سفلي طويل وإغلاق في الجزء العلوي")
    if upper_wick >= max(2.0 * body, 0.35 * candle_range) and lower_wick <= max(body, 0.18 * candle_range) and current.close <= current.low + 0.40 * candle_range:
        add("shooting_star", "ظل علوي طويل وإغلاق في الجزء السفلي")

    windows: list[float] = []
    for end in range(max(20, len(closes) - 60), len(closes) + 1):
        window = closes[end - 20 : end]
        if len(window) == 20:
            windows.append(4.0 * pstdev(window))
    bb_window = closes[-20:]
    bb_mid = sum(bb_window) / 20
    bb_std = pstdev(bb_window)
    bb_upper = bb_mid + 2.0 * bb_std
    bb_lower = bb_mid - 2.0 * bb_std
    if current.close > bb_upper:
        add("bb_above", "الإغلاق فوق الحد العلوي لبولينجر 20")
    if current.close < bb_lower:
        add("bb_below", "الإغلاق تحت الحد السفلي لبولينجر 20")
    if len(windows) >= 10:
        threshold = sorted(windows)[max(0, math.floor((len(windows) - 1) * 0.20))]
        if windows[-1] <= threshold:
            add("bb_squeeze", "عرض بولنجر ضمن أدنى 20% من آخر النوافذ")

    previous_close = candles[-2].close
    true_range = max(current.high - current.low, abs(current.high - previous_close), abs(current.low - previous_close))
    if true_range >= 1.5 * atr:
        add("atr_expansion", f"المدى الحقيقي {true_range / atr:.2f} ATR")
    trusted = frame.volume_trusted
    volumes = [item.volume for item in candles[-21:-1] if item.volume > 0]
    volume_ratio = None
    if trusted and volumes and current.volume > 0:
        baseline = median(volumes)
        volume_ratio = current.volume / baseline if baseline > 0 else None
        if volume_ratio is not None and volume_ratio >= 1.8:
            add("volume_surge", f"الحجم {volume_ratio:.2f}× من الوسيط")
        if volume_ratio is not None and volume_ratio >= 1.2 and current.close > previous.close:
            add("volume_on_rise", f"إغلاق صاعد مع حجم {volume_ratio:.2f}×")

    if frame.entry is not None and frame.stop is not None and frame.targets:
        add("confirmed_plan", "الخطة تحتوي دخولًا ووقفًا وأهدافًا صالحة")
    rank_bonus = (10 if "confirmed_plan" in tags else 0) + (5 if volume_ratio and volume_ratio >= 1.2 else 0)
    return SignalSnapshot(frozenset(tags), tuple(reasons.items()), volume_ratio, rank_bonus)


def match_preset(preset: PresetDefinition, analysis: LiveAnalysis, snapshot: SignalSnapshot) -> tuple[bool, tuple[str, ...], float]:
    if not analysis.frames:
        return False, (), 0.0
    frame = analysis.frames[0]
    if preset.direction and frame.direction != preset.direction:
        return False, (), 0.0
    if frame.confidence < preset.min_confidence:
        return False, (), 0.0
    if preset.require_plan and "confirmed_plan" not in snapshot.tags:
        return False, (), 0.0
    if preset.required_all and not set(preset.required_all).issubset(snapshot.tags):
        return False, (), 0.0
    if preset.required_any and not set(preset.required_any).intersection(snapshot.tags):
        return False, (), 0.0
    selected_tags = list(preset.required_all)
    if preset.required_any:
        selected_tags.extend(tag for tag in preset.required_any if tag in snapshot.tags)
    if preset.require_plan:
        selected_tags.append("confirmed_plan")
    reasons = tuple(dict.fromkeys(snapshot.reason(tag) for tag in selected_tags))
    rank = frame.confidence + snapshot.rank_bonus + abs(frame.score - 50) * 0.1
    return True, reasons, rank


class AdvancedPresetScanner:
    def __init__(self, analyzer: Any) -> None:
        self.analyzer = analyzer
        self._cache: dict[tuple[str, str, str], tuple[float, PresetReport]] = {}
        self._locks: dict[tuple[str, str, str], asyncio.Lock] = {}

    @staticmethod
    def _frame_key(frame_code: str) -> str:
        return "1h" if frame_code.upper() == "H" else "1d"

    async def scan_directional(self, market: str, horizon: str, direction: int, min_score: int, limit: int = 10) -> ScanReport:
        normalized = market.upper()
        frame_key = "1h" if horizon in {"INTRADAY", "SWING"} else "1d"
        raw_items, total, analyzed = await self.analyzer._scan_all(normalized, frame_key)
        items = [normalize_analysis(item) for item in raw_items]
        if direction > 0:
            items = [item for item in items if item.direction > 0]
        elif direction < 0:
            items = [item for item in items if item.direction < 0]
        else:
            items = [item for item in items if item.direction != 0]
        items = [item for item in items if item.confidence >= min_score]
        items.sort(key=lambda item: (item.confidence, abs(item.score - 50)), reverse=True)
        from .universes import UNIVERSE_LABELS
        return ScanReport(
            market=normalized,
            horizon=horizon,
            universe_label=UNIVERSE_LABELS.get(normalized, normalized),
            total_symbols=total,
            analyzed_symbols=analyzed,
            failed_symbols=max(0, total - analyzed),
            direction=direction,
            items=tuple(items[:limit]),
        )

    async def scan_preset(self, market: str, preset_id: str, frame_code: str = "D", limit: int = 10) -> PresetReport:
        preset = PRESET_BY_ID.get(preset_id)
        if preset is None:
            raise MarketDataError("الفلتر الفني غير معروف")
        normalized = market.upper()
        frame_key = self._frame_key(frame_code)
        cache_key = (normalized, preset_id, frame_key)
        now = time.monotonic()
        cached = self._cache.get(cache_key)
        if cached and now - cached[0] <= self.analyzer.scan_cache_seconds:
            return cached[1]
        lock = self._locks.setdefault(cache_key, asyncio.Lock())
        async with lock:
            cached = self._cache.get(cache_key)
            now = time.monotonic()
            if cached and now - cached[0] <= self.analyzer.scan_cache_seconds:
                return cached[1]
            raw_items, total, analyzed = await self.analyzer._scan_all(normalized, frame_key)
            semaphore = asyncio.Semaphore(self.analyzer.scan_concurrency)

            async def worker(raw_item: LiveAnalysis) -> PresetMatch | None:
                async with semaphore:
                    try:
                        item = normalize_analysis(raw_item)
                        candles, _, _ = await self.analyzer._fetch(item.display_symbol, frame_key)
                        snapshot = build_signal_snapshot(candles, item.frames[0])
                        matched, reasons, rank = match_preset(preset, item, snapshot)
                        return PresetMatch(item, reasons, rank) if matched else None
                    except (MarketDataError, ValueError, IndexError, ArithmeticError):
                        return None

            raw_matches = await asyncio.gather(*(worker(item) for item in raw_items))
            matches = [item for item in raw_matches if item is not None]
            matches.sort(key=lambda item: item.rank, reverse=True)
            from .universes import UNIVERSE_LABELS
            report = PresetReport(
                market=normalized,
                frame_key=frame_key,
                universe_label=UNIVERSE_LABELS.get(normalized, normalized),
                total_symbols=total,
                analyzed_symbols=analyzed,
                failed_symbols=max(0, total - analyzed),
                preset=preset,
                items=tuple(matches[:limit]),
            )
            self._cache[cache_key] = (time.monotonic(), report)
            return report
