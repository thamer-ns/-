from __future__ import annotations

import math
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from statistics import median


class MarketDataError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class Candle:
    timestamp: int
    open: float
    high: float
    low: float
    close: float
    volume: float


@dataclass(frozen=True, slots=True)
class FrameAnalysis:
    frame: str
    price: float
    trend: str
    structure: str
    event: str
    score: int
    confidence: int
    evidence_long: int
    evidence_short: int
    rsi: float
    ema20: float
    ema50: float
    ema200: float | None
    macd_hist: float
    atr: float
    atr_percent: float
    volume_ratio: float | None
    volume_trusted: bool
    support: float
    resistance: float
    direction: int
    plan_state: str
    entry: float | None
    stop: float | None
    targets: tuple[float, ...]
    risk_reward: float | None
    reasons: tuple[str, ...]
    warnings: tuple[str, ...]
    updated_at: datetime
    market: str = ""
    frame_key: str = ""
    risk_atr: float | None = None
    target_atr: tuple[float, ...] = ()
    duration_low_bars: int | None = None
    duration_high_bars: int | None = None
    duration_samples: int = 0
    duration_success_rate: float | None = None
    duration_method: str = ""
    plan_profile: str = ""


@dataclass(frozen=True, slots=True)
class LiveAnalysis:
    query: str
    yahoo_symbol: str
    display_symbol: str
    name: str
    exchange: str
    currency: str
    asset_class: str
    price: float
    score: int
    confidence: int
    recommendation: str
    direction: int
    alignment: str
    feed_source: str
    frames: tuple[FrameAnalysis, ...]
    updated_at: datetime
    market: str = ""


@dataclass(frozen=True, slots=True)
class SymbolSpec:
    query: str
    yahoo_symbol: str
    display_symbol: str
    asset_class: str
    market: str


ALIASES = {
    "TASI": ("^TASI.SR", "index", "SAUDI"),
    "SPX": ("^GSPC", "index", "US"),
    "SP500": ("^GSPC", "index", "US"),
    "NASDAQ": ("^IXIC", "index", "US"),
    "DJI": ("^DJI", "index", "US"),
    "DOW": ("^DJI", "index", "US"),
    "GOLD": ("GC=F", "future", "GLOBAL"),
    "XAUUSD": ("GC=F", "future", "GLOBAL"),
    "SILVER": ("SI=F", "future", "GLOBAL"),
    "OIL": ("CL=F", "future", "GLOBAL"),
    "WTI": ("CL=F", "future", "GLOBAL"),
}
CRYPTO = {"BTC", "ETH", "SOL", "XRP", "BNB", "ADA", "DOGE", "AVAX", "DOT", "LINK"}
CURRENCIES = {"USD", "EUR", "GBP", "JPY", "CHF", "AUD", "CAD", "NZD", "SAR", "CNY", "HKD"}


def normalize_symbol(value: str) -> SymbolSpec:
    query = value.strip().upper()
    raw = query.replace(" ", "")
    if not raw:
        raise MarketDataError("الرمز فارغ")
    for prefix in ("TADAWUL:", "NASDAQ:", "NYSE:", "AMEX:"):
        raw = raw.removeprefix(prefix)
    if raw in ALIASES:
        yahoo, asset_class, market = ALIASES[raw]
        return SymbolSpec(query, yahoo, raw, asset_class, market)
    if raw.endswith(".SR"):
        return SymbolSpec(query, raw, raw[:-3], "stock", "SAUDI")
    if re.fullmatch(r"\d{4,6}", raw):
        return SymbolSpec(query, f"{raw}.SR", raw, "stock", "SAUDI")
    pair = raw.replace("/", "").replace("-", "")
    if len(pair) == 6 and pair[:3] in CRYPTO and pair[3:] == "USD":
        return SymbolSpec(query, f"{pair[:3]}-USD", pair, "crypto", "CRYPTO")
    if len(pair) == 6 and pair[:3] in CURRENCIES and pair[3:] in CURRENCIES:
        return SymbolSpec(query, f"{pair}=X", pair, "forex", "FOREX")
    if not re.fullmatch(r"[A-Z0-9.^=_-]{1,24}", raw):
        raise MarketDataError("صيغة الرمز غير مدعومة")
    asset_class = "index" if raw.startswith("^") else "future" if raw.endswith("=F") else "stock"
    market = "US" if asset_class == "stock" else "GLOBAL"
    return SymbolSpec(query, raw, raw, asset_class, market)


def _ema(values: list[float], period: int) -> list[float]:
    if not values:
        return []
    alpha = 2.0 / (period + 1.0)
    seed_len = min(period, len(values))
    seed = sum(values[:seed_len]) / seed_len
    result = [seed] * seed_len
    for value in values[seed_len:]:
        result.append(alpha * value + (1.0 - alpha) * result[-1])
    return result[:len(values)]


def _rsi(values: list[float], period: int = 14) -> float:
    if len(values) <= period:
        return 50.0
    changes = [cur - prev for prev, cur in zip(values, values[1:])]
    gains = [max(change, 0.0) for change in changes]
    losses = [max(-change, 0.0) for change in changes]
    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period
    for gain, loss in zip(gains[period:], losses[period:]):
        avg_gain = (avg_gain * (period - 1) + gain) / period
        avg_loss = (avg_loss * (period - 1) + loss) / period
    if avg_loss == 0:
        return 100.0 if avg_gain else 50.0
    return 100.0 - 100.0 / (1.0 + avg_gain / avg_loss)


def _atr(candles: list[Candle], period: int = 14) -> float:
    if len(candles) < 2:
        return 0.0
    true_ranges = [
        max(cur.high - cur.low, abs(cur.high - prev.close), abs(cur.low - prev.close))
        for prev, cur in zip(candles, candles[1:])
    ]
    if not true_ranges:
        return 0.0
    seed_len = min(period, len(true_ranges))
    value = sum(true_ranges[:seed_len]) / seed_len
    for current in true_ranges[seed_len:]:
        value = (value * (period - 1) + current) / period
    return value


def _pivot_levels(candles: list[Candle], left: int = 2, right: int = 2) -> tuple[list[float], list[float]]:
    lows: list[float] = []
    highs: list[float] = []
    for index in range(left, len(candles) - right):
        window = candles[index - left:index + right + 1]
        current = candles[index]
        if current.low <= min(item.low for item in window):
            lows.append(current.low)
        if current.high >= max(item.high for item in window):
            highs.append(current.high)
    return lows, highs


def _cluster(values: list[float], tolerance: float) -> list[tuple[float, int]]:
    if not values:
        return []
    ordered = sorted(values)
    groups: list[list[float]] = [[ordered[0]]]
    for value in ordered[1:]:
        center = sum(groups[-1]) / len(groups[-1])
        if abs(value - center) <= tolerance:
            groups[-1].append(value)
        else:
            groups.append([value])
    return [(sum(group) / len(group), len(group)) for group in groups]


def _levels(candles: list[Candle], price: float, atr: float) -> tuple[float, float, list[float], list[float]]:
    sample = candles[-100:-2] if len(candles) > 45 else candles[:-2]
    lows, highs = _pivot_levels(sample)
    tolerance = max(atr * 0.30, price * 0.002)
    low_clusters = _cluster(lows, tolerance)
    high_clusters = _cluster(highs, tolerance)
    supports = sorted((level for level, touches in low_clusters if touches >= 2 and level < price), reverse=True)
    resistances = sorted(level for level, touches in high_clusters if touches >= 2 and level > price)
    recent = candles[-20:-1] or candles[-20:]
    fallback_support = min(item.low for item in recent)
    fallback_resistance = max(item.high for item in recent)
    support = supports[0] if supports else fallback_support
    resistance = resistances[0] if resistances else fallback_resistance
    return support, resistance, supports, resistances


def _structure(candles: list[Candle], atr: float) -> tuple[int, str, str]:
    sample = candles[-120:-1]
    lows, highs = _pivot_levels(sample)
    bias = 0
    text = "عرضي أو انتقالي"
    if len(lows) >= 2 and len(highs) >= 2:
        higher_lows = lows[-1] > lows[-2]
        higher_highs = highs[-1] > highs[-2]
        lower_lows = lows[-1] < lows[-2]
        lower_highs = highs[-1] < highs[-2]
        if higher_lows and higher_highs:
            bias, text = 1, "قمم وقيعان صاعدة"
        elif lower_lows and lower_highs:
            bias, text = -1, "قمم وقيعان هابطة"
    event = "لا كسر بنيوي جديد"
    if not highs or not lows or len(candles) < 3:
        return bias, text, event
    previous_close = candles[-2].close
    close = candles[-1].close
    buffer = max(atr * 0.05, close * 0.0005)
    last_high = highs[-1]
    last_low = lows[-1]
    bullish_break = previous_close <= last_high + buffer and close > last_high + buffer
    bearish_break = previous_close >= last_low - buffer and close < last_low - buffer
    if bullish_break:
        event = "CHoCH صاعد" if bias < 0 else "BOS صاعد"
    elif bearish_break:
        event = "CHoCH هابط" if bias > 0 else "BOS هابط"
    return bias, text, event


def _volume_ratio(candles: list[Candle], trusted: bool) -> float | None:
    if not trusted:
        return None
    volumes = [item.volume for item in candles[-31:] if item.volume > 0]
    if len(volumes) < 10:
        return None
    baseline = median(volumes[:-1])
    return volumes[-1] / baseline if baseline > 0 else None


def _round(value: float, price: float) -> float:
    return round(value, 5 if price < 1 else 4 if price < 10 else 3 if price < 100 else 2)


def _setup_event(candles: list[Candle], support: float, resistance: float, atr: float) -> tuple[int, str, float | None]:
    if len(candles) < 5:
        return 0, "لا يوجد زناد مؤكد", None
    current = candles[-1]
    previous = candles[-2]
    buffer = max(atr * 0.05, current.close * 0.0005)
    tolerance = max(atr * 0.18, current.close * 0.001)
    bullish_break = previous.close <= resistance + buffer and current.close > resistance + buffer
    bearish_break = previous.close >= support - buffer and current.close < support - buffer
    recent_before = candles[-5:-1]
    broke_up_recently = any(item.close > resistance + buffer for item in recent_before)
    broke_down_recently = any(item.close < support - buffer for item in recent_before)
    bullish_retest = broke_up_recently and current.low <= resistance + tolerance and current.close > resistance
    bearish_retest = broke_down_recently and current.high >= support - tolerance and current.close < support
    if bullish_retest:
        return 1, "إعادة اختبار صاعدة مؤكدة", resistance
    if bearish_retest:
        return -1, "إعادة اختبار هابطة مؤكدة", support
    if bullish_break:
        return 1, "كسر مقاومة مؤكد", resistance
    if bearish_break:
        return -1, "كسر دعم مؤكد", support
    return 0, "لا يوجد زناد مؤكد", None


def _engulfing(candles: list[Candle]) -> int:
    if len(candles) < 2:
        return 0
    prev, cur = candles[-2], candles[-1]
    bullish = prev.close < prev.open and cur.close > cur.open and cur.open <= prev.close and cur.close >= prev.open
    bearish = prev.close > prev.open and cur.close < cur.open and cur.open >= prev.close and cur.close <= prev.open
    return 1 if bullish else -1 if bearish else 0


def _build_plan(*, direction: int, event_direction: int, event_level: float | None, price: float, atr: float, support: float, resistance: float, supports: list[float], resistances: list[float], evidence: int, frame: str) -> tuple[str, float | None, float | None, tuple[float, ...], float | None, list[str]]:
    warnings: list[str] = []
    if direction == 0:
        return "لا توجد خطة — الاتجاه غير حاسم", None, None, (), None, warnings
    if event_direction != direction or event_level is None:
        return "مراقبة — الاتجاه قائم لكن زناد الدخول غير مؤكد", None, None, (), None, warnings
    if evidence < 55:
        return "مرشح مرفوض — الأدلة أقل من الحد", None, None, (), None, warnings
    extended_distance = abs(price - event_level)
    if extended_distance > max(1.25 * atr, price * 0.025):
        warnings.append("السعر ابتعد عن مستوى الزناد؛ مُنع الدخول المتأخر")
        return "مراقبة — الدخول ممتد بعيدًا عن المستوى", None, None, (), None, warnings
    entry_buffer = max(atr * 0.05, price * 0.0005)
    stop_buffer = max(atr * 0.25, price * 0.001)
    if direction > 0:
        entry = max(price, event_level + entry_buffer)
        structural = max((level for level in supports if level < entry), default=support)
        stop = structural - stop_buffer
        raw_risk = entry - stop
    else:
        entry = min(price, event_level - entry_buffer)
        structural = min((level for level in resistances if level > entry), default=resistance)
        stop = structural + stop_buffer
        raw_risk = stop - entry
    minimum_risk = max(atr * (0.55 if frame == "يومي" else 0.45), price * 0.002)
    maximum_risk = min(atr * (4.0 if frame == "يومي" else 2.8), price * 0.08)
    if raw_risk < minimum_risk:
        stop = entry - minimum_risk if direction > 0 else entry + minimum_risk
        raw_risk = minimum_risk
    if raw_risk <= 0 or raw_risk > maximum_risk:
        warnings.append("مرساة الوقف البنيوية غير صالحة أو بعيدة")
        return "مرفوض — هندسة الوقف غير مناسبة", None, None, (), None, warnings
    obstacles = resistances if direction > 0 else supports
    forward = sorted((level for level in obstacles if level > entry)) if direction > 0 else sorted((level for level in obstacles if level < entry), reverse=True)
    if forward:
        obstacle_distance = abs(forward[0] - entry)
        if obstacle_distance < 0.65 * raw_risk:
            warnings.append("عائق بنيوي قريب جدًا قبل هدف مقبول")
            return "مرفوض — لا توجد مساحة كافية قبل العائق", None, None, (), None, warnings
    targets = [entry + direction * raw_risk * multiple for multiple in (1.0, 1.8, 2.6)]
    if forward:
        obstacle_r = abs(forward[0] - entry) / raw_risk
        if 0.75 <= obstacle_r < 1.0:
            targets[0] = forward[0]
    rr = abs(targets[0] - entry) / raw_risk
    return "خطة مؤكدة بعد إغلاق الزناد", entry, stop, tuple(targets), rr, warnings


def analyze_frame(candles: list[Candle], label: str, asset_class: str = "stock") -> FrameAnalysis:
    if len(candles) < 60:
        raise MarketDataError(f"البيانات غير كافية لفاصل {label}")
    closes = [item.close for item in candles]
    price = closes[-1]
    ema20_series = _ema(closes, 20)
    ema50_series = _ema(closes, 50)
    ema200_series = _ema(closes, 200) if len(closes) >= 200 else []
    ema12 = _ema(closes, 12)
    ema26 = _ema(closes, 26)
    macd = [a - b for a, b in zip(ema12, ema26)]
    signal = _ema(macd, 9)
    macd_hist = macd[-1] - signal[-1]
    rsi = _rsi(closes)
    atr = _atr(candles)
    if atr <= 0 or not math.isfinite(atr):
        raise MarketDataError(f"ATR غير صالح لفاصل {label}")
    support, resistance, supports, resistances = _levels(candles, price, atr)
    structure_bias, structure_text, structure_event = _structure(candles, atr)
    event_direction, event_text, event_level = _setup_event(candles, support, resistance, atr)
    engulfing = _engulfing(candles)
    volume_trusted = asset_class in {"stock", "crypto", "future"}
    volume_ratio = _volume_ratio(candles, volume_trusted)
    ema20 = ema20_series[-1]
    ema50 = ema50_series[-1]
    ema200 = ema200_series[-1] if ema200_series else None
    long_points = 0
    short_points = 0
    reasons: list[str] = []
    warnings: list[str] = []
    if structure_bias > 0:
        long_points += 20
        reasons.append("بنية داو صاعدة")
    elif structure_bias < 0:
        short_points += 20
        reasons.append("بنية داو هابطة")
    if price > ema20:
        long_points += 8
    else:
        short_points += 8
    if ema20 > ema50:
        long_points += 12
        reasons.append("EMA20 أعلى EMA50")
    else:
        short_points += 12
        reasons.append("EMA20 أدنى EMA50")
    if ema200 is not None:
        if ema50 > ema200:
            long_points += 8
        else:
            short_points += 8
    if macd_hist > 0:
        long_points += 10
    elif macd_hist < 0:
        short_points += 10
    if 52 <= rsi <= 72:
        long_points += 10
    elif 28 <= rsi <= 48:
        short_points += 10
    elif rsi > 78:
        warnings.append("تشبع شرائي مرتفع")
    elif rsi < 22:
        warnings.append("تشبع بيعي مرتفع")
    if event_direction > 0:
        long_points += 25
        reasons.append(event_text)
    elif event_direction < 0:
        short_points += 25
        reasons.append(event_text)
    elif engulfing > 0 and abs(price - support) <= 0.6 * atr:
        long_points += 7
        reasons.append("شمعة ابتلاعية صاعدة قرب دعم — مراقبة")
    elif engulfing < 0 and abs(price - resistance) <= 0.6 * atr:
        short_points += 7
        reasons.append("شمعة ابتلاعية هابطة قرب مقاومة — مراقبة")
    if volume_ratio is not None:
        if event_direction and volume_ratio >= 1.10:
            if event_direction > 0:
                long_points += 7
            else:
                short_points += 7
            reasons.append("مشاركة حجم مؤهلة")
        elif event_direction and volume_ratio < 0.75:
            warnings.append("الكسر بحجم ضعيف")
    elif asset_class in {"forex", "index"}:
        warnings.append("الحجم غير مركزي؛ لم يدخل في الدرجة")
    long_evidence = min(100, long_points)
    short_evidence = min(100, short_points)
    score = max(0, min(100, round(50 + (long_points - short_points) * 0.5)))
    direction = 1 if long_evidence >= 55 and long_evidence >= short_evidence + 10 else -1 if short_evidence >= 55 and short_evidence >= long_evidence + 10 else 0
    confidence = max(long_evidence, short_evidence)
    trend = "صاعد" if direction > 0 else "هابط" if direction < 0 else "محايد/انتقالي"
    plan_state, entry, stop, targets, rr, plan_warnings = _build_plan(direction=direction, event_direction=event_direction, event_level=event_level, price=price, atr=atr, support=support, resistance=resistance, supports=supports, resistances=resistances, evidence=confidence, frame=label)
    warnings.extend(plan_warnings)
    return FrameAnalysis(
        frame=label,
        price=_round(price, price),
        trend=trend,
        structure=structure_text,
        event=structure_event if structure_event != "لا كسر بنيوي جديد" else event_text,
        score=score,
        confidence=confidence,
        evidence_long=long_evidence,
        evidence_short=short_evidence,
        rsi=rsi,
        ema20=_round(ema20, price),
        ema50=_round(ema50, price),
        ema200=_round(ema200, price) if ema200 is not None else None,
        macd_hist=macd_hist,
        atr=_round(atr, price),
        atr_percent=(atr / price * 100.0) if price else 0.0,
        volume_ratio=volume_ratio,
        volume_trusted=volume_trusted,
        support=_round(support, price),
        resistance=_round(resistance, price),
        direction=direction,
        plan_state=plan_state,
        entry=_round(entry, price) if entry is not None else None,
        stop=_round(stop, price) if stop is not None else None,
        targets=tuple(_round(value, price) for value in targets),
        risk_reward=rr,
        reasons=tuple(dict.fromkeys(reasons)),
        warnings=tuple(dict.fromkeys(warnings)),
        updated_at=datetime.fromtimestamp(candles[-1].timestamp, tz=timezone.utc),
    )
