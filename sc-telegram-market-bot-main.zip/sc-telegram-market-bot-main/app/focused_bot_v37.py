from __future__ import annotations

import html
import logging
import re
from typing import Any

from .focused_bot_v37_helpers import (
    FOCUSED_HELP_TEXT,
    FRAME_ALIASES,
    FRAME_CALLBACK,
    build_active_buttons,
    build_analysis_buttons,
    build_main_menu,
    parse_symbol_frame,
    provider_status_text,
    sources_text,
    us_list_text,
)
from .formatting import format_health, format_search_results, format_symbol_analysis
from .live_bot import LiveBotService as AdvancedLiveBotService
from .market_data import FRAMES
from .opportunity_format import format_analysis_v37, format_scan_v37, prioritize_scan_report
from .opportunity_v37 import OpportunityMarketAnalyzer
from .presets import AdvancedPresetScanner, normalize_analysis
from .technical import MarketDataError
from .universes import US_FOCUS_UNIVERSE

logger = logging.getLogger(__name__)


class LiveBotService(AdvancedLiveBotService):
    def __init__(self, settings, database, telegram) -> None:
        super().__init__(settings, database, telegram)
        self.live = OpportunityMarketAnalyzer()
        self.scanner = AdvancedPresetScanner(self.live)

    async def _is_authorized(self, user_id: int, chat_id: int) -> bool:
        if user_id in self.settings.telegram_allowed_user_ids:
            return True
        if user_id == chat_id and chat_id in self.settings.telegram_chat_ids:
            return True
        return await self.db.is_admin(user_id)

    async def configure_telegram(self) -> None:
        if not self.settings.public_base_url:
            return
        webhook_url = f"{self.settings.public_base_url}/webhooks/telegram"
        await self.telegram.configure_webhook(
            webhook_url,
            self.settings.telegram_header_secret,
            drop_pending_updates=False,
        )
        await self.telegram.set_commands()
        logger.info("Telegram webhook configured for %s", self.settings.public_base_url)

    @staticmethod
    def _main_menu() -> dict[str, Any]:
        return build_main_menu(AdvancedLiveBotService._main_menu())

    @staticmethod
    def _analysis_buttons(symbol: str) -> dict[str, Any]:
        return build_analysis_buttons(symbol)

    @staticmethod
    def _active_buttons(items: list[Any]) -> dict[str, Any]:
        return build_active_buttons(items)

    async def _status_text(self) -> str:
        health = format_health(await self.db.health_snapshot())
        return (
            health
            + "\n\n<b>محرك التحليل:</b> V3.7 — ذاكرة فرص وخطط مشروطة\n"
            + f"<b>القائمة الأمريكية:</b> {len(US_FOCUS_UNIVERSE)} سهمًا\n"
            + "<b>الفرص:</b> تبقى ظاهرة بعد الزناد حتى الوقف أو اكتمال الأهداف\n"
            + "<b>تعارض الفواصل:</b> لا يخفي خطة الفاصل؛ يعرضها مستقلة مع التحذير\n"
            + provider_status_text()
            + "\n<i>لا يختار عقدًا أو Greeks ولا ينفذ أوامر.</i>"
        )

    async def _send_active_plans(self, chat_id: int) -> None:
        items = await self.db.list_opportunities(
            market=None,
            horizon="ALL",
            direction=0,
            min_score=0,
            limit=20,
            active_only=True,
            fresh_only=False,
        )
        text = format_search_results(
            "خطط TradingView النشطة",
            items,
            market="ALL",
            horizon="ALL",
            min_score=0,
            options_mode=False,
        )
        if items:
            text += "\n\n<i>تبقى الخطة حتى الهدف الثالث أو الوقف أو الإلغاء.</i>"
        await self.telegram.send_message(chat_id, text, self._active_buttons(items))

    async def _send_symbol_analysis(
        self,
        chat_id: int,
        symbol: str,
        frame_key: str | None = None,
    ) -> None:
        clean = symbol.strip().upper()
        if not clean:
            await self.telegram.send_message(
                chat_id,
                "أرسل الرمز مثل <code>2222</code> أو <code>AAPL</code>، ويمكن إضافة <code>1h</code> أو <code>1d</code>.",
            )
            return
        frame_text = FRAMES[frame_key][2] if frame_key else "جميع الفواصل"
        await self.telegram.send_message(
            chat_id,
            f"⏳ تحليل <code>{html.escape(clean)}</code> — {html.escape(frame_text)} من الشموع المغلقة...",
        )
        try:
            raw = await self.live.analyze_one(clean, frame_key) if frame_key else await self.live.analyze(clean)
            result = normalize_analysis(raw)
        except MarketDataError as exc:
            stored = await self.db.find_symbol(clean, limit=12)
            if stored:
                await self.telegram.send_message(
                    chat_id,
                    "⚠️ تعذر الجلب المباشر، وهذه آخر بيانات TradingView محفوظة:\n\n"
                    + format_symbol_analysis(clean, stored),
                    self._detail_buttons(stored[0]),
                )
                return
            await self.telegram.send_message(
                chat_id,
                "❌ <b>تعذر تحليل الرمز الآن.</b>\n\n" + f"السبب: {html.escape(str(exc))}",
                self._main_menu(),
            )
            return
        await self.telegram.send_message(
            chat_id,
            format_analysis_v37(result),
            self._analysis_buttons(result.display_symbol),
        )

    async def _send_search(
        self,
        chat_id: int,
        market: str = "ALL",
        horizon: str = "ALL",
        direction: int = 0,
        min_score: int | None = None,
        options_mode: bool = False,
    ) -> None:
        threshold = self.settings.default_min_score if min_score is None else min_score
        selected = "US_OPTIONS" if options_mode else market
        if selected in {"SAUDI", "US", "US_OPTIONS", "FOREX", "CRYPTO"}:
            await self.telegram.send_message(
                chat_id,
                "⏳ ترتيب الدخول القائم ثم إعادة الاختبار ثم الدخول المشروط...",
            )
            try:
                report = await self.scanner.scan_directional(
                    selected, horizon, direction, threshold, limit=10
                )
                report = prioritize_scan_report(report)
            except MarketDataError as exc:
                await self.telegram.send_message(
                    chat_id,
                    "❌ تعذر تنفيذ المسح الآن: " + html.escape(str(exc)),
                    self._main_menu(),
                )
                return
            await self.telegram.send_message(
                chat_id,
                format_scan_v37(report),
                self._scan_buttons(
                    list(report.items), selected, horizon, direction, threshold,
                    options_mode=options_mode,
                ),
            )
            return
        await super()._send_search(chat_id, market, horizon, direction, threshold, options_mode)

    async def _handle_text(self, chat_id: int, text: str) -> None:
        command, _, argument = text.partition(" ")
        command = command.split("@", 1)[0].lower()
        argument = argument.strip()
        if text.startswith("حلل ") or text.startswith("تحليل "):
            command = "/analyze"
            argument = text.split(" ", 1)[1].strip()

        if command in {"/start", "/help"}:
            await self.telegram.send_message(chat_id, FOCUSED_HELP_TEXT, self._main_menu())
            return
        if command == "/analyze":
            symbol, frame_key = parse_symbol_frame(argument)
            await self._send_symbol_analysis(chat_id, symbol, frame_key)
            return
        if command == "/uslist":
            await self.telegram.send_message(chat_id, us_list_text(), self._main_menu())
            return
        if command == "/sources":
            await self.telegram.send_message(chat_id, sources_text(), self._main_menu())
            return
        if command == "/status":
            await self.telegram.send_message(chat_id, await self._status_text(), self._main_menu())
            return
        if command == "/active":
            await self._send_active_plans(chat_id)
            return

        parts = text.split()
        if parts and len(parts) <= 2 and re.fullmatch(r"[A-Za-z0-9.^=_:/-]{1,24}", parts[0]):
            frame_key = FRAME_ALIASES.get(parts[1].lower()) if len(parts) == 2 else None
            if len(parts) == 1 or parts[1].lower() in FRAME_ALIASES:
                await self._send_symbol_analysis(chat_id, parts[0], frame_key)
                return
        await super()._handle_text(chat_id, text)

    async def _handle_callback(self, callback: dict[str, Any]) -> None:
        callback_id = str(callback["id"])
        message = callback.get("message") or {}
        chat_id = int(message.get("chat", {}).get("id", 0))
        user_id = int(callback.get("from", {}).get("id", 0))
        data = str(callback.get("data", ""))

        if data.startswith("a:"):
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            parts = data.split(":")
            if len(parts) != 3 or parts[2] not in FRAME_CALLBACK:
                await self.telegram.answer_callback(callback_id, "فاصل غير صالح")
                return
            await self.telegram.answer_callback(callback_id, "تحديث التحليل")
            await self._send_symbol_analysis(chat_id, parts[1], FRAME_CALLBACK[parts[2]])
            return

        if data in {"menu:home", "menu:help"}:
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "القائمة الرئيسية")
            await self.telegram.send_message(chat_id, FOCUSED_HELP_TEXT, self._main_menu())
            return
        if data == "menu:active":
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "الخطط النشطة")
            await self._send_active_plans(chat_id)
            return
        if data == "menu:uslist":
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "القائمة الأمريكية")
            await self.telegram.send_message(chat_id, us_list_text(), self._main_menu())
            return
        if data == "menu:sources":
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "مصادر البيانات")
            await self.telegram.send_message(chat_id, sources_text(), self._main_menu())
            return
        if data == "system:status":
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "حالة النظام")
            await self.telegram.send_message(chat_id, await self._status_text(), self._main_menu())
            return
        await super()._handle_callback(callback)
