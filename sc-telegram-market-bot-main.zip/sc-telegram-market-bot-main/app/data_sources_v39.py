from __future__ import annotations

import math
import os
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx

from .audited_engine import AuditedMultiSourceProvider
from .data_sources import (
    ProviderResult,
    _BarchartProvider,
    _YahooFinanceProvider,
    _finite_candle,
    _parse_timestamp,
)
from .technical import Candle, MarketDataError, SymbolSpec


_INTERVAL_SECONDS = {
    "1m": 60,
    "5m": 300,
    "15m": 900,
    "30m": 1800,
    "1h": 3600,
    "1d": 86_400,
}


class ExtendedBinanceSpotProvider:
    provider_id = "binance"

    def __init__(self, timeout: float) -> None:
        self.timeout = timeout
        self.base_url = os.getenv(
            "BINANCE_API_BASE", "https://api.binance.com"
        ).rstrip("/")

    async def fetch(
        self, spec: SymbolSpec, period: str, interval: str
    ) -> ProviderResult:
        if spec.asset_class != "crypto":
            raise MarketDataError("السوق غير مدعوم في Binance")
        if interval not in _INTERVAL_SECONDS:
            raise MarketDataError("الفاصل غير مدعوم في Binance")
        pair = (
            spec.display_symbol.replace("-", "")
            .replace("/", "")
            .upper()
        )
        if pair.endswith("USD"):
            pair = pair[:-3] + "USDT"

        requested = _period_days(period) if interval == "1d" else 1000
        requested = max(60, min(4000, requested + (20 if interval == "1d" else 0)))
        page_count = max(1, math.ceil(requested / 1000))
        pages: list[list[Any]] = []
        end_time: int | None = None
        try:
            async with httpx.AsyncClient(
                timeout=self.timeout,
                follow_redirects=True,
            ) as client:
                for _ in range(page_count):
                    params: dict[str, Any] = {
                        "symbol": pair,
                        "interval": interval,
                        "limit": min(1000, requested),
                    }
                    if end_time is not None:
                        params["endTime"] = end_time
                    response = await client.get(
                        f"{self.base_url}/api/v3/klines",
                        params=params,
                        headers={"User-Agent": "SC-Market-Compass/4.1"},
                    )
                    response.raise_for_status()
                    rows = response.json()
                    if not isinstance(rows, list):
                        raise ValueError("invalid Binance response")
                    if not rows:
                        break
                    pages.append(rows)
                    requested -= len(rows)
                    if requested <= 0 or len(rows) < 1000:
                        break
                    end_time = int(rows[0][0]) - 1
        except (httpx.HTTPError, ValueError, TypeError, IndexError) as exc:
            raise MarketDataError("تعذر جلب شموع Binance") from exc

        candles_by_time: dict[int, Candle] = {}
        for rows in reversed(pages):
            for row in rows:
                if not isinstance(row, list) or len(row) < 6:
                    continue
                candle = _finite_candle(
                    int(row[0]) // 1000,
                    row[1],
                    row[2],
                    row[3],
                    row[4],
                    row[5],
                )
                if candle:
                    candles_by_time[candle.timestamp] = candle
        candles = sorted(candles_by_time.values(), key=lambda item: item.timestamp)
        now = int(datetime.now(timezone.utc).timestamp())
        seconds = _INTERVAL_SECONDS[interval]
        if candles and now < candles[-1].timestamp + seconds:
            candles.pop()
        if not candles:
            raise MarketDataError("لم تصل شموع صالحة من Binance")
        base_asset = pair.removesuffix("USDT")
        return ProviderResult(
            candles=candles,
            metadata={
                "longName": f"{base_asset}/USDT",
                "shortName": pair,
                "exchangeName": "Binance Spot",
                "currency": "USDT",
                "marketTimezone": "UTC",
                "continuousMarket": True,
            },
            provider_id=self.provider_id,
        )



def _period_days(period: str) -> int:
    text = period.strip().lower()
    try:
        if text.endswith("y"):
            return max(365, int(text[:-1]) * 365)
        if text.endswith("mo"):
            return max(30, int(text[:-2]) * 31)
        if text.endswith("d"):
            return max(1, int(text[:-1]))
    except ValueError:
        pass
    return 730


class ExtendedBarchartProvider(_BarchartProvider):
    async def fetch(
        self, spec: SymbolSpec, period: str, interval: str
    ) -> ProviderResult:
        if (
            self.disabled
            or spec.market != "US"
            or spec.asset_class != "stock"
        ):
            raise MarketDataError(
                "السوق غير مدعوم أو Barchart غير مفعّل"
            )
        now = datetime.now(timezone.utc)
        history_type = "daily" if interval == "1d" else "minutes"
        params: dict[str, Any] = {
            "apikey": self.api_key,
            "symbol": self._symbol(spec),
            "type": history_type,
            "startDate": (
                now - timedelta(days=_period_days(period) + 10)
            ).strftime("%Y%m%d%H%M%S"),
            "endDate": (
                now.strftime("%Y%m%d")
                if interval == "1d"
                else now.strftime("%Y%m%d%H%M%S")
            ),
            "maxRecords": 5000,
            "order": "asc",
            "splits": "true",
            "dividends": "true",
        }
        if interval != "1d":
            params["interval"] = 60 if interval == "1h" else 15
        try:
            async with httpx.AsyncClient(
                timeout=self.timeout,
                follow_redirects=True,
            ) as client:
                response = await client.get(
                    "https://ondemand.websol.barchart.com/getHistory.json",
                    params=params,
                    headers={
                        "User-Agent": "SC-Market-Compass/3.9"
                    },
                )
                if response.status_code in {401, 403}:
                    self.disabled = True
                response.raise_for_status()
                payload = response.json()
        except (httpx.HTTPError, ValueError) as exc:
            raise MarketDataError(
                "تعذر جلب شموع Barchart"
            ) from exc
        status = payload.get("status") or {}
        if int(status.get("code") or 0) != 200:
            raise MarketDataError(
                str(status.get("message") or "رفض Barchart الطلب")
            )
        candles: list[Candle] = []
        for row in payload.get("results") or []:
            try:
                timestamp = _parse_timestamp(
                    row.get("timestamp")
                    or row.get("tradingDay")
                )
            except ValueError:
                continue
            candle = _finite_candle(
                timestamp,
                row.get("open"),
                row.get("high"),
                row.get("low"),
                row.get("close"),
                row.get("volume"),
            )
            if candle:
                candles.append(candle)
        if not candles:
            raise MarketDataError(
                "لم تصل شموع صالحة من Barchart"
            )
        return ProviderResult(
            candles=sorted(
                candles, key=lambda item: item.timestamp
            ),
            metadata={
                "longName": spec.display_symbol,
                "shortName": spec.display_symbol,
                "exchangeName": "Barchart OnDemand",
                "currency": "USD",
                "marketTimezone": "America/New_York",
            },
            provider_id=self.provider_id,
        )


class V39DirectProvider:
    """Uses Binance for short crypto frames and Yahoo otherwise."""

    provider_id = "v39-direct"

    def __init__(self, timeout: float) -> None:
        self.binance = ExtendedBinanceSpotProvider(timeout)
        self.yahoo = _YahooFinanceProvider(timeout)

    async def fetch(
        self, spec: SymbolSpec, period: str, interval: str
    ) -> ProviderResult:
        if (
            spec.asset_class == "crypto"
            and interval in {"1m", "5m", "30m"}
        ):
            try:
                return await self.binance.fetch(
                    spec, period, interval
                )
            except MarketDataError:
                return await self.yahoo.fetch(
                    spec, period, interval
                )
        return await self.yahoo.fetch(spec, period, interval)


class V39MultiSourceProvider(AuditedMultiSourceProvider):
    def __init__(self, timeout: float = 12.0) -> None:
        super().__init__(timeout)
        self.binance = ExtendedBinanceSpotProvider(timeout)
        if self.barchart is not None:
            self.barchart = ExtendedBarchartProvider(
                self.barchart.api_key, timeout
            )


__all__ = [
    "ExtendedBarchartProvider",
    "ExtendedBinanceSpotProvider",
    "V39DirectProvider",
    "V39MultiSourceProvider",
    "_period_days",
]
