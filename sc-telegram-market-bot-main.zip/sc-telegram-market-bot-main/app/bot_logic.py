from __future__ import annotations

import asyncio
import html
import logging
import re
import secrets
from typing import Any

from .config import Settings
from .db import Database
from .formatting import (
    format_alert,
    format_health,
    format_opportunity,
    format_search_results,
    format_symbol_analysis,
)
from .market import market_ar, tradingview_chart_url
from .models import Opportunity, TradingViewAlert
from .telegram import TelegramClient

logger = logging.getLogger(__name__)

MARKET_COMMANDS = {
    "/saudi": "SAUDI",
    "/us": "US",
    "/forex": "FOREX",
    "/crypto": "CRYPTO",
}

HELP_TEXT = """<b>بوصلة الأسواق — واجهة Telegram</b>

ابدأ من الأزرار أو استخدم الأوامر:
/scan — البحث عن الفرص حسب السوق والفاصل
/recommendations — أفضل الترشيحات الفنية الحديثة
/active — جميع الفرص النشطة
/analyze SYMBOL — تحليل رمز عبر الفواصل المتاحة
/saudi — السوق السعودي
/us — السوق الأمريكي
/forex — العملات والمؤشرات
/options — اتجاهات CALL/PUT المبنية على الأصل الأمريكي
/status — حالة الخادم وآخر بيانات TradingView
/help — المساعدة

يمكنك إرسال الرمز مباشرة مثل: <code>AAPL</code> أو <code>1120</code> أو <code>EURUSD</code>.

<i>البوت للتحليل والتنبيهات فقط، ولا ينفذ أي صفقة ولا يتصل بمحفظة.</i>"""


class BotService:
    def __init__(
        self,
        settings: Settings,
        database: Database,
        telegram: TelegramClient,
    ) -> None:
        self.settings = settings
        self.db = database
        self.telegram = telegram

    async def _is_authorized(self, user_id: int, chat_id: int) -> bool:
        if user_id in self.settings.telegram_allowed_user_ids:
            return True
        if chat_id in self.settings.telegram_chat_ids:
            return True
        return await self.db.is_admin(user_id)

    @staticmethod
    def _main_menu() -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [
                    {"text": "🔎 البحث عن فرص", "callback_data": "menu:scan"},
                    {"text": "📊 تحليل رمز", "callback_data": "menu:analyze"},
                ],
                [
                    {"text": "⭐ الترشيحات", "callback_data": "recommend:ALL"},
                    {"text": "📂 الفرص النشطة", "callback_data": "search:ALL:ALL:0:60"},
                ],
                [
                    {"text": "🇸🇦 السعودي", "callback_data": "market:SAUDI"},
                    {"text": "🇺🇸 الأمريكي", "callback_data": "market:US"},
                ],
                [
                    {"text": "💱 العملات", "callback_data": "market:FOREX"},
                    {"text": "🧩 الأوبشن", "callback_data": "options:US"},
                ],
                [
                    {"text": "🩺 حالة النظام", "callback_data": "system:status"},
                    {"text": "ℹ️ المساعدة", "callback_data": "menu:help"},
                ],
            ]
        }

    @staticmethod
    def _market_menu() -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [
                    {"text": "🇸🇦 السعودي", "callback_data": "market:SAUDI"},
                    {"text": "🇺🇸 الأمريكي", "callback_data": "market:US"},
                ],
                [
                    {"text": "💱 العملات", "callback_data": "market:FOREX"},
                    {"text": "🌍 عالمي", "callback_data": "market:GLOBAL"},
                ],
                [{"text": "🌐 جميع الأسواق", "callback_data": "market:ALL"}],
                [{"text": "⬅️ الرئيسية", "callback_data": "menu:home"}],
            ]
        }

    @staticmethod
    def _horizon_menu(market: str) -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [{"text": "⚡ لحظي حتى ساعة", "callback_data": f"search:{market}:INTRADAY:0:60"}],
                [{"text": "📈 سوينق 2–4 ساعات", "callback_data": f"search:{market}:SWING:0:60"}],
                [{"text": "🗓 يومي وأعلى", "callback_data": f"search:{market}:DAILY:0:60"}],
                [{"text": "📚 كل الفواصل", "callback_data": f"search:{market}:ALL:0:60"}],
                [{"text": "⬅️ الأسواق", "callback_data": "menu:scan"}],
            ]
        }

    @staticmethod
    def _detail_buttons(op: Opportunity) -> dict[str, Any]:
        return {
            "inline_keyboard": [
                [
                    {"text": "🔄 تحديث التحليل", "callback_data": f"symbol:{op.ticker}"},
                    {"text": "📈 فتح TradingView", "url": tradingview_chart_url(op.tickerid)},
                ],
                [
                    {"text": "🔕 كتم الرمز", "callback_data": f"mute:{op.event_id}"},
                    {"text": "🏠 الرئيسية", "callback_data": "menu:home"},
                ],
            ]
        }

    @staticmethod
    def _result_buttons(
        opportunities: list[Opportunity],
        market: str,
        horizon: str,
        direction: int,
        min_score: int,
        options_mode: bool = False,
    ) -> dict[str, Any]:
        rows: list[list[dict[str, str]]] = []
        callback_prefix = "optionsearch" if options_mode else "search"
        for op in opportunities[:6]:
            rows.append(
                [
                    {
                        "text": f"📊 {op.ticker} · {op.timeframe}",
                        "callback_data": f"detail:{op.event_id}",
                    }
                ]
            )
        rows.extend(
            [
                [
                    {"text": "⬆️ صعود", "callback_data": f"{callback_prefix}:{market}:{horizon}:1:{min_score}"},
                    {"text": "⬇️ هبوط", "callback_data": f"{callback_prefix}:{market}:{horizon}:-1:{min_score}"},
                    {"text": "↕️ الكل", "callback_data": f"{callback_prefix}:{market}:{horizon}:0:{min_score}"},
                ],
                [
                    {"text": "قوة 60+", "callback_data": f"{callback_prefix}:{market}:{horizon}:{direction}:60"},
                    {"text": "قوة 70+", "callback_data": f"{callback_prefix}:{market}:{horizon}:{direction}:70"},
                    {"text": "قوة 80+", "callback_data": f"{callback_prefix}:{market}:{horizon}:{direction}:80"},
                ],
                [
                    {"text": "🔄 تحديث", "callback_data": f"{callback_prefix}:{market}:{horizon}:{direction}:{min_score}"},
                    {"text": "🏠 الرئيسية", "callback_data": "menu:home"},
                ],
            ]
        )
        return {"inline_keyboard": rows}

    async def configure_telegram(self) -> None:
        if not self.settings.public_base_url:
            return
        webhook_url = (
            f"{self.settings.public_base_url}/webhooks/telegram/"
            f"{self.settings.telegram_webhook_token}"
        )
        await self.telegram.configure_webhook(
            webhook_url,
            self.settings.telegram_header_secret,
            drop_pending_updates=False,
        )
        await self.telegram.set_commands()
        logger.info("Telegram webhook configured: %s", webhook_url)

    async def send_stored_notification(self, row: dict[str, Any]) -> None:
        payload = TradingViewAlert.model_validate_json(row["raw_json"])
        event_id = int(row["event_id"])
        chat_id = int(row["chat_id"])
        if await self.db.is_muted(chat_id, payload.tickerid):
            await self.db.mark_notification_skipped(int(row["notification_id"]))
            return
        opportunity = await self.db.get_opportunity_by_event(event_id)
        text = format_alert(payload, str(row["market"]))
        buttons = self._detail_buttons(opportunity) if opportunity else self._main_menu()
        try:
            await self.telegram.send_message(chat_id, text, buttons)
        except Exception as exc:
            attempts = int(row["attempts"]) + 1
            await self.db.mark_notification_failed(
                int(row["notification_id"]), attempts, repr(exc)
            )
            logger.exception("Telegram delivery failed; queued for retry")
        else:
            await self.db.mark_notification_sent(int(row["notification_id"]))

    async def drain_outbox_once(self) -> int:
        rows = await self.db.pending_notifications(limit=20)
        for row in rows:
            await self.send_stored_notification(row)
        return len(rows)

    async def run_outbox(self) -> None:
        while True:
            processed = await self.drain_outbox_once()
            await asyncio.sleep(1.0 if processed else 4.0)

    async def handle_update(self, update: dict[str, Any]) -> None:
        if "callback_query" in update:
            await self._handle_callback(update["callback_query"])
            return
        message = update.get("message") or update.get("edited_message")
        if not message:
            return
        chat_id = int(message["chat"]["id"])
        user_id = int(message.get("from", {}).get("id", 0))
        text = str(message.get("text", "")).strip()
        if not await self._is_authorized(user_id, chat_id):
            command, _, code = text.partition(" ")
            if (
                command.split("@", 1)[0].lower() == "/claim"
                and self.settings.telegram_bootstrap_code
                and secrets.compare_digest(
                    code.strip(), self.settings.telegram_bootstrap_code
                )
            ):
                claimed = await self.db.claim_first_admin(user_id, chat_id)
                if claimed:
                    await self.db.register_subscriber(
                        chat_id,
                        user_id,
                        str(message.get("chat", {}).get("type", "private")),
                    )
                    await self.telegram.send_message(
                        chat_id,
                        "✅ <b>تم ربط حسابك مديرًا للبوت.</b>\n\n"
                        "أرسل /start لفتح القائمة الرئيسية.",
                        self._main_menu(),
                    )
                else:
                    await self.telegram.send_message(
                        chat_id,
                        "⚠️ تم ربط مدير للبوت مسبقًا؛ لم يتغير المدير الحالي.",
                    )
            return
        await self.db.register_subscriber(
            chat_id, user_id, str(message.get("chat", {}).get("type", "private"))
        )
        await self._handle_text(chat_id, text)

    async def _send_search(
        self,
        chat_id: int,
        market: str = "ALL",
        horizon: str = "ALL",
        direction: int = 0,
        min_score: int | None = None,
        options_mode: bool = False,
    ) -> None:
        threshold = self.settings.default_min_score if min_score is None else min_score
        db_market = "US" if options_mode else (None if market == "ALL" else market)
        ops = await self.db.list_opportunities(
            market=db_market,
            horizon=horizon,
            direction=direction,
            min_score=threshold,
            limit=12,
            active_only=True,
            fresh_only=True,
        )
        title = "فرص الأوبشن الاتجاهية" if options_mode else "نتائج البحث الفني"
        text = format_search_results(
            title,
            ops,
            market="US" if options_mode else market,
            horizon=horizon,
            min_score=threshold,
            options_mode=options_mode,
        )
        await self.telegram.send_message(
            chat_id,
            text,
            self._result_buttons(
                ops,
                "US" if options_mode else market,
                horizon,
                direction,
                threshold,
                options_mode=options_mode,
            ),
        )

    async def _send_symbol_analysis(self, chat_id: int, symbol: str) -> None:
        clean = symbol.strip().upper()
        if not clean:
            await self.telegram.send_message(
                chat_id,
                "أرسل الرمز، مثال: <code>AAPL</code> أو <code>1120</code> أو <code>EURUSD</code>.",
            )
            return
        ops = await self.db.find_symbol(clean, limit=12)
        text = format_symbol_analysis(clean, ops)
        if ops:
            await self.telegram.send_message(chat_id, text, self._detail_buttons(ops[0]))
        else:
            await self.telegram.send_message(chat_id, text, self._main_menu())

    async def _handle_text(self, chat_id: int, text: str) -> None:
        command, _, arg = text.partition(" ")
        command = command.split("@", 1)[0].lower()
        arg = arg.strip()
        if text.startswith("حلل ") or text.startswith("تحليل "):
            arg = text.split(" ", 1)[1].strip()
            command = "/analyze"

        if command in {"/start", "/help"}:
            await self.telegram.send_message(chat_id, HELP_TEXT, self._main_menu())
            return
        if command == "/scan":
            await self.telegram.send_message(
                chat_id, "<b>اختر السوق الذي تريد البحث فيه:</b>", self._market_menu()
            )
            return
        if command in MARKET_COMMANDS:
            await self._send_search(chat_id, market=MARKET_COMMANDS[command])
            return
        if command in {"/active", "/top", "/recommendations"}:
            threshold = 70 if command in {"/top", "/recommendations"} else self.settings.default_min_score
            await self._send_search(chat_id, min_score=threshold)
            return
        if command == "/options":
            await self._send_search(chat_id, market="US", options_mode=True)
            return
        if command == "/analyze":
            await self._send_symbol_analysis(chat_id, arg)
            return
        if command == "/status":
            await self.telegram.send_message(
                chat_id, format_health(await self.db.health_snapshot()), self._main_menu()
            )
            return
        if command in {"/mute", "/unmute"}:
            if not arg:
                await self.telegram.send_message(chat_id, "أضف الرمز بعد الأمر.")
                return
            matches = await self.db.find_symbol(arg, limit=1)
            tickerid = matches[0].tickerid if matches else arg.upper()
            muted = command == "/mute"
            await self.db.set_mute(chat_id, tickerid, muted)
            state = "تم كتم" if muted else "تم إلغاء كتم"
            await self.telegram.send_message(
                chat_id, f"{state} <code>{html.escape(tickerid)}</code>."
            )
            return

        if text and not text.startswith("/") and len(text) <= 40 and re.fullmatch(r"[\w:./-]+", text, re.UNICODE):
            await self._send_symbol_analysis(chat_id, text)
            return
        await self.telegram.send_message(chat_id, HELP_TEXT, self._main_menu())

    async def _handle_callback(self, callback: dict[str, Any]) -> None:
        callback_id = str(callback["id"])
        message = callback.get("message") or {}
        chat_id = int(message.get("chat", {}).get("id", 0))
        user_id = int(callback.get("from", {}).get("id", 0))
        if not await self._is_authorized(user_id, chat_id):
            await self.telegram.answer_callback(callback_id, "غير مصرح")
            return
        await self.db.register_subscriber(
            chat_id, user_id, str(message.get("chat", {}).get("type", "private"))
        )
        data = str(callback.get("data", ""))
        parts = data.split(":")
        action = parts[0]

        if data == "menu:home":
            await self.telegram.answer_callback(callback_id, "القائمة الرئيسية")
            await self.telegram.send_message(chat_id, HELP_TEXT, self._main_menu())
            return
        if data == "menu:scan":
            await self.telegram.answer_callback(callback_id, "اختر السوق")
            await self.telegram.send_message(
                chat_id, "<b>اختر السوق الذي تريد البحث فيه:</b>", self._market_menu()
            )
            return
        if data == "menu:analyze":
            await self.telegram.answer_callback(callback_id, "أرسل الرمز")
            await self.telegram.send_message(
                chat_id,
                "📊 أرسل الرمز الآن فقط، مثل: <code>AAPL</code> أو <code>1120</code> أو <code>EURUSD</code>.",
            )
            return
        if data == "menu:help":
            await self.telegram.answer_callback(callback_id, "المساعدة")
            await self.telegram.send_message(chat_id, HELP_TEXT, self._main_menu())
            return
        if action == "market" and len(parts) == 2:
            market = parts[1]
            await self.telegram.answer_callback(callback_id, market_ar(market))
            await self.telegram.send_message(
                chat_id,
                f"<b>{html.escape(market_ar(market))}</b>\nاختر نوع الفاصل:",
                self._horizon_menu(market),
            )
            return
        if action in {"search", "optionsearch"} and len(parts) == 5:
            market, horizon = parts[1], parts[2]
            try:
                direction = int(parts[3])
                min_score = int(parts[4])
            except ValueError:
                await self.telegram.answer_callback(callback_id, "مرشح غير صالح")
                return
            await self.telegram.answer_callback(callback_id, "تم تحديث البحث")
            await self._send_search(
                chat_id,
                market,
                horizon,
                direction,
                min_score,
                options_mode=action == "optionsearch",
            )
            return
        if action == "recommend" and len(parts) == 2:
            await self.telegram.answer_callback(callback_id, "أفضل الترشيحات")
            await self._send_search(chat_id, market=parts[1], min_score=70)
            return
        if action == "options":
            await self.telegram.answer_callback(callback_id, "فرص CALL وPUT")
            await self._send_search(chat_id, market="US", options_mode=True)
            return
        if action == "system" and len(parts) == 2 and parts[1] == "status":
            await self.telegram.answer_callback(callback_id, "حالة النظام")
            await self.telegram.send_message(
                chat_id, format_health(await self.db.health_snapshot()), self._main_menu()
            )
            return
        if action == "detail" and len(parts) == 2 and parts[1].isdigit():
            op = await self.db.get_opportunity_by_event(int(parts[1]))
            if not op:
                await self.telegram.answer_callback(callback_id, "الفرصة غير موجودة")
                return
            await self.telegram.answer_callback(callback_id, "تفاصيل الفرصة")
            await self.telegram.send_message(
                chat_id, format_opportunity(op), self._detail_buttons(op)
            )
            return
        if action == "symbol" and len(parts) == 2:
            await self.telegram.answer_callback(callback_id, "تم تحديث التحليل")
            await self._send_symbol_analysis(chat_id, parts[1])
            return
        if action == "mute" and len(parts) == 2 and parts[1].isdigit():
            op = await self.db.get_opportunity_by_event(int(parts[1]))
            if not op:
                await self.telegram.answer_callback(callback_id, "الفرصة غير موجودة")
                return
            await self.db.set_mute(chat_id, op.tickerid, True)
            await self.telegram.answer_callback(callback_id, "تم كتم الرمز")
            return
        await self.telegram.answer_callback(callback_id, "أمر غير معروف")
