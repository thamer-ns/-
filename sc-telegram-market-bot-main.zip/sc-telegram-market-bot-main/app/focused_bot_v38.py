from __future__ import annotations

import html
import re
from typing import Any

from .focused_bot_v37 import LiveBotService as V37LiveBotService
from .focused_bot_v38_helpers import (
    FOCUSED_HELP_TEXT_V38,
    FRAME_ALIASES_V38,
    FRAME_CALLBACK_V38,
    build_analysis_buttons_v38,
    build_frame_menu_v38,
    build_frame_scan_buttons_v38,
    frame_label,
    parse_symbol_frame_v38,
)
from .formatting import format_symbol_analysis
from .presets_v37 import V37PresetScanner
from .school_engine_v38 import HORIZON_TO_FRAME, SchoolConsensusAnalyzer
from .school_format_v38 import format_analysis_v38, format_scan_v38
from .technical import MarketDataError
from .universes import US_FOCUS_UNIVERSE


class LiveBotService(V37LiveBotService):
    """V3.8 Telegram UX for school consensus and 1m-to-month analysis."""

    def __init__(self, settings, database, telegram) -> None:
        super().__init__(settings, database, telegram)
        self.live = SchoolConsensusAnalyzer()
        self.scanner = V37PresetScanner(self.live)

    @staticmethod
    def _analysis_buttons(symbol: str) -> dict[str, Any]:
        return build_analysis_buttons_v38(symbol)

    @staticmethod
    def _horizon_menu(market: str) -> dict[str, Any]:
        return build_frame_menu_v38(market)

    async def _status_text(self) -> str:
        base = await super()._status_text()
        return (
            base
            + "\n\n<b>محرك المدارس:</b> V3.8 — 9 مدارس مستقلة\n"
            + "<b>شرط الفرصة:</b> مدرستان متوافقتان أو مدرسة واحدة قوية قابلة للتنفيذ\n"
            + "<b>الفواصل:</b> 1د، 5د، 15د، 30د، ساعة، 4س، يومي، أسبوعي، شهري\n"
            + f"<b>القائمة الأمريكية:</b> {len(US_FOCUS_UNIVERSE)} سهمًا"
        )

    async def _send_symbol_analysis(
        self,
        chat_id: int,
        symbol: str,
        frame_key: str | None = None,
    ) -> None:
        clean = symbol.strip().upper()
        if not clean:
            await self.telegram.send_message(
                chat_id,
                "أرسل الرمز مثل <code>2222</code> أو <code>AAPL</code>، "
                "ثم الفاصل اختياريًا مثل <code>1m</code> أو <code>4h</code> أو <code>1w</code>.",
            )
            return
        await self.telegram.send_message(
            chat_id,
            f"⏳ تحليل <code>{html.escape(clean)}</code> — "
            f"{html.escape(frame_label(frame_key))} من الشموع المغلقة وبناء توافق المدارس...",
        )
        try:
            result = (
                await self.live.analyze_one(clean, frame_key)
                if frame_key
                else await self.live.analyze(clean)
            )
        except MarketDataError as exc:
            stored = await self.db.find_symbol(clean, limit=12)
            if stored:
                await self.telegram.send_message(
                    chat_id,
                    "⚠️ تعذر الجلب المباشر، وهذه آخر بيانات TradingView محفوظة:\n\n"
                    + format_symbol_analysis(clean, stored),
                    self._detail_buttons(stored[0]),
                )
                return
            await self.telegram.send_message(
                chat_id,
                "❌ <b>تعذر تحليل الرمز الآن.</b>\n\n"
                + f"السبب: {html.escape(str(exc))}",
                self._main_menu(),
            )
            return
        await self.telegram.send_message(
            chat_id,
            format_analysis_v38(result),
            self._analysis_buttons(result.display_symbol),
        )

    async def _send_frame_scan(
        self,
        chat_id: int,
        market: str,
        frame_key: str,
        direction: int = 0,
        min_score: int = 60,
    ) -> None:
        await self.telegram.send_message(
            chat_id,
            f"⏳ مسح <b>{html.escape(market)}</b> على فاصل "
            f"<b>{html.escape(frame_label(frame_key))}</b>؛ "
            "تُقبل مدرستان متوافقتان أو مدرسة واحدة قوية...",
        )
        try:
            report = await self.live.scan_frame_detailed(
                market,
                frame_key,
                direction,
                min_score,
                limit=10,
            )
        except MarketDataError as exc:
            await self.telegram.send_message(
                chat_id,
                "❌ تعذر تنفيذ المسح: " + html.escape(str(exc)),
                self._main_menu(),
            )
            return
        await self.telegram.send_message(
            chat_id,
            format_scan_v38(report),
            build_frame_scan_buttons_v38(
                list(report.items), market, frame_key, direction, min_score
            ),
        )

    async def _send_search(
        self,
        chat_id: int,
        market: str = "ALL",
        horizon: str = "ALL",
        direction: int = 0,
        min_score: int | None = None,
        options_mode: bool = False,
    ) -> None:
        threshold = self.settings.default_min_score if min_score is None else min_score
        selected = "US_OPTIONS" if options_mode else market
        if selected in {"SAUDI", "US", "US_OPTIONS", "FOREX", "CRYPTO"}:
            frame_key = HORIZON_TO_FRAME.get(horizon.upper(), "1d")
            await self._send_frame_scan(
                chat_id, selected, frame_key, direction, threshold
            )
            return
        await super()._send_search(
            chat_id, market, horizon, direction, threshold, options_mode
        )

    async def _handle_text(self, chat_id: int, text: str) -> None:
        command, _, argument = text.partition(" ")
        command = command.split("@", 1)[0].lower()
        argument = argument.strip()
        if text.startswith("حلل ") or text.startswith("تحليل "):
            command = "/analyze"
            argument = text.split(" ", 1)[1].strip()

        if command in {"/start", "/help"}:
            await self.telegram.send_message(
                chat_id, FOCUSED_HELP_TEXT_V38, self._main_menu()
            )
            return
        if command == "/analyze":
            symbol, frame_key = parse_symbol_frame_v38(argument)
            await self._send_symbol_analysis(chat_id, symbol, frame_key)
            return

        parts = text.split()
        if parts and len(parts) <= 2 and re.fullmatch(
            r"[A-Za-z0-9.^=_:/-]{1,24}", parts[0]
        ):
            frame_key = (
                FRAME_ALIASES_V38.get(parts[1].lower())
                if len(parts) == 2
                else None
            )
            if len(parts) == 1 or parts[1].lower() in FRAME_ALIASES_V38:
                await self._send_symbol_analysis(chat_id, parts[0], frame_key)
                return
        await super()._handle_text(chat_id, text)

    async def _handle_callback(self, callback: dict[str, Any]) -> None:
        callback_id = str(callback["id"])
        message = callback.get("message") or {}
        chat_id = int(message.get("chat", {}).get("id", 0))
        user_id = int(callback.get("from", {}).get("id", 0))
        data = str(callback.get("data", ""))

        if data.startswith("a38:"):
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            parts = data.split(":")
            if len(parts) != 3 or parts[2] not in FRAME_CALLBACK_V38:
                await self.telegram.answer_callback(callback_id, "فاصل غير صالح")
                return
            await self.telegram.answer_callback(callback_id, "تحديث التحليل")
            await self._send_symbol_analysis(
                chat_id, parts[1], FRAME_CALLBACK_V38[parts[2]]
            )
            return

        if data.startswith("sf:"):
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            parts = data.split(":")
            if len(parts) != 5:
                await self.telegram.answer_callback(callback_id, "طلب غير صالح")
                return
            market, frame_key = parts[1], parts[2]
            try:
                direction, score = int(parts[3]), int(parts[4])
            except ValueError:
                await self.telegram.answer_callback(callback_id, "قيم غير صالحة")
                return
            await self.telegram.answer_callback(callback_id, "بدء مسح المدارس")
            await self._send_frame_scan(
                chat_id, market, frame_key, direction, score
            )
            return

        if data in {"menu:home", "menu:help"}:
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "القائمة الرئيسية")
            await self.telegram.send_message(
                chat_id, FOCUSED_HELP_TEXT_V38, self._main_menu()
            )
            return
        await super()._handle_callback(callback)


FOCUSED_HELP_TEXT = FOCUSED_HELP_TEXT_V38
