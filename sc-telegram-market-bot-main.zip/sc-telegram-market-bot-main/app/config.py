from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path


def _csv_ints(value: str, *, name: str = "ID list") -> tuple[int, ...]:
    items: list[int] = []
    for raw in value.split(","):
        raw = raw.strip()
        if not raw:
            continue
        try:
            numeric = int(raw)
        except ValueError as exc:
            raise RuntimeError(f"{name} contains a non-integer value") from exc
        if numeric == 0:
            raise RuntimeError(f"{name} contains an invalid zero ID")
        items.append(numeric)
    return tuple(dict.fromkeys(items))


def _env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    raw = os.getenv(name, str(default)).strip()
    try:
        numeric = int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer") from exc
    return max(minimum, min(maximum, numeric))


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _safe_telegram_secret(value: str) -> bool:
    return (
        16 <= len(value) <= 256
        and re.fullmatch(r"[A-Za-z0-9_-]+", value) is not None
    )


@dataclass(frozen=True, slots=True)
class Settings:
    telegram_bot_token: str
    telegram_chat_ids: tuple[int, ...]
    telegram_allowed_user_ids: tuple[int, ...]
    tradingview_webhook_token: str
    telegram_webhook_token: str
    telegram_header_secret: str
    telegram_bootstrap_code: str
    public_base_url: str
    database_path: Path
    auto_configure_telegram_webhook: bool
    default_min_score: int
    app_name: str = "SC Market Compass Bot V4.1.1"

    @classmethod
    def from_env(cls) -> "Settings":
        public_url = (
            os.getenv("PUBLIC_BASE_URL", "").strip()
            or os.getenv("RENDER_EXTERNAL_URL", "").strip()
        ).rstrip("/")
        return cls(
            telegram_bot_token=os.getenv(
                "TELEGRAM_BOT_TOKEN", ""
            ).strip(),
            telegram_chat_ids=_csv_ints(
                os.getenv("TELEGRAM_CHAT_IDS", ""),
                name="TELEGRAM_CHAT_IDS",
            ),
            telegram_allowed_user_ids=_csv_ints(
                os.getenv("TELEGRAM_ALLOWED_USER_IDS", ""),
                name="TELEGRAM_ALLOWED_USER_IDS",
            ),
            tradingview_webhook_token=os.getenv(
                "TRADINGVIEW_WEBHOOK_TOKEN", ""
            ).strip(),
            telegram_webhook_token=os.getenv(
                "TELEGRAM_WEBHOOK_TOKEN", "change-me-telegram"
            ).strip(),
            telegram_header_secret=os.getenv(
                "TELEGRAM_HEADER_SECRET", ""
            ).strip(),
            telegram_bootstrap_code=os.getenv(
                "TELEGRAM_BOOTSTRAP_CODE", ""
            ).strip(),
            public_base_url=public_url,
            database_path=Path(
                os.getenv("DATABASE_PATH", "./data/sc_bot.sqlite3")
            ),
            auto_configure_telegram_webhook=_env_bool(
                "AUTO_CONFIGURE_TELEGRAM_WEBHOOK", False
            ),
            default_min_score=_env_int(
                "DEFAULT_MIN_SCORE", 60, 0, 100
            ),
        )

    def validate_runtime(self) -> None:
        missing: list[str] = []
        if not self.telegram_bot_token:
            missing.append("TELEGRAM_BOT_TOKEN")
        if (
            not self.telegram_allowed_user_ids
            and not self.telegram_chat_ids
            and not self.telegram_bootstrap_code
        ):
            missing.append(
                "TELEGRAM_BOOTSTRAP_CODE or allowed Telegram IDs"
            )
        if (
            len(self.telegram_webhook_token) < 24
            or self.telegram_webhook_token == "change-me-telegram"
        ):
            missing.append("strong TELEGRAM_WEBHOOK_TOKEN")
        if (
            self.auto_configure_telegram_webhook
            and not self.public_base_url
        ):
            missing.append("PUBLIC_BASE_URL or RENDER_EXTERNAL_URL")
        if self.telegram_bot_token and not _safe_telegram_secret(
            self.telegram_header_secret
        ):
            missing.append("valid TELEGRAM_HEADER_SECRET")
        if (
            self.telegram_bootstrap_code
            and len(self.telegram_bootstrap_code) < 16
        ):
            missing.append("strong TELEGRAM_BOOTSTRAP_CODE")
        if (
            self.tradingview_webhook_token
            and len(self.tradingview_webhook_token) < 24
        ):
            missing.append("strong TRADINGVIEW_WEBHOOK_TOKEN")
        if missing:
            raise RuntimeError(
                "Missing or unsafe settings: " + ", ".join(missing)
            )
