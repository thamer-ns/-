from __future__ import annotations

import asyncio
import math
import os
import time
from dataclasses import replace
from datetime import datetime, time as clock_time, timezone
from statistics import median
from typing import Any
from zoneinfo import ZoneInfo

from .data_sources import (
    CandleProvider,
    ProviderResult,
    _BarchartProvider,
    _BinanceSpotProvider,
    _WebullProvider,
    _YahooFinanceProvider,
)
from .market_data import FRAMES, LiveMarketAnalyzer
from .technical import (
    Candle,
    FrameAnalysis,
    LiveAnalysis,
    MarketDataError,
    SymbolSpec,
    _atr,
    _cluster,
    _ema,
    _engulfing,
    _pivot_levels,
    _round,
    _rsi,
    _structure,
    normalize_symbol,
)


class AuditedMultiSourceProvider:
    """Provider router with source-specific pacing and symbol normalization."""

    provider_id = "audited-multi-source"

    def __init__(self, timeout: float = 12.0) -> None:
        self.timeout = timeout
        self.yahoo = _YahooFinanceProvider(timeout)
        self.binance = _BinanceSpotProvider(timeout)
        webull_key = os.getenv("WEBULL_APP_KEY", "").strip()
        webull_secret = os.getenv("WEBULL_APP_SECRET", "").strip()
        barchart_key = os.getenv("BARCHART_API_KEY", "").strip()
        self.webull = (
            _WebullProvider(webull_key, webull_secret, timeout)
            if webull_key and webull_secret
            else None
        )
        self.barchart = _BarchartProvider(barchart_key, timeout) if barchart_key else None
        self._webull_lock = asyncio.Lock()
        self._webull_last_call = 0.0
        self._barchart_semaphore = asyncio.Semaphore(3)

    @staticmethod
    def _provider_spec(spec: SymbolSpec, provider_id: str) -> SymbolSpec:
        if provider_id == "webull" and spec.display_symbol == "BRK-B":
            return replace(spec, display_symbol="BRK.B")
        return spec

    @staticmethod
    def _with_metadata(result: ProviderResult, spec: SymbolSpec) -> ProviderResult:
        metadata = dict(result.metadata)
        if spec.market == "US":
            metadata.setdefault("marketTimezone", "America/New_York")
        elif spec.market == "SAUDI":
            metadata.setdefault("marketTimezone", "Asia/Riyadh")
        elif spec.market == "CRYPTO":
            metadata.setdefault("marketTimezone", "UTC")
            metadata.setdefault("continuousMarket", True)
        return ProviderResult(result.candles, metadata, result.provider_id)

    async def _fetch_webull(
        self, provider: CandleProvider, spec: SymbolSpec, period: str, interval: str
    ) -> ProviderResult:
        # Official Webull stock-bars limit is approximately one request per second
        # per App Key on the documented server-to-server surface.
        async with self._webull_lock:
            wait = 1.05 - (time.monotonic() - self._webull_last_call)
            if wait > 0:
                await asyncio.sleep(wait)
            try:
                return await provider.fetch(
                    self._provider_spec(spec, "webull"), period, interval
                )
            finally:
                self._webull_last_call = time.monotonic()

    async def fetch(
        self, spec: SymbolSpec, period: str, interval: str
    ) -> ProviderResult:
        if spec.asset_class == "crypto":
            providers: list[CandleProvider] = [self.binance, self.yahoo]
        elif spec.market == "US" and spec.asset_class == "stock":
            providers = [
                provider
                for provider in (self.webull, self.barchart, self.yahoo)
                if provider is not None
            ]
        else:
            providers = [self.yahoo]

        errors: list[str] = []
        for provider in providers:
            try:
                if provider.provider_id == "webull":
                    result = await self._fetch_webull(provider, spec, period, interval)
                elif provider.provider_id == "barchart":
                    async with self._barchart_semaphore:
                        result = await provider.fetch(spec, period, interval)
                else:
                    result = await provider.fetch(spec, period, interval)
                return self._with_metadata(result, spec)
            except MarketDataError as exc:
                errors.append(f"{provider.provider_id}: {exc}")
        raise MarketDataError(" | ".join(errors) or "لم يعمل أي مصدر بيانات")


def _reference_levels(
    candles: list[Candle], price: float, atr: float
) -> tuple[float, float, list[float]]:
    """Build levels known before the last two bars, so a breakout can be detected."""

    historical = candles[-140:-2] if len(candles) > 45 else candles[:-2]
    if len(historical) < 10:
        historical = candles[:-2]
    lows, highs = _pivot_levels(historical)
    tolerance = max(atr * 0.30, price * 0.002)
    clustered = [
        level
        for level, touches in (*_cluster(lows, tolerance), *_cluster(highs, tolerance))
        if touches >= 2
    ]
    levels = sorted(set(clustered))
    previous_close = candles[-2].close
    recent = candles[-22:-2] or candles[:-2]
    fallback_support = min(item.low for item in recent)
    fallback_resistance = max(item.high for item in recent)
    support_before = max((level for level in levels if level < previous_close), default=fallback_support)
    resistance_before = min((level for level in levels if level > previous_close), default=fallback_resistance)
    return support_before, resistance_before, levels


def _display_levels(
    candles: list[Candle], price: float, all_levels: list[float]
) -> tuple[float, float]:
    recent = candles[-22:-1] or candles[:-1]
    support = max(
        (level for level in all_levels if level < price),
        default=min(item.low for item in recent),
    )
    resistance = min(
        (level for level in all_levels if level > price),
        default=max(item.high for item in recent),
    )
    return support, resistance


def _setup_event_audited(
    candles: list[Candle], support: float, resistance: float, atr: float
) -> tuple[int, str, float | None]:
    current, previous = candles[-1], candles[-2]
    buffer = max(atr * 0.08, current.close * 0.0007)
    touch_tolerance = max(atr * 0.20, current.close * 0.001)
    max_overshoot = max(atr * 0.65, current.close * 0.004)

    bullish_break = previous.close <= resistance + buffer and current.close > resistance + buffer
    bearish_break = previous.close >= support - buffer and current.close < support - buffer
    recent_before = candles[-7:-1]
    broke_up_recently = any(item.close > resistance + buffer for item in recent_before)
    broke_down_recently = any(item.close < support - buffer for item in recent_before)
    bullish_retest = (
        broke_up_recently
        and resistance - max_overshoot <= current.low <= resistance + touch_tolerance
        and current.close > resistance + buffer * 0.25
    )
    bearish_retest = (
        broke_down_recently
        and support - touch_tolerance <= current.high <= support + max_overshoot
        and current.close < support - buffer * 0.25
    )
    if bullish_retest:
        return 1, "إعادة اختبار صاعدة مؤكدة", resistance
    if bearish_retest:
        return -1, "إعادة اختبار هابطة مؤكدة", support
    if bullish_break:
        return 1, "كسر مقاومة مؤكد", resistance
    if bearish_break:
        return -1, "كسر دعم مؤكد", support
    return 0, "لا يوجد زناد مؤكد", None


def _plan_audited(
    *,
    direction: int,
    event_direction: int,
    event_level: float | None,
    price: float,
    atr: float,
    levels: list[float],
    evidence: int,
    frame: str,
    short_history: bool,
) -> tuple[str, float | None, float | None, tuple[float, ...], float | None, list[str]]:
    warnings: list[str] = []
    if short_history:
        warnings.append("سجل الإدراج قصير؛ مُنع اعتماد خطة يومية حتى تتراكم 60 شمعة")
        return "مراقبة — سجل يومي قصير", None, None, (), None, warnings
    if direction == 0:
        return "لا توجد خطة — الاتجاه غير حاسم", None, None, (), None, warnings
    if event_direction != direction or event_level is None:
        return "مراقبة — الاتجاه قائم لكن زناد الدخول غير مؤكد", None, None, (), None, warnings
    if evidence < 55:
        return "مرشح مرفوض — الأدلة أقل من الحد", None, None, (), None, warnings
    if abs(price - event_level) > max(1.25 * atr, price * 0.025):
        warnings.append("السعر ابتعد عن مستوى الزناد؛ مُنع الدخول المتأخر")
        return "مراقبة — الدخول ممتد بعيدًا عن المستوى", None, None, (), None, warnings

    entry_buffer = max(atr * 0.06, price * 0.0006)
    stop_buffer = max(atr * 0.28, price * 0.0012)
    entry = max(price, event_level + entry_buffer) if direction > 0 else min(price, event_level - entry_buffer)
    if direction > 0:
        structural = max((level for level in levels if level < entry), default=event_level)
        stop = structural - stop_buffer
        risk = entry - stop
    else:
        structural = min((level for level in levels if level > entry), default=event_level)
        stop = structural + stop_buffer
        risk = stop - entry

    minimum_risk = max(atr * (0.60 if frame == "يومي" else 0.48), price * 0.002)
    maximum_risk = min(atr * (4.0 if frame == "يومي" else 2.8), price * 0.08)
    if risk < minimum_risk:
        stop = entry - minimum_risk if direction > 0 else entry + minimum_risk
        risk = minimum_risk
        warnings.append("وُسّع الوقف إلى حد التذبذب الأدنى بدل وقف ضيق هش")
    if risk <= 0 or risk > maximum_risk:
        warnings.append("مرساة الوقف البنيوية غير صالحة أو بعيدة")
        return "مرفوض — هندسة الوقف غير مناسبة", None, None, (), None, warnings

    forward = (
        sorted(level for level in levels if level > entry)
        if direction > 0
        else sorted((level for level in levels if level < entry), reverse=True)
    )
    if forward and abs(forward[0] - entry) < 0.75 * risk:
        warnings.append("عائق بنيوي قريب قبل عائد مقبول")
        return "مرفوض — لا توجد مساحة كافية قبل العائق", None, None, (), None, warnings

    targets: list[float] = []
    previous_target = entry
    for multiple in (1.0, 1.8, 2.6):
        nominal = entry + direction * risk * multiple
        if direction > 0:
            structural_targets = [level for level in forward if previous_target < level <= nominal]
        else:
            structural_targets = [level for level in forward if nominal <= level < previous_target]
        target = structural_targets[0] if structural_targets else nominal
        if targets and direction * (target - targets[-1]) <= 0:
            target = nominal
        targets.append(target)
        previous_target = target

    first_rr = abs(targets[0] - entry) / risk
    if first_rr < 0.75:
        return "مرفوض — عائد الهدف الأول ضعيف", None, None, (), None, warnings
    return "خطة مؤكدة بعد إغلاق الزناد", entry, stop, tuple(targets), first_rr, warnings


def analyze_frame_audited(
    candles: list[Candle], label: str, asset_class: str = "stock"
) -> FrameAnalysis:
    minimum = 35 if label == "يومي" else 60
    if len(candles) < minimum:
        raise MarketDataError(f"البيانات غير كافية لفاصل {label}")
    short_history = len(candles) < 60
    closes = [item.close for item in candles]
    price = closes[-1]
    ema20_series = _ema(closes, 20)
    ema50_series = _ema(closes, 50)
    ema200_series = _ema(closes, 200) if len(closes) >= 200 else []
    ema12, ema26 = _ema(closes, 12), _ema(closes, 26)
    macd = [left - right for left, right in zip(ema12, ema26)]
    signal = _ema(macd, 9)
    macd_hist = macd[-1] - signal[-1]
    rsi = _rsi(closes)
    atr = _atr(candles)
    if atr <= 0 or not math.isfinite(atr):
        raise MarketDataError(f"ATR غير صالح لفاصل {label}")

    prior_support, prior_resistance, all_levels = _reference_levels(candles, price, atr)
    display_support, display_resistance = _display_levels(candles, price, all_levels)
    structure_bias, structure_text, structure_event = _structure(candles, atr)
    event_direction, event_text, event_level = _setup_event_audited(
        candles, prior_support, prior_resistance, atr
    )
    engulfing = _engulfing(candles)
    volume_trusted = asset_class in {"stock", "crypto", "future"}
    baseline_volumes = [
        item.volume for item in candles[-31:-1] if item.volume > 0
    ]
    volume_ratio = None
    current_volume = candles[-1].volume
    if (
        volume_trusted
        and current_volume > 0
        and len(baseline_volumes) >= 10
    ):
        baseline = median(baseline_volumes)
        volume_ratio = current_volume / baseline if baseline > 0 else None

    ema20, ema50 = ema20_series[-1], ema50_series[-1]
    ema200 = ema200_series[-1] if ema200_series else None
    long_points = short_points = 0
    reasons: list[str] = []
    warnings: list[str] = []

    if structure_bias > 0:
        long_points += 20
        reasons.append("بنية داو صاعدة")
    elif structure_bias < 0:
        short_points += 20
        reasons.append("بنية داو هابطة")
    if price > ema20:
        long_points += 8
        reasons.append("السعر أعلى EMA20")
    else:
        short_points += 8
        reasons.append("السعر أدنى EMA20")
    if ema20 > ema50:
        long_points += 12
        reasons.append("EMA20 أعلى EMA50")
    else:
        short_points += 12
        reasons.append("EMA20 أدنى EMA50")
    if ema200 is not None:
        if ema50 > ema200:
            long_points += 8
        else:
            short_points += 8
    if macd_hist > 0:
        long_points += 10
    elif macd_hist < 0:
        short_points += 10
    if 52 <= rsi <= 72:
        long_points += 10
    elif 28 <= rsi <= 48:
        short_points += 10
    elif rsi > 78:
        warnings.append("تشبع شرائي مرتفع")
    elif rsi < 22:
        warnings.append("تشبع بيعي مرتفع")
    if event_direction > 0:
        long_points += 25
        reasons.append(event_text)
    elif event_direction < 0:
        short_points += 25
        reasons.append(event_text)
    elif engulfing > 0 and abs(price - display_support) <= 0.60 * atr:
        long_points += 7
        reasons.append("ابتلاع صاعد قرب دعم — مراقبة")
    elif engulfing < 0 and abs(price - display_resistance) <= 0.60 * atr:
        short_points += 7
        reasons.append("ابتلاع هابط قرب مقاومة — مراقبة")
    if volume_ratio is not None:
        if event_direction and volume_ratio >= 1.10:
            long_points += 7 if event_direction > 0 else 0
            short_points += 7 if event_direction < 0 else 0
            reasons.append("مشاركة حجم مؤهلة")
        elif event_direction and volume_ratio < 0.75:
            warnings.append("الكسر بحجم ضعيف")
    elif asset_class in {"forex", "index"}:
        warnings.append("الحجم غير مركزي؛ لم يدخل في الدرجة")
    if short_history:
        warnings.append(f"سجل حديث: {len(candles)} شمعة فقط؛ الثقة محدودة")

    long_evidence = min(100, long_points)
    short_evidence = min(100, short_points)
    score = max(0, min(100, round(50 + (long_points - short_points) * 0.5)))
    direction = (
        1
        if long_evidence >= 55 and long_evidence >= short_evidence + 10
        else -1
        if short_evidence >= 55 and short_evidence >= long_evidence + 10
        else 0
    )
    confidence = max(long_evidence, short_evidence)
    if short_history:
        confidence = min(confidence, 70)
    trend = "صاعد" if direction > 0 else "هابط" if direction < 0 else "محايد/انتقالي"
    plan_state, entry, stop, targets, rr, plan_warnings = _plan_audited(
        direction=direction,
        event_direction=event_direction,
        event_level=event_level,
        price=price,
        atr=atr,
        levels=all_levels,
        evidence=confidence,
        frame=label,
        short_history=short_history,
    )
    warnings.extend(plan_warnings)
    return FrameAnalysis(
        frame=label,
        price=_round(price, price),
        trend=trend,
        structure=structure_text,
        event=structure_event if structure_event != "لا كسر بنيوي جديد" else event_text,
        score=score,
        confidence=confidence,
        evidence_long=long_evidence,
        evidence_short=short_evidence,
        rsi=rsi,
        ema20=_round(ema20, price),
        ema50=_round(ema50, price),
        ema200=_round(ema200, price) if ema200 is not None else None,
        macd_hist=macd_hist,
        atr=_round(atr, price),
        atr_percent=(atr / price * 100.0) if price else 0.0,
        volume_ratio=volume_ratio,
        volume_trusted=volume_trusted,
        support=_round(display_support, price),
        resistance=_round(display_resistance, price),
        direction=direction,
        plan_state=plan_state,
        entry=_round(entry, price) if entry is not None else None,
        stop=_round(stop, price) if stop is not None else None,
        targets=tuple(_round(value, price) for value in targets),
        risk_reward=rr,
        reasons=tuple(dict.fromkeys(reasons)),
        warnings=tuple(dict.fromkeys(warnings)),
        updated_at=datetime.fromtimestamp(candles[-1].timestamp, tz=timezone.utc),
    )


class AuditedMarketAnalyzer(LiveMarketAnalyzer):
    """Corrects candle closure, multi-frame direction, current price and feed reporting."""

    def __init__(self, timeout: float | None = None, cache_seconds: int | None = None) -> None:
        resolved_timeout = timeout or float(os.getenv("MARKET_DATA_TIMEOUT", "12"))
        super().__init__(
            timeout=resolved_timeout,
            cache_seconds=cache_seconds,
            providers=[AuditedMultiSourceProvider(resolved_timeout)],
        )

    @staticmethod
    def _remove_incomplete_audited(
        spec: SymbolSpec,
        candles: list[Candle],
        interval_seconds: int,
        metadata: dict[str, Any],
    ) -> list[Candle]:
        if len(candles) < 2:
            return candles
        now_utc = datetime.now(timezone.utc)
        last = candles[-1]
        if interval_seconds < 86_400:
            zone_name = str(metadata.get("marketTimezone") or "")
            if not zone_name:
                zone_name = (
                    "America/New_York" if spec.market == "US"
                    else "Asia/Riyadh" if spec.market == "SAUDI"
                    else "UTC"
                )
            try:
                zone = ZoneInfo(zone_name)
            except Exception:
                zone = timezone.utc
            now_local = now_utc.astimezone(zone)
            last_local = datetime.fromtimestamp(
                last.timestamp, tz=timezone.utc
            ).astimezone(zone)
            if last_local.date() < now_local.date():
                return candles
            if last_local.date() > now_local.date():
                return candles[:-1]
            # The final equity bar can be shorter than the nominal interval.
            # It is complete after the exchange close/auction buffer.
            if spec.market == "SAUDI" and now_local.time() >= clock_time(15, 21):
                return candles
            if spec.market == "US" and now_local.time() >= clock_time(16, 5):
                return candles
            return (
                candles[:-1]
                if int(now_utc.timestamp()) < last.timestamp + interval_seconds + 90
                else candles
            )
        if metadata.get("continuousMarket"):
            return candles[:-1] if int(now_utc.timestamp()) < last.timestamp + 86_400 else candles

        regular = ((metadata.get("currentTradingPeriod") or {}).get("regular") or {})
        regular_end = int(regular.get("end") or 0)
        if regular_end and int(now_utc.timestamp()) < regular_end:
            last_day = datetime.fromtimestamp(last.timestamp, tz=timezone.utc).date()
            if last_day == now_utc.date():
                return candles[:-1]
            return candles

        zone_name = str(metadata.get("marketTimezone") or "")
        if not zone_name:
            zone_name = "America/New_York" if spec.market == "US" else "Asia/Riyadh" if spec.market == "SAUDI" else "UTC"
        try:
            zone = ZoneInfo(zone_name)
        except Exception:
            zone = timezone.utc
        now_local = now_utc.astimezone(zone)
        last_utc_date = datetime.fromtimestamp(last.timestamp, tz=timezone.utc).date()
        last_local_date = datetime.fromtimestamp(last.timestamp, tz=timezone.utc).astimezone(zone).date()
        same_session_date = now_local.date() in {last_local_date, last_utc_date}
        if not same_session_date:
            return candles
        close_time = clock_time(16, 15) if spec.market == "US" else clock_time(15, 21) if spec.market == "SAUDI" else clock_time(23, 59)
        return candles[:-1] if now_local.time() < close_time else candles

    async def _fetch(
        self, symbol: str, frame_key: str
    ) -> tuple[list[Any], dict[str, Any], str]:
        spec = normalize_symbol(symbol)
        period, interval, label, interval_seconds = FRAMES[frame_key]
        key = (spec.yahoo_symbol, frame_key)
        cached = self._cache.get(key)
        now_mono = time.monotonic()
        ttl = self.cache_seconds if frame_key != "1d" else max(self.cache_seconds, 600)
        if cached and now_mono - cached[0] <= ttl:
            return cached[1], cached[2], cached[3]
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            cached = self._cache.get(key)
            now_mono = time.monotonic()
            if cached and now_mono - cached[0] <= ttl:
                return cached[1], cached[2], cached[3]
            errors: list[str] = []
            for provider in self.providers:
                try:
                    result = await provider.fetch(spec, period, interval)
                    closed = self._remove_incomplete_audited(
                        spec, result.candles, interval_seconds, result.metadata
                    )
                    minimum = 35 if frame_key == "1d" else 60
                    if len(closed) < minimum:
                        raise MarketDataError(
                            f"وصلت {len(closed)} شمعة فقط بعد استبعاد الشمعة غير المكتملة لفاصل {label}"
                        )
                    self._cache[key] = (
                        time.monotonic(),
                        closed,
                        result.metadata,
                        result.provider_id,
                    )
                    self._prune_data_cache()
                    return closed, result.metadata, result.provider_id
                except MarketDataError as exc:
                    errors.append(f"{getattr(provider, 'provider_id', 'provider')}: {exc}")
            raise MarketDataError(" | ".join(errors) or "لم يعمل أي مصدر بيانات")

    @staticmethod
    def _build_audited(
        symbol: str,
        frames: list[FrameAnalysis],
        metadata: dict[str, Any],
        feed_sources: list[str],
    ) -> LiveAnalysis:
        spec = normalize_symbol(symbol)
        weights = {"يومي": 0.50, "ساعة": 0.35, "15 دقيقة": 0.15}
        total_weight = sum(weights.get(frame.frame, 0.10) for frame in frames)
        score = round(
            sum(frame.score * weights.get(frame.frame, 0.10) for frame in frames)
            / max(total_weight, 0.01)
        )
        daily = next((frame for frame in frames if frame.frame == "يومي"), None)
        hourly = next((frame for frame in frames if frame.frame == "ساعة"), None)
        strong_conflict = bool(
            daily
            and hourly
            and daily.direction
            and hourly.direction
            and daily.direction != hourly.direction
            and daily.confidence >= 60
            and hourly.confidence >= 60
        )
        directional = [frame for frame in frames if frame.direction]
        if strong_conflict:
            direction = 0
            alignment = "تعارض قوي بين اليومي والساعة"
            confidence = max(0, round(sum(frame.confidence for frame in frames) / len(frames)) - 15)
        elif not directional:
            direction = 0
            alignment = "الفواصل لم تجتز شروط اتجاه مؤكد"
            confidence = round(sum(frame.confidence for frame in frames) / len(frames))
        elif len(frames) == 1:
            direction = directional[0].direction
            alignment = f"قراءة فاصل واحد: {directional[0].frame}"
            confidence = directional[0].confidence
            score = directional[0].score
        else:
            signed = sum(
                frame.direction * frame.confidence * weights.get(frame.frame, 0.10)
                for frame in directional
            )
            strength = sum(
                frame.confidence * weights.get(frame.frame, 0.10)
                for frame in directional
            )
            ratio = signed / max(strength, 1.0)
            direction = 1 if ratio >= 0.25 else -1 if ratio <= -0.25 else 0
            matching = [frame for frame in directional if frame.direction == direction]
            confidence = (
                round(
                    sum(frame.confidence * weights.get(frame.frame, 0.10) for frame in matching)
                    / max(sum(weights.get(frame.frame, 0.10) for frame in matching), 0.01)
                )
                if direction
                else round(sum(frame.confidence for frame in frames) / len(frames))
            )
            signs = {frame.direction for frame in directional}
            if len(signs) == 1 and len(directional) == len(frames):
                alignment = "توافق كامل للفواصل"
            elif len(signs) == 1:
                alignment = "توافق جزئي مع فواصل محايدة"
            else:
                alignment = "توافق جزئي/مرحلة انتقال"

        adjusted: list[FrameAnalysis] = []
        for frame in frames:
            if (
                daily
                and frame.frame != "يومي"
                and daily.direction
                and frame.direction == -daily.direction
                and daily.confidence >= 65
            ):
                adjusted.append(
                    replace(
                        frame,
                        plan_state="مراقبة — الفاصل اليومي يعارض الخطة",
                        entry=None,
                        stop=None,
                        targets=(),
                        risk_reward=None,
                        warnings=tuple(dict.fromkeys((*frame.warnings, "تعارض مع الفاصل اليومي"))),
                    )
                )
            else:
                adjusted.append(frame)

        if strong_conflict:
            recommendation = "محايد — يمنع فتح خطة جديدة حتى ينخفض تعارض الفواصل"
        elif direction > 0 and confidence >= 70:
            recommendation = "إيجابي قوي — اعتمد فقط الخطة ذات الزناد المؤكد"
        elif direction > 0:
            recommendation = "إيجابي — مراقبة وتأكيد"
        elif direction < 0 and confidence >= 70:
            recommendation = "سلبي قوي — راقب كسرًا أو إعادة اختبار مؤكدة"
        elif direction < 0:
            recommendation = "سلبي — مراقبة وتأكيد"
        else:
            recommendation = "محايد/انتقالي — الانتظار أفضل"

        newest = max(adjusted, key=lambda frame: frame.updated_at)
        feed_source = " + ".join(dict.fromkeys(feed_sources)) or "unknown"
        return LiveAnalysis(
            query=spec.query,
            yahoo_symbol=spec.yahoo_symbol,
            display_symbol=spec.display_symbol,
            name=str(metadata.get("longName") or metadata.get("shortName") or spec.display_symbol),
            exchange=str(metadata.get("exchangeName") or metadata.get("fullExchangeName") or "غير محدد"),
            currency=str(metadata.get("currency") or ""),
            asset_class=spec.asset_class,
            price=newest.price,
            score=max(0, min(100, score)),
            confidence=max(0, min(100, confidence)),
            recommendation=recommendation,
            direction=direction,
            alignment=alignment,
            feed_source=feed_source,
            frames=tuple(adjusted),
            updated_at=newest.updated_at,
        )

    async def analyze(self, symbol: str) -> LiveAnalysis:
        spec = normalize_symbol(symbol)
        fetched = await asyncio.gather(
            *(self._fetch(symbol, key) for key in ("1d", "1h", "15m")),
            return_exceptions=True,
        )
        frames: list[FrameAnalysis] = []
        metadata_by_frame: list[tuple[datetime, dict[str, Any]]] = []
        feed_sources: list[str] = []
        errors: list[str] = []
        for key, item in zip(("1d", "1h", "15m"), fetched):
            if isinstance(item, Exception):
                errors.append(str(item))
                continue
            candles, metadata, provider_id = item
            frame = analyze_frame_audited(candles, FRAMES[key][2], spec.asset_class)
            frames.append(frame)
            metadata_by_frame.append((frame.updated_at, metadata))
            feed_sources.append(provider_id)
        if not frames:
            raise MarketDataError(errors[0] if errors else "لم تتوفر بيانات كافية لهذا الرمز")
        latest_metadata = max(metadata_by_frame, key=lambda item: item[0])[1]
        return self._build_audited(symbol, frames, latest_metadata, feed_sources)

    async def analyze_one(self, symbol: str, frame_key: str) -> LiveAnalysis:
        spec = normalize_symbol(symbol)
        candles, metadata, provider_id = await self._fetch(symbol, frame_key)
        frame = analyze_frame_audited(candles, FRAMES[frame_key][2], spec.asset_class)
        return self._build_audited(symbol, [frame], metadata, [provider_id])
