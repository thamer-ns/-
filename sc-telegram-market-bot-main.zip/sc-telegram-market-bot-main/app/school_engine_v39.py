from __future__ import annotations

import math
from dataclasses import dataclass, fields, replace
from typing import Any

from .audited_engine import analyze_frame_audited
from .market_data import ScanReport
from .opportunity_v37 import opportunity_state_rank
from .school_engine_v38 import FRAME_SPECS, SchoolFrameAnalysis
from .school_engine_v38_final import (
    FinalSchoolConsensusAnalyzer,
    apply_school_consensus_final,
    evaluate_school_consensus_final,
)
from .technical import (
    Candle,
    FrameAnalysis,
    LiveAnalysis,
    MarketDataError,
    normalize_symbol,
)
from .universes import UNIVERSE_LABELS


_TERMINAL_STATES = (
    "منتهية",
    "مكتملة",
    "كسر الوقف",
    "تعذر حسم",
)


@dataclass(frozen=True, slots=True)
class VerifiedSchoolFrameAnalysis(SchoolFrameAnalysis):
    """School frame with explicit qualification and plan validity."""

    consensus_qualified: bool = False
    plan_valid: bool = False
    opposing_school_names: tuple[str, ...] = ()


def _promote_verified(
    frame: SchoolFrameAnalysis,
    *,
    qualified: bool,
    plan_valid: bool,
    opposing_names: tuple[str, ...],
) -> VerifiedSchoolFrameAnalysis:
    values = {
        item.name: getattr(frame, item.name)
        for item in fields(SchoolFrameAnalysis)
    }
    return VerifiedSchoolFrameAnalysis(
        **values,
        consensus_qualified=qualified,
        plan_valid=plan_valid,
        opposing_school_names=opposing_names,
    )


def _valid_plan_geometry(frame: FrameAnalysis) -> bool:
    values = (frame.entry, frame.stop, *frame.targets)
    if (
        frame.direction not in (-1, 1)
        or frame.entry is None
        or frame.stop is None
        or len(frame.targets) != 3
        or not all(
            value is not None
            and math.isfinite(float(value))
            and float(value) > 0
            for value in values
        )
    ):
        return False
    if frame.direction > 0:
        return (
            frame.stop < frame.entry
            and all(target > frame.entry for target in frame.targets)
            and all(
                right > left
                for left, right in zip(
                    frame.targets, frame.targets[1:]
                )
            )
        )
    return (
        frame.stop > frame.entry
        and all(target < frame.entry for target in frame.targets)
        and all(
            right < left
            for left, right in zip(
                frame.targets, frame.targets[1:]
            )
        )
    )


def is_executable_opportunity(frame: FrameAnalysis) -> bool:
    return bool(
        getattr(frame, "consensus_qualified", False)
        and getattr(frame, "plan_valid", False)
        and _valid_plan_geometry(frame)
        and opportunity_state_rank(frame) >= 30
        and not any(
            marker in frame.plan_state for marker in _TERMINAL_STATES
        )
    )


def finalize_school_frame(
    candles: list[Candle],
    base_frame: FrameAnalysis,
    asset_class: str,
    *,
    market: str = "",
    frame_key: str = "",
) -> VerifiedSchoolFrameAnalysis:
    if market or frame_key:
        base_frame = replace(
            base_frame,
            market=market or base_frame.market,
            frame_key=frame_key or base_frame.frame_key,
        )
    consensus = evaluate_school_consensus_final(
        candles, base_frame, asset_class
    )
    enriched = apply_school_consensus_final(
        candles, base_frame, asset_class
    )
    opposing_names = tuple(
        signal.school for signal in consensus.opposing
    )

    if not consensus.qualified:
        extra_warnings = (
            ("تعارض مدارس: " + " + ".join(opposing_names),)
            if opposing_names
            else ()
        )
        warnings = tuple(
            dict.fromkeys(
                (
                    *enriched.warnings,
                    "مراقبة فقط: لم يتحقق شرط مدرستين مستقلتين أو مدرسة واحدة قوية قابلة للتنفيذ",
                    *extra_warnings,
                )
            )
        )
        neutral = replace(
            enriched,
            direction=0,
            trend="محايد/مراقبة",
            plan_state="مراقبة — توافق المدارس غير كافٍ",
            entry=None,
            stop=None,
            targets=(),
            risk_reward=None,
            risk_atr=None,
            target_atr=(),
            duration_low_bars=None,
            duration_high_bars=None,
            duration_samples=0,
            duration_success_rate=None,
            duration_method="",
            plan_profile="",
            confidence=min(
                enriched.confidence,
                max(0, consensus.strength),
            ),
            warnings=warnings,
        )
        return _promote_verified(
            neutral,
            qualified=False,
            plan_valid=False,
            opposing_names=opposing_names,
        )

    valid = _valid_plan_geometry(enriched)
    if not valid:
        warnings = tuple(
            dict.fromkeys(
                (
                    *enriched.warnings,
                    "توافق المدارس مؤهل، لكن هندسة الدخول والوقف والأهداف لم تجتز شروط التنفيذ",
                )
            )
        )
        enriched = replace(
            enriched,
            plan_state=(
                "رأي فني مؤهل — لا توجد خطة تنفيذ سليمة حاليًا"
            ),
            entry=None,
            stop=None,
            targets=(),
            risk_reward=None,
            risk_atr=None,
            target_atr=(),
            duration_low_bars=None,
            duration_high_bars=None,
            duration_samples=0,
            duration_success_rate=None,
            duration_method="",
            plan_profile="",
            warnings=warnings,
        )

    return _promote_verified(
        enriched,
        qualified=True,
        plan_valid=valid,
        opposing_names=opposing_names,
    )


class VerifiedSchoolConsensusAnalyzer(FinalSchoolConsensusAnalyzer):
    """Only qualified frames with valid plans may enter scans."""

    async def _analyze_frame(
        self, symbol: str, frame_key: str
    ) -> tuple[VerifiedSchoolFrameAnalysis, dict[str, Any], str]:
        if frame_key not in FRAME_SPECS:
            raise MarketDataError("الفاصل المطلوب غير مدعوم")
        spec = normalize_symbol(symbol)
        candles, metadata, provider_id = await self._fetch(
            symbol, frame_key
        )
        base = analyze_frame_audited(
            candles,
            FRAME_SPECS[frame_key].label,
            spec.asset_class,
        )
        base = replace(base, market=spec.market, frame_key=frame_key)
        return (
            finalize_school_frame(
                candles,
                base,
                spec.asset_class,
                market=spec.market,
                frame_key=frame_key,
            ),
            metadata,
            provider_id,
        )

    async def scan_frame_detailed(
        self,
        market: str,
        frame_key: str,
        direction: int,
        min_score: int,
        limit: int = 10,
    ) -> ScanReport:
        normalized = market.upper()
        if frame_key not in FRAME_SPECS:
            raise MarketDataError("الفاصل المطلوب غير مدعوم")
        items, total, analyzed = await self._scan_all(
            normalized, frame_key
        )
        filtered: list[LiveAnalysis] = []
        for item in items:
            if not item.frames:
                continue
            frame = item.frames[0]
            if not is_executable_opportunity(frame):
                continue
            if direction and frame.direction != direction:
                continue
            if frame.confidence < min_score:
                continue
            filtered.append(item)
        filtered.sort(
            key=lambda item: (
                opportunity_state_rank(item.frames[0]),
                len(getattr(item.frames[0], "independent_axes", ())),
                getattr(item.frames[0], "consensus_strength", 0),
                item.frames[0].confidence,
                abs(item.frames[0].score - 50),
            ),
            reverse=True,
        )
        return ScanReport(
            market=normalized,
            horizon=frame_key,
            universe_label=UNIVERSE_LABELS.get(
                normalized, normalized
            ),
            total_symbols=total,
            analyzed_symbols=analyzed,
            failed_symbols=max(0, total - analyzed),
            direction=direction,
            items=tuple(filtered[:limit]),
        )
