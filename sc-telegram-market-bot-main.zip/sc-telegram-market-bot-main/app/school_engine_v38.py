from __future__ import annotations

import asyncio
import math
import time
from dataclasses import dataclass, fields, replace
from datetime import datetime, time as clock_time, timedelta, timezone
from statistics import median, pstdev
from typing import Any
from zoneinfo import ZoneInfo

from .audited_engine import AuditedMarketAnalyzer, analyze_frame_audited
from .data_sources import _YahooFinanceProvider
from .market_safety_v37 import sanitize_candles
from .market_data import ScanReport
from .opportunity_v37 import OpportunityMarketAnalyzer, enrich_frame_opportunity, opportunity_state_rank
from .technical import (
    Candle,
    FrameAnalysis,
    LiveAnalysis,
    MarketDataError,
    _atr,
    _ema,
    _engulfing,
    _levels,
    _round,
    _rsi,
    _structure,
    normalize_symbol,
)
from .universes import UNIVERSE_LABELS


@dataclass(frozen=True, slots=True)
class FrameSpec:
    period: str
    source_interval: str
    label: str
    source_seconds: int
    target_seconds: int
    minimum: int
    family: str


FRAME_SPECS: dict[str, FrameSpec] = {
    "1m": FrameSpec("7d", "1m", "1 دقيقة", 60, 60, 80, "scalp"),
    "5m": FrameSpec("30d", "5m", "5 دقائق", 300, 300, 80, "scalp"),
    "15m": FrameSpec("30d", "15m", "15 دقيقة", 900, 900, 80, "intraday"),
    "30m": FrameSpec("60d", "30m", "30 دقيقة", 1800, 1800, 80, "intraday"),
    "1h": FrameSpec("60d", "1h", "ساعة", 3600, 3600, 80, "intraday"),
    "4h": FrameSpec("730d", "1h", "4 ساعات", 3600, 14400, 60, "swing"),
    "1d": FrameSpec("2y", "1d", "يومي", 86400, 86400, 60, "position"),
    "1w": FrameSpec("10y", "1d", "أسبوعي", 86400, 604800, 60, "investor"),
    "1mo": FrameSpec("10y", "1d", "شهري", 86400, 2_592_000, 60, "investor"),
}
FRAME_ORDER = tuple(FRAME_SPECS)
FRAME_WEIGHTS = {
    "1 دقيقة": 0.02,
    "5 دقائق": 0.04,
    "15 دقيقة": 0.07,
    "30 دقيقة": 0.09,
    "ساعة": 0.12,
    "4 ساعات": 0.16,
    "يومي": 0.20,
    "أسبوعي": 0.17,
    "شهري": 0.13,
}
HORIZON_TO_FRAME = {
    "SCALP": "5m",
    "INTRADAY": "15m",
    "SWING": "4h",
    "DAILY": "1d",
    "INVEST": "1w",
    "MONTHLY": "1mo",
}


@dataclass(frozen=True, slots=True)
class SchoolSignal:
    school: str
    direction: int
    strength: int
    signal_type: str
    reason: str
    actionable: bool = False


@dataclass(frozen=True, slots=True)
class SchoolConsensus:
    direction: int
    qualified: bool
    strength: int
    signal_type: str
    signals: tuple[SchoolSignal, ...]
    opposing: tuple[SchoolSignal, ...]
    strong_single: bool
    independent_axes: tuple[str, ...] = ()

    @property
    def school_names(self) -> tuple[str, ...]:
        return tuple(signal.school for signal in self.signals)


@dataclass(frozen=True, slots=True)
class SchoolFrameAnalysis(FrameAnalysis):
    school_count: int = 0
    school_names: tuple[str, ...] = ()
    school_details: tuple[str, ...] = ()
    signal_type: str = ""
    consensus_strength: int = 0
    strong_single_school: bool = False
    independent_axes: tuple[str, ...] = ()


def _promote(frame: FrameAnalysis, consensus: SchoolConsensus) -> SchoolFrameAnalysis:
    values = {item.name: getattr(frame, item.name) for item in fields(FrameAnalysis)}
    return SchoolFrameAnalysis(
        **values,
        school_count=len(consensus.signals),
        school_names=consensus.school_names,
        school_details=tuple(
            f"{item.school} (قوة {item.strength}/100): {item.reason}" for item in consensus.signals
        ),
        signal_type=consensus.signal_type,
        consensus_strength=consensus.strength,
        strong_single_school=consensus.strong_single,
        independent_axes=consensus.independent_axes,
    )


def _body_metrics(candle: Candle) -> tuple[float, float, float, float]:
    spread = max(candle.high - candle.low, 1e-12)
    body = abs(candle.close - candle.open)
    upper = candle.high - max(candle.open, candle.close)
    lower = min(candle.open, candle.close) - candle.low
    return spread, body, upper, lower


def _macd_hist_series(closes: list[float]) -> list[float]:
    fast = _ema(closes, 12)
    slow = _ema(closes, 26)
    macd = [left - right for left, right in zip(fast, slow)]
    signal = _ema(macd, 9)
    return [left - right for left, right in zip(macd, signal)]


def _school_signals(candles: list[Candle], frame: FrameAnalysis, asset_class: str) -> list[SchoolSignal]:
    closes = [bar.close for bar in candles]
    current, previous = candles[-1], candles[-2]
    price = current.close
    atr = max(_atr(candles), price * 0.0001)
    signals: list[SchoolSignal] = []

    structure_bias, structure_text, structure_event = _structure(candles, atr)
    if structure_bias:
        strength = 68
        signal_type = "استمرار اتجاه"
        actionable = False
        if "BOS" in structure_event:
            strength, signal_type, actionable = 84, "اختراق", True
        elif "CHoCH" in structure_event:
            strength, signal_type, actionable = 88, "انعكاس", True
        signals.append(
            SchoolSignal(
                "داو والبنية السعرية",
                structure_bias,
                strength,
                signal_type,
                structure_event if "جديد" not in structure_event else structure_text,
                actionable,
            )
        )

    ema20 = _ema(closes, 20)
    ema50 = _ema(closes, 50)
    ema200 = _ema(closes, 200) if len(closes) >= 200 else []
    slope20 = ema20[-1] - ema20[max(0, len(ema20) - 6)]
    if price > ema20[-1] > ema50[-1] and slope20 > 0:
        strength = 72 + (8 if ema200 and ema50[-1] > ema200[-1] else 0)
        signals.append(SchoolSignal("اتباع الاتجاه والمتوسطات", 1, strength, "استمرار اتجاه", "السعر فوق EMA20 وEMA20 فوق EMA50 مع ميل صاعد"))
    elif price < ema20[-1] < ema50[-1] and slope20 < 0:
        strength = 72 + (8 if ema200 and ema50[-1] < ema200[-1] else 0)
        signals.append(SchoolSignal("اتباع الاتجاه والمتوسطات", -1, strength, "استمرار اتجاه", "السعر تحت EMA20 وEMA20 تحت EMA50 مع ميل هابط"))

    hist = _macd_hist_series(closes)
    rsi_now = _rsi(closes)
    rsi_prev = _rsi(closes[:-1])
    if hist[-1] > 0 and hist[-1] >= hist[-2] and rsi_now >= 52:
        cross = hist[-2] <= 0 or rsi_prev <= 50 < rsi_now
        signals.append(SchoolSignal("الزخم (MACD وRSI)", 1, 84 if cross else 66, "تأكيد زخم", "زخم MACD موجب ومتسارع وRSI يدعم الصعود", cross))
    elif hist[-1] < 0 and hist[-1] <= hist[-2] and rsi_now <= 48:
        cross = hist[-2] >= 0 or rsi_prev >= 50 > rsi_now
        signals.append(SchoolSignal("الزخم (MACD وRSI)", -1, 84 if cross else 66, "تأكيد زخم", "زخم MACD سالب ومتزايد وRSI يدعم الهبوط", cross))

    support, resistance, _, _ = _levels(candles, price, atr)
    near_support = abs(price - support) <= 0.45 * atr
    near_resistance = abs(price - resistance) <= 0.45 * atr
    buffer = max(0.08 * atr, price * 0.0007)
    broke_up = previous.close <= resistance + buffer and price > resistance + buffer
    broke_down = previous.close >= support - buffer and price < support - buffer
    spread, body, upper, lower = _body_metrics(current)
    close_location = (current.close - current.low) / spread
    if broke_up:
        signals.append(SchoolSignal("الدعم والمقاومة", 1, 90, "اختراق", "إغلاق مؤكد فوق مقاومة كانت معروفة قبل الشمعة", True))
    elif broke_down:
        signals.append(SchoolSignal("الدعم والمقاومة", -1, 90, "اختراق", "إغلاق مؤكد تحت دعم كان معروفًا قبل الشمعة", True))
    elif near_support and current.close > current.open and close_location >= 0.65:
        signals.append(SchoolSignal("الدعم والمقاومة", 1, 75, "ارتداد", "رفض سعري صاعد من دعم قريب", True))
    elif near_resistance and current.close < current.open and close_location <= 0.35:
        signals.append(SchoolSignal("الدعم والمقاومة", -1, 75, "ارتداد", "رفض سعري هابط من مقاومة قريبة", True))

    engulfing = _engulfing(candles)
    hammer = lower >= max(body * 2.0, atr * 0.25) and upper <= max(body, atr * 0.12)
    shooting = upper >= max(body * 2.0, atr * 0.25) and lower <= max(body, atr * 0.12)
    if engulfing > 0 and near_support:
        signals.append(SchoolSignal("السلوك السعري والشموع", 1, 82, "انعكاس", "ابتلاع صاعد في سياق دعم", True))
    elif engulfing < 0 and near_resistance:
        signals.append(SchoolSignal("السلوك السعري والشموع", -1, 82, "انعكاس", "ابتلاع هابط في سياق مقاومة", True))
    elif hammer and near_support and current.close > current.open:
        signals.append(SchoolSignal("السلوك السعري والشموع", 1, 80, "انعكاس", "مطرقة صاعدة مؤكدة قرب دعم", True))
    elif shooting and near_resistance and current.close < current.open:
        signals.append(SchoolSignal("السلوك السعري والشموع", -1, 80, "انعكاس", "شهاب هابط مؤكد قرب مقاومة", True))

    trusted_volume = asset_class in {"stock", "crypto", "future"}
    positive_volumes = [bar.volume for bar in candles[-31:-1] if bar.volume > 0]
    baseline = median(positive_volumes) if len(positive_volumes) >= 10 else 0.0
    volume_ratio = current.volume / baseline if trusted_volume and baseline > 0 else None
    if volume_ratio is not None and volume_ratio >= 1.6:
        if current.close > current.open and close_location >= 0.70 and body / spread >= 0.55:
            signals.append(SchoolSignal("الحجم وVSA", 1, 82, "تأكيد طلب", f"شمعة طلب قوية بحجم {volume_ratio:.2f}×", True))
        elif current.close < current.open and close_location <= 0.30 and body / spread >= 0.55:
            signals.append(SchoolSignal("الحجم وVSA", -1, 82, "تأكيد عرض", f"شمعة عرض قوية بحجم {volume_ratio:.2f}×", True))

    recent = candles[-22:-1]
    prior_low = min(bar.low for bar in recent)
    prior_high = max(bar.high for bar in recent)
    spring = current.low < prior_low - 0.05 * atr and current.close > prior_low and close_location >= 0.60
    upthrust = current.high > prior_high + 0.05 * atr and current.close < prior_high and close_location <= 0.40
    vol_ok = volume_ratio is None or volume_ratio >= 1.15
    if spring and vol_ok:
        signals.append(SchoolSignal("وايكوف المبسط (عرض وطلب)", 1, 88, "انعكاس", "Spring: كسر كاذب للقاع ثم استرداد المستوى", True))
    elif upthrust and vol_ok:
        signals.append(SchoolSignal("وايكوف المبسط (عرض وطلب)", -1, 88, "انعكاس", "Upthrust: اختراق كاذب للقمة ثم إغلاق دونها", True))

    if len(closes) >= 40:
        basis = sum(closes[-20:]) / 20
        dev = pstdev(closes[-20:])
        upper_band, lower_band = basis + 2 * dev, basis - 2 * dev
        widths: list[float] = []
        for index in range(20, len(closes) + 1):
            sample = closes[index - 20:index]
            middle = sum(sample) / 20
            if middle:
                widths.append((4 * pstdev(sample)) / middle)
        window = widths[-80:]
        squeeze_threshold = sorted(window)[max(0, int(len(window) * 0.2) - 1)] if window else 0.0
        squeeze = bool(window and window[-1] <= squeeze_threshold)
        if price > upper_band and (squeeze or spread >= 1.3 * atr):
            signals.append(SchoolSignal("بولنجر والتذبذب", 1, 80 if squeeze else 72, "اختراق تذبذب", "خروج صاعد من نطاق بولنجر مع توسع التذبذب", True))
        elif price < lower_band and (squeeze or spread >= 1.3 * atr):
            signals.append(SchoolSignal("بولنجر والتذبذب", -1, 80 if squeeze else 72, "اختراق تذبذب", "خروج هابط من نطاق بولنجر مع توسع التذبذب", True))

    swing_sample = candles[-60:-1]
    swing_low = min(bar.low for bar in swing_sample)
    swing_high = max(bar.high for bar in swing_sample)
    swing = swing_high - swing_low
    if swing >= 3 * atr and structure_bias:
        if structure_bias > 0:
            fibs = [swing_high - swing * ratio for ratio in (0.382, 0.5, 0.618)]
            nearest = min(fibs, key=lambda level: abs(price - level))
            if abs(price - nearest) <= 0.35 * atr and current.close > current.open:
                signals.append(SchoolSignal("فيبوناتشي", 1, 68, "ارتداد", "ارتداد صاعد قرب منطقة تصحيح 38.2%–61.8%", True))
        else:
            fibs = [swing_low + swing * ratio for ratio in (0.382, 0.5, 0.618)]
            nearest = min(fibs, key=lambda level: abs(price - level))
            if abs(price - nearest) <= 0.35 * atr and current.close < current.open:
                signals.append(SchoolSignal("فيبوناتشي", -1, 68, "ارتداد", "ارتداد هابط قرب منطقة تصحيح 38.2%–61.8%", True))

    strongest: dict[str, SchoolSignal] = {}
    for signal in signals:
        old = strongest.get(signal.school)
        if old is None or signal.strength > old.strength:
            strongest[signal.school] = signal
    return list(strongest.values())


def evaluate_school_consensus(candles: list[Candle], frame: FrameAnalysis, asset_class: str) -> SchoolConsensus:
    signals = _school_signals(candles, frame, asset_class)
    long_signals = sorted((item for item in signals if item.direction > 0 and item.strength >= 55), key=lambda item: item.strength, reverse=True)
    short_signals = sorted((item for item in signals if item.direction < 0 and item.strength >= 55), key=lambda item: item.strength, reverse=True)
    long_total = sum(item.strength for item in long_signals)
    short_total = sum(item.strength for item in short_signals)
    if long_total == short_total:
        return SchoolConsensus(0, False, 0, "محايد", (), tuple(signals), False)
    direction = 1 if long_total > short_total else -1
    aligned = long_signals if direction > 0 else short_signals
    opposing = short_signals if direction > 0 else long_signals
    strongest = aligned[0] if aligned else None
    strong_single = bool(len(aligned) == 1 and strongest and strongest.strength >= 84 and strongest.actionable)
    multi = len(aligned) >= 2 and aligned[0].strength >= 60 and aligned[1].strength >= 58
    opposition_veto = bool(opposing and (opposing[0].strength >= 84 or (len(opposing) >= 2 and sum(item.strength for item in opposing[:2]) >= sum(item.strength for item in aligned[:2]) * 0.85)))
    qualified = (strong_single or multi) and not opposition_veto
    selected = tuple(aligned[:4]) if qualified else tuple(aligned[:2])
    average = round(sum(item.strength for item in selected) / max(len(selected), 1))
    strength = min(96, average + (6 if len(selected) >= 3 else 3 if len(selected) == 2 else 0))
    priorities = {"انعكاس": 6, "ارتداد": 5, "اختراق": 4, "اختراق تذبذب": 4, "تأكيد طلب": 3, "تأكيد عرض": 3, "تأكيد زخم": 2, "استمرار اتجاه": 1}
    signal_type = max(selected, key=lambda item: priorities.get(item.signal_type, 0)).signal_type if selected else "محايد"
    return SchoolConsensus(direction if qualified else 0, qualified, strength if qualified else average, signal_type, selected, tuple(opposing[:3]), strong_single)


def _school_plan(candles: list[Candle], frame: SchoolFrameAnalysis, consensus: SchoolConsensus) -> SchoolFrameAnalysis:
    if not consensus.qualified or consensus.direction == 0:
        return frame
    if consensus.signal_type not in {"انعكاس", "ارتداد", "تأكيد طلب", "تأكيد عرض"} or not any(item.actionable for item in consensus.signals):
        return frame
    direction = consensus.direction
    price = candles[-1].close
    atr = max(_atr(candles), price * 0.0001)
    recent = candles[-22:-1]
    entry = price
    if direction > 0:
        structural = min(frame.support, min(bar.low for bar in recent[-8:]))
        stop = structural - 0.25 * atr
        risk = entry - stop
    else:
        structural = max(frame.resistance, max(bar.high for bar in recent[-8:]))
        stop = structural + 0.25 * atr
        risk = stop - entry
    minimum = max(0.50 * atr, price * 0.002)
    maximum = min(3.5 * atr, price * 0.08)
    risk = max(risk, minimum)
    if risk > maximum:
        return replace(frame, warnings=tuple(dict.fromkeys((*frame.warnings, "إشارة مدارس جيدة لكن الوقف البنيوي بعيد؛ لم تُعتمد الخطة"))))
    stop = entry - direction * risk
    targets = tuple(entry + direction * risk * multiple for multiple in (1.0, 1.8, 2.6))
    qualifier = "مدرسة واحدة قوية" if consensus.strong_single else f"توافق {len(consensus.signals)} مدارس"
    reasons = tuple(dict.fromkeys((*frame.reasons, f"سبب الرأي: {qualifier}", *(f"مدرسة {item.school}: {item.reason}" for item in consensus.signals), "تقدم الخطة: 0/3")))
    return replace(frame, event=f"{consensus.signal_type} بتأكيد مدارس", plan_state=f"فرصة {consensus.signal_type} محتملة — {qualifier}", entry=_round(entry, price), stop=_round(stop, price), targets=tuple(_round(target, price) for target in targets), risk_reward=1.0, reasons=reasons)


def apply_school_consensus(candles: list[Candle], frame: FrameAnalysis, asset_class: str) -> SchoolFrameAnalysis:
    consensus = evaluate_school_consensus(candles, frame, asset_class)
    promoted = _promote(frame, consensus)
    if not consensus.qualified:
        if consensus.opposing:
            return replace(promoted, warnings=tuple(dict.fromkeys((*promoted.warnings, "لا توجد فرصة مدارس مكتملة؛ الإشارات متعارضة أو غير كافية"))))
        return promoted
    direction = consensus.direction
    evidence = max(promoted.confidence, consensus.strength)
    school_reason = (f"توافق المدارس: {len(consensus.signals)} — " + " + ".join(consensus.school_names) if len(consensus.signals) >= 2 else f"مدرسة واحدة قوية: {consensus.school_names[0]}")
    updated = replace(
        promoted,
        direction=direction,
        trend="صاعد" if direction > 0 else "هابط",
        confidence=min(96, evidence),
        score=(max(promoted.score, min(100, 50 + round(evidence * 0.45))) if direction > 0 else min(promoted.score, max(0, 50 - round(evidence * 0.45)))),
        reasons=tuple(dict.fromkeys((school_reason, *(f"مدرسة {item.school} ({item.strength}%): {item.reason}" for item in consensus.signals), *promoted.reasons))),
        warnings=tuple(dict.fromkeys((*promoted.warnings, *(("توجد مدرسة معاكسة قوية؛ لا تُدمج الإشارات دون وقف",) if consensus.opposing else ())))),
    )
    enriched = enrich_frame_opportunity(candles, updated)
    return _school_plan(candles, enriched, consensus)


def _timezone(metadata: dict[str, Any], market: str) -> ZoneInfo:
    name = str(metadata.get("marketTimezone") or "")
    if not name:
        name = "America/New_York" if market == "US" else "Asia/Riyadh" if market == "SAUDI" else "UTC"
    try:
        return ZoneInfo(name)
    except Exception:
        return ZoneInfo("UTC")


def _aggregate(group: list[Candle]) -> Candle:
    return Candle(group[0].timestamp, group[0].open, max(bar.high for bar in group), min(bar.low for bar in group), group[-1].close, sum(max(0.0, bar.volume) for bar in group))


def _equity_period_complete(
    frame_key: str, market: str, now_local: datetime
) -> bool:
    """Whether the current exchange week/month has finished trading.

    A period can be complete while its calendar key is still current (for
    example Saudi Friday or US Saturday).  Keeping this separate prevents
    dropping a fully closed weekly candle all weekend.
    """

    if market not in {"SAUDI", "US", "US_OPTIONS"}:
        return False
    weekday = now_local.weekday()  # Monday=0 ... Sunday=6
    if market == "SAUDI":
        trading_weekdays = {6, 0, 1, 2, 3}
        close = clock_time(15, 21)
        last_weekday = 3  # Thursday
    else:
        trading_weekdays = {0, 1, 2, 3, 4}
        close = clock_time(16, 5)
        last_weekday = 4  # Friday

    if frame_key == "1w":
        weekend = {4, 5} if market == "SAUDI" else {5, 6}
        return weekday in weekend or (
            weekday == last_weekday and now_local.time() >= close
        )

    if frame_key != "1mo":
        return False
    # Current month is complete only when no later exchange trading date
    # remains in the month and today's session (if any) has closed.
    cursor = now_local.date() + timedelta(days=1)
    while cursor.month == now_local.month:
        if cursor.weekday() in trading_weekdays:
            return False
        cursor += timedelta(days=1)
    return (
        weekday not in trading_weekdays
        or now_local.time() >= close
    )


def resample_candles(candles: list[Candle], frame_key: str, market: str, metadata: dict[str, Any]) -> list[Candle]:
    if frame_key not in {"4h", "1w", "1mo"}:
        return candles
    zone = _timezone(metadata, market)
    groups: list[list[Candle]] = []
    if frame_key == "4h" and market in {"US", "SAUDI"}:
        by_day: dict[Any, list[Candle]] = {}
        for bar in candles:
            day = datetime.fromtimestamp(bar.timestamp, tz=timezone.utc).astimezone(zone).date()
            by_day.setdefault(day, []).append(bar)
        for day in sorted(by_day):
            day_bars = sorted(by_day[day], key=lambda bar: bar.timestamp)
            groups.extend(day_bars[index:index + 4] for index in range(0, len(day_bars), 4))
    else:
        bucketed: dict[Any, list[Candle]] = {}
        for bar in candles:
            local = datetime.fromtimestamp(bar.timestamp, tz=timezone.utc).astimezone(zone)
            if frame_key == "4h":
                key = (local.date(), local.hour // 4)
            elif frame_key == "1w":
                if market == "SAUDI":
                    # Saudi Exchange trading week starts on Sunday.
                    days_since_sunday = (local.weekday() + 1) % 7
                    key = local.date() - timedelta(days=days_since_sunday)
                else:
                    iso = local.isocalendar()
                    key = (iso.year, iso.week)
            else:
                key = (local.year, local.month)
            bucketed.setdefault(key, []).append(bar)
        groups = [bucketed[key] for key in sorted(bucketed)]
    result = [_aggregate(group) for group in groups if group]
    now_local = datetime.now(timezone.utc).astimezone(zone)
    if result and frame_key in {"1w", "1mo"}:
        last_local = datetime.fromtimestamp(
            result[-1].timestamp, tz=timezone.utc
        ).astimezone(zone)
        if frame_key == "1w" and market == "SAUDI":
            last_week = last_local.date() - timedelta(
                days=(last_local.weekday() + 1) % 7
            )
            current_week = now_local.date() - timedelta(
                days=(now_local.weekday() + 1) % 7
            )
            same_period = last_week == current_week
        elif frame_key == "1w":
            same_period = (
                last_local.isocalendar()[:2]
                == now_local.isocalendar()[:2]
            )
        else:
            same_period = (last_local.year, last_local.month) == (
                now_local.year,
                now_local.month,
            )
        incomplete = same_period and not _equity_period_complete(
            frame_key, market, now_local
        )
        if incomplete:
            result.pop()
    return result


class SchoolConsensusAnalyzer(OpportunityMarketAnalyzer):
    """Independent-school consensus from one minute through monthly."""

    def __init__(self, timeout: float | None = None, cache_seconds: int | None = None) -> None:
        super().__init__(timeout=timeout, cache_seconds=cache_seconds)
        self._v38_yahoo = _YahooFinanceProvider(self.timeout)

    async def _fetch(self, symbol: str, frame_key: str) -> tuple[list[Candle], dict[str, Any], str]:
        spec = normalize_symbol(symbol)
        frame_spec = FRAME_SPECS.get(frame_key)
        if frame_spec is None:
            raise MarketDataError("الفاصل المطلوب غير مدعوم")
        key = (spec.yahoo_symbol, f"v38:{frame_key}")
        cached = self._cache.get(key)
        now_mono = time.monotonic()
        ttl = self.cache_seconds if frame_spec.family not in {"position", "investor"} else max(self.cache_seconds, 600)
        if cached and now_mono - cached[0] <= ttl:
            return cached[1], cached[2], cached[3]
        lock = self._locks.setdefault(key, asyncio.Lock())
        async with lock:
            cached = self._cache.get(key)
            if cached and time.monotonic() - cached[0] <= ttl:
                return cached[1], cached[2], cached[3]
            router = self.providers[0]
            direct_yahoo = frame_spec.source_interval in {"1m", "5m", "30m"}
            result = await (self._v38_yahoo.fetch(spec, frame_spec.period, frame_spec.source_interval) if direct_yahoo else router.fetch(spec, frame_spec.period, frame_spec.source_interval))
            raw = AuditedMarketAnalyzer._remove_incomplete_audited(spec, sanitize_candles(result.candles), frame_spec.source_seconds, result.metadata)
            candles = sanitize_candles(resample_candles(raw, frame_key, spec.market, result.metadata))
            if len(candles) < frame_spec.minimum and result.provider_id == "binance":
                fallback = await self._v38_yahoo.fetch(spec, frame_spec.period, frame_spec.source_interval)
                raw = AuditedMarketAnalyzer._remove_incomplete_audited(spec, sanitize_candles(fallback.candles), frame_spec.source_seconds, fallback.metadata)
                candles = sanitize_candles(resample_candles(raw, frame_key, spec.market, fallback.metadata))
                result = fallback
            if len(candles) < frame_spec.minimum:
                raise MarketDataError(f"وصلت {len(candles)} شمعة صالحة فقط لفاصل {frame_spec.label}")
            self._cache[key] = (time.monotonic(), candles, result.metadata, result.provider_id)
            self._prune_data_cache()
            return candles, result.metadata, result.provider_id

    @staticmethod
    def _build_v38(symbol: str, frames: list[FrameAnalysis], metadata: dict[str, Any], feed_sources: list[str]) -> LiveAnalysis:
        spec = normalize_symbol(symbol)
        weights = [FRAME_WEIGHTS.get(frame.frame, 0.08) for frame in frames]
        signed = sum(frame.direction * frame.confidence * weight for frame, weight in zip(frames, weights) if frame.direction)
        strength = sum(frame.confidence * weight for frame, weight in zip(frames, weights) if frame.direction)
        ratio = signed / max(strength, 1.0)
        direction = 1 if ratio >= 0.22 else -1 if ratio <= -0.22 else 0
        score = round(sum(frame.score * weight for frame, weight in zip(frames, weights)) / max(sum(weights), 0.01))
        matching = [frame for frame in frames if frame.direction == direction] if direction else []
        confidence = round(sum(frame.confidence for frame in matching) / len(matching)) if matching else round(sum(frame.confidence for frame in frames) / len(frames))
        higher = [frame for frame in frames if frame.frame in {"يومي", "أسبوعي", "شهري"} and frame.direction]
        execution = [frame for frame in frames if frame.frame in {"15 دقيقة", "30 دقيقة", "ساعة", "4 ساعات"} and frame.direction]
        conflict = bool(higher and execution and max(higher, key=lambda frame: frame.confidence).direction != max(execution, key=lambda frame: frame.confidence).direction and max(frame.confidence for frame in higher) >= 65 and max(frame.confidence for frame in execution) >= 65)
        if conflict:
            direction = 0
            confidence = max(0, confidence - 12)
            alignment = "تعارض بين فواصل التنفيذ والسياق الاستثماري"
            recommendation = "تعارض فواصل — اعتمد كل فرصة على فاصلها ولا توحّد الاتجاه"
        else:
            signs = {frame.direction for frame in frames if frame.direction}
            alignment = "توافق كامل للفواصل" if len(signs) == 1 and all(frame.direction for frame in frames) else "توافق جزئي مع فواصل محايدة" if len(signs) == 1 else "توافق جزئي/مرحلة انتقال" if signs else "الفواصل محايدة"
            recommendation = "إيجابي — توجد فرصة صعود حسب المدارس والفاصل" if direction > 0 else "سلبي — توجد فرصة هبوط حسب المدارس والفاصل" if direction < 0 else "محايد — لا يوجد توافق مدارس كافٍ للاتجاه العام"
        newest = max(frames, key=lambda frame: frame.updated_at)
        return LiveAnalysis(query=spec.query, yahoo_symbol=spec.yahoo_symbol, display_symbol=spec.display_symbol, name=str(metadata.get("longName") or metadata.get("shortName") or spec.display_symbol), exchange=str(metadata.get("exchangeName") or metadata.get("fullExchangeName") or "غير محدد"), currency=str(metadata.get("currency") or ""), asset_class=spec.asset_class, price=newest.price, score=max(0, min(100, score)), confidence=max(0, min(100, confidence)), recommendation=recommendation, direction=direction, alignment=alignment, feed_source=" + ".join(dict.fromkeys(feed_sources)) or "unknown", frames=tuple(frames), updated_at=newest.updated_at, market=spec.market)

    async def _analyze_frame(self, symbol: str, frame_key: str) -> tuple[SchoolFrameAnalysis, dict[str, Any], str]:
        spec = normalize_symbol(symbol)
        candles, metadata, provider_id = await self._fetch(symbol, frame_key)
        frame = analyze_frame_audited(candles, FRAME_SPECS[frame_key].label, spec.asset_class)
        frame = replace(frame, market=spec.market, frame_key=frame_key)
        return apply_school_consensus(candles, frame, spec.asset_class), metadata, provider_id

    async def analyze(self, symbol: str) -> LiveAnalysis:
        fetched = await asyncio.gather(*(self._analyze_frame(symbol, key) for key in FRAME_ORDER), return_exceptions=True)
        frames: list[FrameAnalysis] = []
        metadata_by_frame: list[tuple[datetime, dict[str, Any]]] = []
        sources: list[str] = []
        errors: list[str] = []
        for item in fetched:
            if isinstance(item, Exception):
                errors.append(str(item))
                continue
            frame, metadata, provider = item
            frames.append(frame)
            metadata_by_frame.append((frame.updated_at, metadata))
            sources.append(provider)
        if not frames:
            raise MarketDataError(errors[0] if errors else "لم تتوفر بيانات كافية")
        metadata = max(metadata_by_frame, key=lambda item: item[0])[1]
        return self._build_v38(symbol, frames, metadata, sources)

    async def analyze_one(self, symbol: str, frame_key: str) -> LiveAnalysis:
        frame, metadata, source = await self._analyze_frame(symbol, frame_key)
        return self._build_v38(symbol, [frame], metadata, [source])

    async def scan_frame_detailed(self, market: str, frame_key: str, direction: int, min_score: int, limit: int = 10) -> ScanReport:
        normalized = market.upper()
        if frame_key not in FRAME_SPECS:
            raise MarketDataError("الفاصل المطلوب غير مدعوم")
        items, total, analyzed = await self._scan_all(normalized, frame_key)
        filtered: list[LiveAnalysis] = []
        for item in items:
            frame = item.frames[0]
            if not getattr(frame, "school_count", 0):
                continue
            if direction and frame.direction != direction:
                continue
            if frame.direction == 0 or frame.confidence < min_score:
                continue
            filtered.append(item)
        filtered.sort(key=lambda item: (opportunity_state_rank(item.frames[0]), getattr(item.frames[0], "school_count", 0), getattr(item.frames[0], "consensus_strength", 0), item.confidence), reverse=True)
        return ScanReport(market=normalized, horizon=frame_key, universe_label=UNIVERSE_LABELS.get(normalized, normalized), total_symbols=total, analyzed_symbols=analyzed, failed_symbols=max(0, total - analyzed), direction=direction, items=tuple(filtered[:limit]))

    async def scan_market_detailed(self, market: str, horizon: str, direction: int, min_score: int, limit: int = 10) -> ScanReport:
        return await self.scan_frame_detailed(market, HORIZON_TO_FRAME.get(horizon.upper(), "1d"), direction, min_score, limit)
