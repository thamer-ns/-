from __future__ import annotations

from .focused_bot_v37_helpers import provider_status_text, sources_text
from .focused_bot_v38 import (
    FOCUSED_HELP_TEXT,
    LiveBotService as BaseV38LiveBotService,
)
from .formatting import format_health
from .presets_v37 import V37PresetScanner
from .school_engine_v38_final import FinalSchoolConsensusAnalyzer
from .universes import US_FOCUS_UNIVERSE


class LiveBotService(BaseV38LiveBotService):
    def __init__(self, settings, database, telegram) -> None:
        super().__init__(settings, database, telegram)
        self.live = FinalSchoolConsensusAnalyzer()
        self.scanner = V37PresetScanner(self.live)

    async def _status_text(self) -> str:
        health = format_health(await self.db.health_snapshot())
        return (
            health
            + "\n\n<b>محرك التحليل:</b> V3.8 — توافق المدارس\n"
            + "<b>شرط الفرصة:</b> مدرستان مستقلتان متوافقتان أو "
            + "مدرسة واحدة قوية قابلة للتنفيذ\n"
            + "<b>المدارس:</b> 9 مدارس فنية مستقلة\n"
            + "<b>الفواصل:</b> 1د، 5د، 15د، 30د، ساعة، 4س، "
            + "يومي، أسبوعي، شهري\n"
            + f"<b>القائمة الأمريكية:</b> {len(US_FOCUS_UNIVERSE)} سهمًا\n"
            + provider_status_text()
            + "\n<i>التحليل احتمالي ولا ينفذ أوامر أو يختار عقد أوبشن.</i>"
        )

    async def _handle_text(self, chat_id: int, text: str) -> None:
        command = text.partition(" ")[0].split("@", 1)[0].lower()
        if command == "/sources":
            await self.telegram.send_message(
                chat_id,
                sources_text().replace("V3.7", "V3.8"),
                self._main_menu(),
            )
            return
        await super()._handle_text(chat_id, text)
