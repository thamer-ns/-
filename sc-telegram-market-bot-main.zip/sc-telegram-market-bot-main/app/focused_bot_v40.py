from __future__ import annotations

import html
from typing import Any

from .focused_bot_v37_helpers import sources_text
from .focused_bot_v38_helpers import (
    build_frame_scan_buttons_v38,
    frame_label,
)
from .focused_bot_v39_final import (
    LiveBotService as BaseV39LiveBotService,
    _COMMANDS as V39_COMMANDS,
)
from .formatting import format_health, format_symbol_analysis
from .presentation_v40 import analysis_pages, preset_pages, scan_pages
from .presets import PRESET_BY_ID
from .presets_v39 import FRAME_CODE_TO_KEY
from .technical import MarketDataError
from .universes import US_FOCUS_UNIVERSE

FOCUSED_HELP_TEXT_V40 = """<b>بوصلة الأسواق V4.1 — أهداف ووقف متكيفان مع كل فاصل</b>

أرسل الرمز مباشرة أو استخدم:
<code>/analyze 2222</code> — تحليل جميع الفواصل
<code>/analyze AAPL 15m</code> — تحليل فاصل محدد

<b>كيف تقرأ النتيجة؟</b>
• فرصة مفعّلة: تحقق الدخول والسعر قريب من منطقة التنفيذ.
• بانتظار التفعيل: الاتجاه موجود لكن الدخول لم يتأكد بعد.
• مراقبة فقط: لا يوجد توافق كافٍ أو لا توجد خطة مخاطرة صالحة.

/scan — فرص مكتملة حسب السوق والفاصل
/filters — فلاتر فنية وخطط شراء أو هبوط
/recommendations — أفضل الفرص السعودية
/options — فرص CALL وPUT حسب اتجاه الأصل
/calls — فرص CALL
/puts — فرص PUT
/active — خطط TradingView القائمة
/sources — مصادر البيانات
/status — حالة النظام

<i>كل فرصة تعرض دخولًا ووقفًا وأهدافًا مبنية على بنية السعر وATR وتدرج السوق الخاص بالفاصل. المدة تقدير تاريخي أو نطاق ATR وليست موعدًا مضمونًا. البوت لا ينفذ صفقات ولا يختار عقد الأوبشن.</i>"""

COMMANDS_V40: tuple[tuple[str, str], ...] = tuple(
    (
        command,
        {
            "analyze": "تحليل واضح مع خطة كل فاصل",
            "scan": "فرص مكتملة بالدخول والوقف والأهداف",
            "filters": "فلاتر وخطط واضحة على جميع الفواصل",
            "recommendations": "أفضل الفرص السعودية المكتملة",
            "options": "فرص CALL وPUT حسب الأصل",
            "calls": "فرص CALL مع خطة الأصل",
            "puts": "فرص PUT مع خطة الأصل",
        }.get(command, description),
    )
    for command, description in V39_COMMANDS
)


class LiveBotService(BaseV39LiveBotService):
    """V4.1 Telegram UX with adaptive risk and transparent duration."""

    async def configure_telegram(self) -> None:
        await super().configure_telegram()
        await self.telegram._call(
            "setMyCommands",
            {
                "commands": [
                    {"command": command, "description": description}
                    for command, description in COMMANDS_V40
                ]
            },
        )

    async def _send_pages(
        self,
        chat_id: int,
        pages: tuple[str, ...],
        final_buttons: dict[str, Any] | None = None,
    ) -> None:
        if not pages:
            await self.telegram.send_message(
                chat_id,
                "❌ تعذر تكوين نتيجة قابلة للعرض.",
                final_buttons or self._main_menu(),
            )
            return
        for index, page in enumerate(pages):
            buttons = final_buttons if index == len(pages) - 1 else None
            await self.telegram.send_message(chat_id, page, buttons)

    async def _status_text(self) -> str:
        health = format_health(await self.db.health_snapshot())
        return (
            health
            + "\n\n<b>محرك التحليل:</b> V4.1 — وقف وأهداف متكيفة مع الفاصل\n"
            + "<b>نتيجة الرمز:</b> ملخص تنفيذي ثم تفاصيل كل فاصل\n"
            + "<b>نتيجة المسح:</b> مستويات متدرجة حسب ATR والبنية وتدرج السوق\n"
            + "<b>الفواصل:</b> 1د، 5د، 15د، 30د، ساعة، 4س، يومي، أسبوعي، شهري\n"
            + f"<b>القائمة الأمريكية:</b> {len(US_FOCUS_UNIVERSE)} سهمًا\n"
            + "<i>الأوبشن يعرض اتجاه وخطة الأصل فقط، ولا يختار Strike أو Expiry أو Greeks.</i>"
        )

    async def _send_symbol_analysis(
        self,
        chat_id: int,
        symbol: str,
        frame_key: str | None = None,
    ) -> None:
        clean = symbol.strip().upper()
        if not clean:
            await self.telegram.send_message(
                chat_id,
                "أرسل الرمز مثل <code>2222</code> أو <code>AAPL</code>، والفاصل اختياري مثل <code>15m</code> أو <code>1d</code>.",
            )
            return
        await self.telegram.send_message(
            chat_id,
            f"⏳ تحليل <code>{html.escape(clean)}</code> — {html.escape(frame_label(frame_key))}. سأعرض الخلاصة أولًا ثم خطة كل فاصل بوضوح...",
        )
        try:
            result = (
                await self.live.analyze_one(clean, frame_key)
                if frame_key
                else await self.live.analyze(clean)
            )
        except MarketDataError as exc:
            stored = await self.db.find_symbol(clean, limit=12)
            if stored:
                await self.telegram.send_message(
                    chat_id,
                    "⚠️ تعذر الجلب المباشر، وهذه آخر بيانات TradingView محفوظة:\n\n"
                    + format_symbol_analysis(clean, stored),
                    self._detail_buttons(stored[0]),
                )
                return
            await self.telegram.send_message(
                chat_id,
                "❌ <b>تعذر تحليل الرمز الآن.</b>\n\n"
                + f"السبب: {html.escape(str(exc))}",
                self._main_menu(),
            )
            return
        await self._send_pages(
            chat_id,
            analysis_pages(result),
            self._analysis_buttons(result.display_symbol),
        )

    async def _send_frame_scan(
        self,
        chat_id: int,
        market: str,
        frame_key: str,
        direction: int = 0,
        min_score: int = 60,
    ) -> None:
        await self.telegram.send_message(
            chat_id,
            f"⏳ مسح <b>{html.escape(market)}</b> على فاصل <b>{html.escape(frame_label(frame_key))}</b>. ستظهر فقط الفرص المكتملة، مع الدخول والوقف والأهداف والمدة...",
        )
        try:
            report = await self.live.scan_frame_detailed(
                market, frame_key, direction, min_score, limit=10
            )
        except MarketDataError as exc:
            await self.telegram.send_message(
                chat_id,
                "❌ تعذر تنفيذ المسح: " + html.escape(str(exc)),
                self._main_menu(),
            )
            return
        await self._send_pages(
            chat_id,
            scan_pages(report),
            build_frame_scan_buttons_v38(
                list(report.items),
                market,
                frame_key,
                direction,
                min_score,
            ),
        )

    async def _send_preset(
        self,
        chat_id: int,
        market: str,
        preset_id: str,
        frame_code: str,
    ) -> None:
        preset = PRESET_BY_ID.get(preset_id)
        if preset is None:
            await self.telegram.send_message(
                chat_id, "❌ الفلتر غير معروف.", self._main_menu()
            )
            return
        if frame_code.upper() not in FRAME_CODE_TO_KEY:
            await self.telegram.send_message(
                chat_id, "❌ فاصل الفلتر غير صالح.", self._main_menu()
            )
            return
        await self.telegram.send_message(
            chat_id,
            f"⏳ تطبيق فلتر <b>{html.escape(preset.title)}</b>. ستظهر الخطة كاملة لأي نتيجة قابلة للتنفيذ...",
        )
        try:
            report = await self.scanner.scan_preset(
                market, preset_id, frame_code, limit=10
            )
        except MarketDataError as exc:
            await self.telegram.send_message(
                chat_id,
                "❌ تعذر تنفيذ الفلتر الآن: " + html.escape(str(exc)),
                self._filter_categories_menu(market),
            )
            return
        await self._send_pages(
            chat_id,
            preset_pages(report, frame_code),
            self._preset_result_buttons(report, frame_code),
        )

    async def _handle_text(self, chat_id: int, text: str) -> None:
        command = text.partition(" ")[0].split("@", 1)[0].lower()
        if command in {"/start", "/help"}:
            await self.telegram.send_message(
                chat_id, FOCUSED_HELP_TEXT_V40, self._main_menu()
            )
            return
        if command == "/sources":
            await self.telegram.send_message(
                chat_id,
                sources_text().replace("V3.7", "V4.1").replace("V3.9", "V4.1").replace("V4.0", "V4.1"),
                self._main_menu(),
            )
            return
        await super()._handle_text(chat_id, text)

    async def _handle_callback(self, callback: dict[str, Any]) -> None:
        callback_id = str(callback["id"])
        message = callback.get("message") or {}
        chat_id = int(message.get("chat", {}).get("id", 0))
        user_id = int(callback.get("from", {}).get("id", 0))
        data = str(callback.get("data", ""))
        if data in {"menu:home", "menu:help"}:
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(callback_id, "غير مصرح")
                return
            await self.telegram.answer_callback(callback_id, "القائمة الرئيسية")
            await self.telegram.send_message(
                chat_id, FOCUSED_HELP_TEXT_V40, self._main_menu()
            )
            return
        await super()._handle_callback(callback)


FOCUSED_HELP_TEXT = FOCUSED_HELP_TEXT_V40
__all__ = [
    "COMMANDS_V40",
    "FOCUSED_HELP_TEXT",
    "FOCUSED_HELP_TEXT_V40",
    "LiveBotService",
]
