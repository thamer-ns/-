from __future__ import annotations

import math
from dataclasses import replace
from typing import Any

from .market_data import FRAMES
from .opportunity_v37 import OpportunityMarketAnalyzer
from .technical import Candle, LiveAnalysis, MarketDataError


def valid_candle(candle: Candle) -> bool:
    prices = (candle.open, candle.high, candle.low, candle.close)
    if candle.timestamp <= 0:
        return False
    if not all(math.isfinite(value) and value > 0 for value in prices):
        return False
    if not math.isfinite(candle.volume) or candle.volume < 0:
        return False
    tolerance = max(candle.high, 1.0) * 1e-10
    if candle.high + tolerance < max(
        candle.open, candle.close, candle.low
    ):
        return False
    if candle.low - tolerance > min(
        candle.open, candle.close, candle.high
    ):
        return False
    return True


def sanitize_candles(candles: list[Candle]) -> list[Candle]:
    """Sorts, validates and deduplicates bars by timestamp."""

    by_timestamp: dict[int, Candle] = {}
    for candle in candles:
        if valid_candle(candle):
            by_timestamp[candle.timestamp] = candle
    return [by_timestamp[key] for key in sorted(by_timestamp)]


def clarify_tracking_state(item: LiveAnalysis) -> LiveAnalysis:
    """Marks progressed plans as tracking-only rather than fresh entries."""

    frames = []
    for frame in item.frames:
        state = frame.plan_state
        if state.startswith("فرصة قائمة — تحقق الهدف"):
            state = state.replace(
                "فرصة قائمة —",
                "فرصة قائمة للمتابعة —",
                1,
            )
        frames.append(replace(frame, plan_state=state))
    return replace(item, frames=tuple(frames))


class SafeOpportunityMarketAnalyzer(OpportunityMarketAnalyzer):
    """Applies OHLC integrity and user-facing tracking safeguards."""

    async def _fetch(
        self, symbol: str, frame_key: str
    ) -> tuple[list[Any], dict[str, Any], str]:
        candles, metadata, provider_id = await super()._fetch(
            symbol, frame_key
        )
        cleaned = sanitize_candles(candles)
        minimum = 35 if frame_key == "1d" else 60
        if len(cleaned) < minimum:
            label = FRAMES.get(frame_key, ("", "", frame_key, 0))[2]
            raise MarketDataError(
                f"الشموع الصالحة غير كافية لفاصل {label} "
                "بعد تدقيق OHLC"
            )
        return cleaned, metadata, provider_id

    async def analyze(self, symbol: str) -> LiveAnalysis:
        return clarify_tracking_state(await super().analyze(symbol))

    async def analyze_one(
        self, symbol: str, frame_key: str
    ) -> LiveAnalysis:
        return clarify_tracking_state(
            await super().analyze_one(symbol, frame_key)
        )
