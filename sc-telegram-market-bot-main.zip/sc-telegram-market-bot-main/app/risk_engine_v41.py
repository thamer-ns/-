from __future__ import annotations

import math
from dataclasses import dataclass

from .technical import Candle, _atr, _cluster, _pivot_levels


@dataclass(frozen=True, slots=True)
class TimeframeRiskProfile:
    key: str
    label: str
    min_stop_atr: float
    max_stop_atr: float
    stop_cushion_atr: float
    target_r: tuple[float, float, float]
    min_target_atr: tuple[float, float, float]
    max_risk_percent: float
    duration_horizon: int
    history_anchors: int


@dataclass(frozen=True, slots=True)
class AdaptivePlan:
    valid: bool
    entry: float | None = None
    stop: float | None = None
    targets: tuple[float, ...] = ()
    first_rr: float | None = None
    warnings: tuple[str, ...] = ()
    risk_atr: float | None = None
    target_atr: tuple[float, ...] = ()
    duration_low_bars: int | None = None
    duration_high_bars: int | None = None
    duration_samples: int = 0
    duration_success_rate: float | None = None
    duration_method: str = ""
    profile: str = ""
    rejection_reason: str = ""


# Each profile is calibrated in units of the timeframe's own ATR.  A daily
# plan therefore cannot inherit the tiny price geometry of a minute plan.
PROFILES: dict[str, TimeframeRiskProfile] = {
    "1 دقيقة": TimeframeRiskProfile("1m", "1 دقيقة", 0.45, 1.80, 0.18, (1.00, 1.65, 2.30), (0.80, 1.40, 2.00), 1.20, 90, 180),
    "5 دقائق": TimeframeRiskProfile("5m", "5 دقائق", 0.50, 2.00, 0.20, (1.00, 1.70, 2.40), (0.90, 1.55, 2.25), 1.60, 80, 180),
    "15 دقيقة": TimeframeRiskProfile("15m", "15 دقيقة", 0.55, 2.20, 0.22, (1.00, 1.80, 2.60), (1.00, 1.75, 2.55), 2.10, 70, 200),
    "30 دقيقة": TimeframeRiskProfile("30m", "30 دقيقة", 0.60, 2.40, 0.24, (1.05, 1.90, 2.75), (1.05, 1.90, 2.80), 2.60, 60, 200),
    "ساعة": TimeframeRiskProfile("1h", "ساعة", 0.65, 2.70, 0.26, (1.10, 2.00, 2.95), (1.10, 2.00, 3.00), 3.20, 55, 220),
    "4 ساعات": TimeframeRiskProfile("4h", "4 ساعات", 0.75, 3.10, 0.28, (1.15, 2.10, 3.15), (1.20, 2.20, 3.30), 5.00, 42, 240),
    "يومي": TimeframeRiskProfile("1d", "يومي", 0.85, 3.50, 0.30, (1.20, 2.20, 3.35), (1.30, 2.40, 3.60), 8.00, 35, 280),
    "أسبوعي": TimeframeRiskProfile("1w", "أسبوعي", 1.00, 4.00, 0.35, (1.30, 2.45, 3.75), (1.50, 2.80, 4.20), 15.00, 24, 240),
    "شهري": TimeframeRiskProfile("1mo", "شهري", 1.10, 4.50, 0.40, (1.45, 2.70, 4.10), (1.80, 3.20, 4.80), 25.00, 15, 160),
}
_DEFAULT_PROFILE = PROFILES["ساعة"]


def profile_for(frame_name: str) -> TimeframeRiskProfile:
    return PROFILES.get(frame_name, _DEFAULT_PROFILE)


def saudi_tick_size(price: float) -> float:
    if price < 25.00:
        return 0.01
    if price < 50.00:
        return 0.02
    if price < 100.00:
        return 0.05
    if price < 250.00:
        return 0.10
    if price < 500.00:
        return 0.20
    return 0.50


def tick_size(market: str, price: float) -> float:
    market = market.upper()
    if market == "SAUDI":
        return saudi_tick_size(price)
    # US equities currently trade on the one-cent grid for the symbols in the
    # focused universe.  Keep this isolated so a future rule change is local.
    if market in {"US", "US_OPTIONS"}:
        return 0.01
    if market == "FOREX":
        return 0.001 if price >= 20 else 0.0001
    if market == "CRYPTO":
        if price >= 1000:
            return 0.10
        if price >= 100:
            return 0.01
        if price >= 1:
            return 0.001
        return 0.00001
    magnitude = max(abs(price), 1e-12)
    decimals = max(2, min(8, 4 - math.floor(math.log10(magnitude))))
    return 10.0 ** (-decimals)


def round_to_tick(value: float, tick: float, mode: str = "nearest") -> float:
    if tick <= 0 or not math.isfinite(value):
        return value
    ratio = value / tick
    if mode == "up":
        units = math.ceil(ratio - 1e-10)
    elif mode == "down":
        units = math.floor(ratio + 1e-10)
    else:
        units = round(ratio)
    rounded = units * tick
    decimals = (
        max(0, min(10, int(math.ceil(-math.log10(tick))) + 1))
        if tick < 1
        else 2
    )
    return round(rounded, decimals)


def round_market_price(market: str, value: float, mode: str = "nearest") -> float:
    """Round using the tick band that applies to the resulting price level.

    Saudi tick sizes change at price-band boundaries, so stops and targets
    must not inherit the entry price's tick when they lie in another band.
    """

    rounded = value
    for _ in range(3):
        tick = tick_size(market, rounded)
        updated = round_to_tick(value, tick, mode)
        if updated == rounded:
            break
        rounded = updated
    return rounded


def _true_ranges(candles: list[Candle]) -> list[float]:
    return [
        max(
            current.high - current.low,
            abs(current.high - previous.close),
            abs(current.low - previous.close),
        )
        for previous, current in zip(candles, candles[1:])
    ]


def _quantile(values: list[float], fraction: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    position = (len(ordered) - 1) * min(1.0, max(0.0, fraction))
    lower = int(math.floor(position))
    upper = int(math.ceil(position))
    if lower == upper:
        return ordered[lower]
    weight = position - lower
    return ordered[lower] * (1.0 - weight) + ordered[upper] * weight


def _structural_levels(
    candles: list[Candle], atr: float, entry: float, event_level: float
) -> tuple[list[float], list[float], list[float]]:
    """Return all levels plus support-like and resistance-like anchors.

    Stops use pivot lows for long plans and pivot highs for short plans.  This
    avoids treating an old pivot high below price as if it were a long stop
    anchor merely because it is numerically below the entry.
    """

    historical = candles[:-1]
    sample = historical[-180:]
    lows, highs = _pivot_levels(sample, 2, 2)
    tolerance = max(0.28 * atr, entry * 0.0015)
    low_clusters = [
        level
        for level, touches in _cluster(lows, tolerance)
        if touches >= 2
    ]
    high_clusters = [
        level
        for level, touches in _cluster(highs, tolerance)
        if touches >= 2
    ]
    recent = historical[-24:]
    supports = [*low_clusters]
    resistances = [*high_clusters]
    target_levels = [*low_clusters, *high_clusters]
    if recent:
        supports.extend(bar.low for bar in recent[-12:])
        resistances.extend(bar.high for bar in recent[-12:])
        # Only the outer bounds of the recent range are treated as target
        # obstacles.  Every individual wick would make valid plans appear
        # blocked by ordinary noise.
        target_levels.extend(
            (min(bar.low for bar in recent), max(bar.high for bar in recent))
        )
    if event_level > 0 and math.isfinite(event_level):
        target_levels.append(event_level)
        if event_level < entry:
            supports.append(event_level)
        elif event_level > entry:
            resistances.append(event_level)
    support_values = sorted(
        {value for value in supports if value > 0 and math.isfinite(value)}
    )
    resistance_values = sorted(
        {value for value in resistances if value > 0 and math.isfinite(value)}
    )
    confirmed_targets = sorted(
        {value for value in target_levels if value > 0 and math.isfinite(value)}
    )
    return confirmed_targets, support_values, resistance_values


def _duration_window(
    candles: list[Candle],
    *,
    direction: int,
    reference: float,
    stop: float,
    target: float,
    current_atr: float,
    profile: TimeframeRiskProfile,
) -> tuple[int, int, int, float | None, str]:
    """Estimate bars to target by double-barrier historical first passage.

    Comparable anchors must have the same short-term direction and a similar
    ATR percentage, so quiet and highly volatile regimes are not mixed. A
    wider volatility band is used only when the strict sample is insufficient.
    A candle touching target and stop is evaluated but not counted as a
    successful hit because OHLC data cannot reveal the intrabar order.
    """

    target_atr = abs(target - reference) / max(current_atr, 1e-12)
    stop_atr = abs(reference - stop) / max(current_atr, 1e-12)
    current_atr_percent = current_atr / max(abs(reference), 1e-12)
    horizon = profile.duration_horizon
    last_anchor = len(candles) - horizon - 1
    first_anchor = max(20, last_anchor - profile.history_anchors)

    def collect(
        minimum_volatility_ratio: float,
        maximum_volatility_ratio: float,
    ) -> tuple[list[int], int]:
        successful: list[int] = []
        evaluated = 0
        if last_anchor < first_anchor:
            return successful, evaluated

        for index in range(first_anchor, last_anchor + 1):
            local = candles[max(0, index - 45) : index + 1]
            local_atr = _atr(local)
            anchor = candles[index].close
            if (
                local_atr <= 0
                or not math.isfinite(local_atr)
                or anchor <= 0
                or not math.isfinite(anchor)
            ):
                continue

            local_atr_percent = local_atr / anchor
            volatility_ratio = local_atr_percent / max(
                current_atr_percent, 1e-12
            )
            if not (
                minimum_volatility_ratio
                <= volatility_ratio
                <= maximum_volatility_ratio
            ):
                continue

            lookback_index = max(0, index - 5)
            drift = candles[index].close - candles[lookback_index].close
            drift_atr = direction * drift / local_atr
            if drift_atr <= 0.05 or drift_atr > 5.0:
                continue

            evaluated += 1
            local_target = anchor + direction * target_atr * local_atr
            local_stop = anchor - direction * stop_atr * local_atr
            for bars, bar in enumerate(
                candles[index + 1 : index + 1 + horizon], 1
            ):
                target_hit = (
                    bar.high >= local_target
                    if direction > 0
                    else bar.low <= local_target
                )
                stop_hit = (
                    bar.low <= local_stop
                    if direction > 0
                    else bar.high >= local_stop
                )
                if target_hit and stop_hit:
                    break
                if stop_hit:
                    break
                if target_hit:
                    successful.append(bars)
                    break
        return successful, evaluated

    strict_successful, strict_evaluated = collect(0.60, 1.67)
    strict_rate = (
        len(strict_successful) / strict_evaluated
        if strict_evaluated
        else None
    )
    if len(strict_successful) >= 8:
        low = max(1, round(_quantile(strict_successful, 0.25)))
        high = max(low, round(_quantile(strict_successful, 0.75)))
        return (
            low,
            high,
            strict_evaluated,
            strict_rate,
            "historical-first-passage",
        )

    relaxed_successful, relaxed_evaluated = collect(0.40, 2.50)
    relaxed_rate = (
        len(relaxed_successful) / relaxed_evaluated
        if relaxed_evaluated
        else None
    )
    if len(relaxed_successful) >= 8:
        low = max(1, round(_quantile(relaxed_successful, 0.25)))
        high = max(low, round(_quantile(relaxed_successful, 0.75)))
        return (
            low,
            high,
            relaxed_evaluated,
            relaxed_rate,
            "historical-first-passage-relaxed",
        )

    distance = abs(target - reference)
    low = max(
        1,
        math.ceil(distance / max(0.85 * current_atr, 1e-12)),
    )
    high = max(
        low,
        math.ceil(distance / max(0.35 * current_atr, 1e-12)),
    )
    low = min(low, horizon)
    high = min(max(high, low), horizon)
    evaluated = max(strict_evaluated, relaxed_evaluated)
    rate = relaxed_rate if relaxed_evaluated >= strict_evaluated else strict_rate
    return low, high, evaluated, rate, "atr-range-fallback"


def estimate_remaining_duration(
    candles: list[Candle],
    *,
    frame_name: str,
    direction: int,
    reference: float,
    stop: float,
    target: float,
    atr: float,
) -> tuple[int, int, int, float | None, str]:
    return _duration_window(
        candles,
        direction=direction,
        reference=reference,
        stop=stop,
        target=target,
        current_atr=atr,
        profile=profile_for(frame_name),
    )


def build_adaptive_plan(
    *,
    candles: list[Candle],
    frame_name: str,
    direction: int,
    event_level: float,
    market: str = "",
    entry_override: float | None = None,
) -> AdaptivePlan:
    profile = profile_for(frame_name)
    if direction not in (-1, 1) or len(candles) < 20:
        return AdaptivePlan(
            False,
            profile=profile.key,
            rejection_reason="الاتجاه أو السجل غير كافٍ",
        )
    price = candles[-1].close
    atr = _atr(candles)
    if atr <= 0 or not math.isfinite(atr):
        return AdaptivePlan(
            False, profile=profile.key, rejection_reason="ATR غير صالح"
        )
    reference_tick = tick_size(market, price)
    entry_buffer = max(0.06 * atr, 2.0 * reference_tick)
    raw_entry = (
        entry_override
        if entry_override is not None
        else event_level + direction * entry_buffer
    )
    entry_mode = "up" if direction > 0 else "down"
    entry = round_market_price(market, raw_entry, entry_mode)
    tick = tick_size(market, entry)
    if entry <= 0:
        return AdaptivePlan(
            False, profile=profile.key, rejection_reason="الدخول غير صالح"
        )

    all_levels, supports, resistances = _structural_levels(
        candles, atr, entry, event_level
    )
    stop_candidates = (
        [level for level in supports if level < entry - tick]
        if direction > 0
        else [level for level in resistances if level > entry + tick]
    )
    structural = (
        max(stop_candidates)
        if direction > 0 and stop_candidates
        else min(stop_candidates)
        if direction < 0 and stop_candidates
        else entry - direction * atr
    )
    cushion = max(profile.stop_cushion_atr * atr, 2.0 * tick)
    raw_stop = structural - direction * cushion
    raw_risk = direction * (entry - raw_stop)

    ranges = _true_ranges(candles[-80:])
    range_floor = _quantile(ranges, 0.35)
    tick_floor = 3.0 * tick
    minimum_risk = max(
        profile.min_stop_atr * atr, 0.70 * range_floor, tick_floor
    )
    # A coarse exchange tick can be slightly wider than the profile's ATR
    # ceiling.  Permit the minimum executable tick distance, but never bypass
    # the explicit percentage risk cap.
    profile_ceiling = max(profile.max_stop_atr * atr, tick_floor)
    percentage_ceiling = entry * profile.max_risk_percent / 100.0
    maximum_risk = min(profile_ceiling, percentage_ceiling)
    warnings: list[str] = []
    if maximum_risk + tick < minimum_risk:
        return AdaptivePlan(
            False,
            warnings=(
                "التذبذب يتطلب وقفًا أوسع من حد المخاطرة المسموح لهذا الفاصل",
            ),
            profile=profile.key,
            rejection_reason="لا يمكن بناء وقف متناسب مع التذبذب وحد المخاطرة",
        )
    if raw_risk < minimum_risk:
        raw_risk = minimum_risk
        raw_stop = entry - direction * raw_risk
        warnings.append("وُسّع الوقف ليتجاوز ضوضاء الفاصل المعتادة")
    if raw_risk <= 0 or raw_risk > maximum_risk:
        return AdaptivePlan(
            False,
            warnings=("الوقف البنيوي أبعد من الحد الملائم لهذا الفاصل",),
            profile=profile.key,
            rejection_reason="الوقف البنيوي غير متناسب مع الفاصل",
        )
    stop_mode = "down" if direction > 0 else "up"
    stop = round_market_price(market, raw_stop, stop_mode)
    stop_tick = tick_size(market, stop)
    risk = direction * (entry - stop)
    if risk <= 0:
        return AdaptivePlan(
            False,
            profile=profile.key,
            rejection_reason="الوقف في الجهة الخاطئة",
        )
    if risk > maximum_risk + max(tick, stop_tick):
        return AdaptivePlan(
            False,
            profile=profile.key,
            rejection_reason="الوقف بعد التقريب تجاوز مخاطرة الفاصل",
        )

    forward = (
        sorted(level for level in all_levels if level > entry + tick)
        if direction > 0
        else sorted(
            (level for level in all_levels if level < entry - tick),
            reverse=True,
        )
    )
    first_required = max(
        profile.target_r[0] * risk,
        profile.min_target_atr[0] * atr,
    )
    if forward and abs(forward[0] - entry) < 0.72 * first_required:
        warnings.append(
            "يوجد عائق سعري قريب قبل الهدف الأول؛ يلزم مراقبة تجاوزه"
        )

    targets: list[float] = []
    previous = entry
    for r_multiple, atr_multiple in zip(
        profile.target_r, profile.min_target_atr
    ):
        required_distance = max(r_multiple * risk, atr_multiple * atr)
        nominal = entry + direction * required_distance
        candidates = [
            level
            for level in forward
            if direction * (level - previous) > 0
            and required_distance
            <= abs(level - entry)
            <= 1.25 * required_distance
        ]
        if candidates:
            level = min(
                candidates,
                key=lambda value: abs(
                    abs(value - entry) - required_distance
                ),
            )
            raw_target = level - direction * tick
            # Never let conservative tick placement pull the target under the
            # timeframe minimum.
            if abs(raw_target - entry) < required_distance:
                raw_target = nominal
        else:
            raw_target = nominal
        target_mode = "down" if direction > 0 else "up"
        target = round_market_price(market, raw_target, target_mode)
        if abs(target - entry) + 1e-12 < required_distance:
            target = round_market_price(
                market, nominal, "up" if direction > 0 else "down"
            )
        target_tick = tick_size(market, target)
        previous_tick = tick_size(market, previous)
        min_spacing = max(0.30 * atr, 2.0 * max(target_tick, previous_tick))
        if direction * (target - previous) < min_spacing:
            target = round_market_price(
                market, previous + direction * min_spacing, entry_mode
            )
        targets.append(target)
        previous = target

    if len(targets) != 3:
        return AdaptivePlan(
            False, profile=profile.key, rejection_reason="عدد الأهداف غير صالح"
        )
    if not all(direction * (target - entry) > 0 for target in targets):
        return AdaptivePlan(
            False,
            profile=profile.key,
            rejection_reason="الأهداف في الجهة الخاطئة",
        )
    if any(
        direction * (right - left) <= 0
        for left, right in zip(targets, targets[1:])
    ):
        return AdaptivePlan(
            False,
            profile=profile.key,
            rejection_reason="الأهداف غير مرتبة",
        )

    first_rr = abs(targets[0] - entry) / risk
    if first_rr + 1e-9 < profile.target_r[0]:
        return AdaptivePlan(
            False,
            profile=profile.key,
            rejection_reason="عائد الهدف الأول أقل من معيار الفاصل",
        )
    (
        duration_low,
        duration_high,
        duration_samples,
        duration_success_rate,
        duration_method,
    ) = _duration_window(
        candles,
        direction=direction,
        reference=entry,
        stop=stop,
        target=targets[0],
        current_atr=atr,
        profile=profile,
    )
    return AdaptivePlan(
        True,
        entry=entry,
        stop=stop,
        targets=tuple(targets),
        first_rr=first_rr,
        warnings=tuple(warnings),
        risk_atr=risk / atr,
        target_atr=tuple(abs(target - entry) / atr for target in targets),
        duration_low_bars=duration_low,
        duration_high_bars=duration_high,
        duration_samples=duration_samples,
        duration_success_rate=duration_success_rate,
        duration_method=duration_method,
        profile=profile.key,
    )


__all__ = [
    "AdaptivePlan",
    "PROFILES",
    "TimeframeRiskProfile",
    "build_adaptive_plan",
    "estimate_remaining_duration",
    "profile_for",
    "round_market_price",
    "round_to_tick",
    "saudi_tick_size",
    "tick_size",
]
