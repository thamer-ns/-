from __future__ import annotations

import asyncio
import time

from .audited_engine import _reference_levels, _setup_event_audited
from .presets import (
    PRESET_BY_ID,
    PresetMatch,
    PresetReport,
    SignalSnapshot,
    match_preset,
    normalize_analysis,
)
from .presets_v37 import V37PresetScanner, build_signal_snapshot_v37
from .school_engine_v38 import FRAME_SPECS
from .technical import Candle, FrameAnalysis, LiveAnalysis, MarketDataError
from .universes import UNIVERSE_LABELS


FRAME_CODE_TO_KEY: dict[str, str] = {
    "1": "1m",
    "5": "5m",
    "15": "15m",
    "30": "30m",
    "H": "1h",
    "4H": "4h",
    "D": "1d",
    "W": "1w",
    "MO": "1mo",
}
FRAME_KEY_TO_CODE = {value: key for key, value in FRAME_CODE_TO_KEY.items()}


def frame_code_label(frame_code: str) -> str:
    key = FRAME_CODE_TO_KEY.get(frame_code.upper())
    return FRAME_SPECS[key].label if key else "فاصل غير معروف"


def build_signal_snapshot_v39(
    candles: list[Candle], frame: FrameAnalysis
) -> SignalSnapshot:
    """Builds preset tags with fixed pre-trigger breakout levels."""
    snapshot = build_signal_snapshot_v37(candles, frame)
    level_tags = {
        "break_up",
        "break_down",
        "retest_up",
        "retest_down",
    }
    tags = set(snapshot.tags).difference(level_tags)
    reasons = {
        tag: reason
        for tag, reason in snapshot.reasons
        if tag not in level_tags
    }

    if len(candles) >= 10:
        price = candles[-1].close
        atr = max(frame.atr, price * 0.0001)
        support, resistance, _ = _reference_levels(
            candles, price, atr
        )
        event_direction, event_text, _ = _setup_event_audited(
            candles, support, resistance, atr
        )
        if event_direction > 0:
            tag = "retest_up" if "إعادة اختبار" in event_text else "break_up"
            tags.add(tag)
            reasons[tag] = event_text
        elif event_direction < 0:
            tag = "retest_down" if "إعادة اختبار" in event_text else "break_down"
            tags.add(tag)
            reasons[tag] = event_text

    return SignalSnapshot(
        tags=frozenset(tags),
        reasons=tuple(reasons.items()),
        volume_ratio=snapshot.volume_ratio,
        rank_bonus=snapshot.rank_bonus,
    )


class V39PresetScanner(V37PresetScanner):
    """Preset scanner for every V3.9 frame with audited level events."""

    @staticmethod
    def _frame_key(frame_code: str) -> str:
        key = FRAME_CODE_TO_KEY.get(frame_code.upper())
        if key is None:
            raise MarketDataError("فاصل الفلتر غير مدعوم")
        return key

    async def scan_preset(
        self,
        market: str,
        preset_id: str,
        frame_code: str = "D",
        limit: int = 10,
    ) -> PresetReport:
        preset = PRESET_BY_ID.get(preset_id)
        if preset is None:
            raise MarketDataError("الفلتر الفني غير معروف")
        normalized = market.upper()
        frame_key = self._frame_key(frame_code)
        cache_key = (normalized, preset_id, frame_key)
        now = time.monotonic()
        cached = self._cache.get(cache_key)
        if cached and now - cached[0] <= self.analyzer.scan_cache_seconds:
            return cached[1]
        lock = self._locks.setdefault(cache_key, asyncio.Lock())
        async with lock:
            cached = self._cache.get(cache_key)
            now = time.monotonic()
            if cached and now - cached[0] <= self.analyzer.scan_cache_seconds:
                return cached[1]
            raw_items, total, analyzed = await self.analyzer._scan_all(
                normalized, frame_key
            )
            semaphore = asyncio.Semaphore(self.analyzer.scan_concurrency)

            async def worker(
                raw_item: LiveAnalysis,
            ) -> PresetMatch | None:
                async with semaphore:
                    try:
                        item = normalize_analysis(raw_item)
                        candles, _, _ = await self.analyzer._fetch(
                            item.display_symbol, frame_key
                        )
                        snapshot = build_signal_snapshot_v39(
                            candles, item.frames[0]
                        )
                        matched, reasons, rank = match_preset(
                            preset, item, snapshot
                        )
                        return (
                            PresetMatch(item, reasons, rank)
                            if matched
                            else None
                        )
                    except (
                        MarketDataError,
                        ValueError,
                        IndexError,
                        ArithmeticError,
                    ):
                        return None

            raw_matches = await asyncio.gather(
                *(worker(item) for item in raw_items)
            )
            matches = [
                item for item in raw_matches if item is not None
            ]
            matches.sort(key=lambda item: item.rank, reverse=True)
            report = PresetReport(
                market=normalized,
                frame_key=frame_key,
                universe_label=UNIVERSE_LABELS.get(
                    normalized, normalized
                ),
                total_symbols=total,
                analyzed_symbols=analyzed,
                failed_symbols=max(0, total - analyzed),
                preset=preset,
                items=tuple(matches[:limit]),
            )
            self._cache[cache_key] = (time.monotonic(), report)
            return report
