from __future__ import annotations

import asyncio
import time

from .presets import (
    PRESET_BY_ID,
    AdvancedPresetScanner,
    PresetMatch,
    PresetReport,
    SignalSnapshot,
    build_signal_snapshot,
    match_preset,
    normalize_analysis,
)
from .technical import LiveAnalysis, MarketDataError
from .universes import UNIVERSE_LABELS


def build_signal_snapshot_v37(candles, frame) -> SignalSnapshot:
    snapshot = build_signal_snapshot(candles, frame)
    conditional = "فرصة مشروطة" in frame.plan_state
    if not conditional or "confirmed_plan" not in snapshot.tags:
        return snapshot
    tags = frozenset(tag for tag in snapshot.tags if tag != "confirmed_plan")
    reasons = tuple(
        (tag, reason)
        for tag, reason in snapshot.reasons
        if tag != "confirmed_plan"
    )
    return SignalSnapshot(
        tags=tags,
        reasons=reasons,
        volume_ratio=snapshot.volume_ratio,
        rank_bonus=max(0, snapshot.rank_bonus - 10),
    )


class V37PresetScanner(AdvancedPresetScanner):
    """Keeps conditional numeric plans out of confirmed-plan presets."""

    async def scan_preset(
        self,
        market: str,
        preset_id: str,
        frame_code: str = "D",
        limit: int = 10,
    ) -> PresetReport:
        preset = PRESET_BY_ID.get(preset_id)
        if preset is None:
            raise MarketDataError("الفلتر الفني غير معروف")
        normalized = market.upper()
        frame_key = self._frame_key(frame_code)
        cache_key = (normalized, preset_id, frame_key)
        now = time.monotonic()
        cached = self._cache.get(cache_key)
        if cached and now - cached[0] <= self.analyzer.scan_cache_seconds:
            return cached[1]
        lock = self._locks.setdefault(cache_key, asyncio.Lock())
        async with lock:
            cached = self._cache.get(cache_key)
            now = time.monotonic()
            if cached and now - cached[0] <= self.analyzer.scan_cache_seconds:
                return cached[1]
            raw_items, total, analyzed = await self.analyzer._scan_all(
                normalized, frame_key
            )
            semaphore = asyncio.Semaphore(self.analyzer.scan_concurrency)

            async def worker(
                raw_item: LiveAnalysis,
            ) -> PresetMatch | None:
                async with semaphore:
                    try:
                        item = normalize_analysis(raw_item)
                        candles, _, _ = await self.analyzer._fetch(
                            item.display_symbol, frame_key
                        )
                        snapshot = build_signal_snapshot_v37(
                            candles, item.frames[0]
                        )
                        matched, reasons, rank = match_preset(
                            preset, item, snapshot
                        )
                        return (
                            PresetMatch(item, reasons, rank)
                            if matched
                            else None
                        )
                    except (
                        MarketDataError,
                        ValueError,
                        IndexError,
                        ArithmeticError,
                    ):
                        return None

            raw_matches = await asyncio.gather(
                *(worker(item) for item in raw_items)
            )
            matches = [
                item for item in raw_matches if item is not None
            ]
            matches.sort(key=lambda item: item.rank, reverse=True)
            report = PresetReport(
                market=normalized,
                frame_key=frame_key,
                universe_label=UNIVERSE_LABELS.get(
                    normalized, normalized
                ),
                total_symbols=total,
                analyzed_symbols=analyzed,
                failed_symbols=max(0, total - analyzed),
                preset=preset,
                items=tuple(matches[:limit]),
            )
            self._cache[cache_key] = (time.monotonic(), report)
            return report
