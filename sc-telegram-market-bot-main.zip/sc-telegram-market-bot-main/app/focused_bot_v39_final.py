from __future__ import annotations

from typing import Any

from .analyzer_v39 import ProductionVerifiedAnalyzer
from .focused_bot_v37_helpers import sources_text
from .focused_bot_v39 import (
    FOCUSED_HELP_TEXT,
    LiveBotService as BaseV39LiveBotService,
)
from .presets_v39 import FRAME_CODE_TO_KEY, V39PresetScanner


_COMMANDS: tuple[tuple[str, str], ...] = (
    ("start", "فتح القائمة الرئيسية"),
    ("analyze", "تحليل رمز من دقيقة إلى شهر"),
    ("scan", "اختيار السوق والفاصل والاتجاه"),
    ("filters", "الفلاتر الفنية على جميع الفواصل"),
    ("recommendations", "أفضل الفرص السعودية المدققة"),
    ("options", "اتجاهات CALL وPUT حسب الأصل"),
    ("calls", "أفضل فرص CALL الأمريكية"),
    ("puts", "أفضل فرص PUT الأمريكية"),
    ("saudi", "مسح السوق السعودي"),
    ("us", "مسح القائمة الأمريكية المركزة"),
    ("forex", "مسح العملات"),
    ("crypto", "مسح العملات الرقمية"),
    ("active", "خطط TradingView القائمة"),
    ("uslist", "عرض الأسهم الأمريكية الـ51"),
    ("sources", "مصادر البيانات والتحقق"),
    ("status", "حالة الخادم والمحرك"),
    ("help", "شرح الاستخدام"),
)


class LiveBotService(BaseV39LiveBotService):
    """Final V3.9 production routing and command catalogue."""

    def __init__(self, settings, database, telegram) -> None:
        super().__init__(settings, database, telegram)
        self.live = ProductionVerifiedAnalyzer()
        self.scanner = V39PresetScanner(self.live)

    async def configure_telegram(self) -> None:
        await super().configure_telegram()
        await self.telegram._call(
            "setMyCommands",
            {
                "commands": [
                    {
                        "command": command,
                        "description": description,
                    }
                    for command, description in _COMMANDS
                ]
            },
        )

    async def _send_preset(
        self,
        chat_id: int,
        market: str,
        preset_id: str,
        frame_code: str,
    ) -> None:
        if frame_code.upper() not in FRAME_CODE_TO_KEY:
            await self.telegram.send_message(
                chat_id,
                "❌ فاصل الفلتر غير صالح.",
                self._main_menu(),
            )
            return
        await super()._send_preset(
            chat_id, market, preset_id, frame_code
        )

    async def _handle_callback(
        self, callback: dict[str, Any]
    ) -> None:
        callback_id = str(callback["id"])
        message = callback.get("message") or {}
        chat_id = int(message.get("chat", {}).get("id", 0))
        user_id = int(callback.get("from", {}).get("id", 0))
        data = str(callback.get("data", ""))

        if data == "menu:sources":
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(
                    callback_id, "غير مصرح"
                )
                return
            await self.telegram.answer_callback(
                callback_id, "مصادر البيانات"
            )
            await self.telegram.send_message(
                chat_id,
                sources_text().replace("V3.7", "V3.9"),
                self._main_menu(),
            )
            return

        if data.startswith("fp:"):
            parts = data.split(":")
            if (
                len(parts) != 4
                or parts[3].upper() not in FRAME_CODE_TO_KEY
            ):
                if await self._is_authorized(user_id, chat_id):
                    await self.telegram.answer_callback(
                        callback_id, "فاصل فلتر غير صالح"
                    )
                else:
                    await self.telegram.answer_callback(
                        callback_id, "غير مصرح"
                    )
                return

        await super()._handle_callback(callback)


__all__ = ["FOCUSED_HELP_TEXT", "LiveBotService", "_COMMANDS"]
