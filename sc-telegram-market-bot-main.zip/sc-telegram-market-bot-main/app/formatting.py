from __future__ import annotations

import html
from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from .market import age_hours, horizon_ar, is_fresh, market_ar, timeframe_horizon
from .models import AlertEvent, Opportunity, TradingViewAlert

RIYADH = ZoneInfo("Asia/Riyadh")


def h(value: object) -> str:
    return html.escape(str(value), quote=True)


def price(value: float | None) -> str:
    if value is None:
        return "—"
    return f"{value:.8f}".rstrip("0").rstrip(".")


def score_percent(op: Opportunity) -> int:
    return max(0, min(100, round(op.score / max(op.score_max, 1) * 100)))


def direction_ar(direction: int) -> str:
    return "صعود / شراء فني" if direction > 0 else "هبوط / بيع فني" if direction < 0 else "محايد"


def direction_short(direction: int) -> str:
    return "صعود" if direction > 0 else "هبوط" if direction < 0 else "محايد"


def status_ar(status: str) -> str:
    return {
        "ACTIVE": "نشطة",
        "TARGET_1": "تحقق الهدف الأول",
        "TARGET_2": "تحقق الهدف الثاني",
        "COMPLETED": "مكتملة",
        "STOPPED": "ضُرب الوقف الفني",
        "CANCELLED": "ملغاة",
    }.get(status, status)


def event_title(event: AlertEvent, direction: int) -> tuple[str, str]:
    if event in {AlertEvent.NEW_LONG, AlertEvent.NEW_SHORT}:
        return ("🟢" if direction > 0 else "🔴", "فرصة فنية جديدة")
    return {
        AlertEvent.TARGET_1: ("🎯", "تحقق الهدف الأول"),
        AlertEvent.TARGET_2: ("🎯", "تحقق الهدف الثاني"),
        AlertEvent.TARGET_3: ("🏁", "اكتملت الأهداف"),
        AlertEvent.STOP: ("🛑", "ضُرب الوقف الفني"),
        AlertEvent.CANCELLED: ("⚠️", "أُلغيت الفرصة"),
        AlertEvent.FAKEOUT: ("↩️", "كسر وهمي مؤكد"),
    }[event]


def human_age(iso_value: str) -> str:
    hours = age_hours(iso_value)
    if hours < 1 / 60:
        return "الآن"
    if hours < 1:
        return f"قبل {max(1, round(hours * 60))} دقيقة"
    if hours < 24:
        return f"قبل {round(hours)} ساعة"
    return f"قبل {round(hours / 24)} يوم"


def freshness_badge(op: Opportunity) -> str:
    return "🟢 حديث" if is_fresh(op.timeframe, op.updated_at) else "🟠 قديم"


def format_alert(payload: TradingViewAlert, market: str) -> str:
    icon, title = event_title(payload.event, payload.direction)
    when = payload.event_time.astimezone(RIYADH).strftime("%Y-%m-%d %H:%M")
    score = payload.score_percent
    lines = [
        f"{icon} <b>{title}</b>",
        "",
        f"<b>السوق:</b> {h(market_ar(market))}",
        f"<b>الرمز:</b> <code>{h(payload.tickerid)}</code>",
        f"<b>الفاصل:</b> {h(payload.timeframe)}",
        f"<b>الاتجاه:</b> {h(direction_ar(payload.direction))}",
    ]
    if payload.event in {AlertEvent.NEW_LONG, AlertEvent.NEW_SHORT}:
        lines += [
            f"<b>جودة التوافق:</b> {score}%",
            f"<b>الدخول المرجعي:</b> <code>{price(payload.entry)}</code>",
            f"<b>وقف الإلغاء:</b> <code>{price(payload.stop)}</code>",
            f"<b>الهدف 1:</b> <code>{price(payload.target1)}</code>",
        ]
        if payload.target_count >= 2:
            lines.append(f"<b>الهدف 2:</b> <code>{price(payload.target2)}</code>")
        if payload.target_count >= 3:
            lines.append(f"<b>الهدف 3:</b> <code>{price(payload.target3)}</code>")
        if payload.counter_trend:
            lines.append("<b>تنبيه:</b> الفرصة عكس السياق الأعلى.")
    else:
        lines.append(f"<b>السعر المسجل:</b> <code>{price(payload.price)}</code>")
    lines += [
        f"<b>الوقت:</b> {when} بتوقيت الرياض",
        "",
        "<i>تحليل فني للمراقبة فقط؛ لا توجد أوامر أو صلة بمحفظة تداول.</i>",
    ]
    return "\n".join(lines)


def format_opportunity(op: Opportunity, detailed: bool = True) -> str:
    lines = [
        f"<b>{h(op.tickerid)}</b> — {h(direction_ar(op.direction))}",
        f"السوق: {h(market_ar(op.market))} | الفاصل: {h(op.timeframe)}",
        f"الحالة: {h(status_ar(op.status))} | التوافق: {score_percent(op)}%",
        f"الحداثة: {freshness_badge(op)} — {h(human_age(op.updated_at))}",
    ]
    if detailed:
        lines += [
            f"الدخول المرجعي: <code>{price(op.entry)}</code>",
            f"وقف الإلغاء: <code>{price(op.stop)}</code>",
            f"الأهداف: <code>{price(op.target1)}</code> / <code>{price(op.target2)}</code> / <code>{price(op.target3)}</code>",
        ]
        if op.counter_trend:
            lines.append("⚠️ الفرصة عكس السياق الأعلى.")
    return "\n".join(lines)


def format_search_results(
    title: str,
    opportunities: list[Opportunity],
    market: str | None = None,
    horizon: str = "ALL",
    min_score: int = 0,
    options_mode: bool = False,
) -> str:
    subtitle = []
    if market and market != "ALL":
        subtitle.append(market_ar(market))
    if horizon != "ALL":
        subtitle.append(horizon_ar(horizon))
    if min_score:
        subtitle.append(f"قوة توافق {min_score}+")
    header = f"<b>{h(title)}</b>"
    if subtitle:
        header += "\n" + " | ".join(h(item) for item in subtitle)
    if not opportunities:
        return header + "\n\nلا توجد فرص مطابقة وحديثة حاليًا."
    blocks = [header]
    for index, op in enumerate(opportunities, start=1):
        bias = "CALL" if op.direction > 0 else "PUT"
        option_text = f" | مراقبة {bias}" if options_mode else ""
        blocks.append(
            f"{index}. <code>{h(op.tickerid)}</code> — {h(direction_short(op.direction))}{option_text}\n"
            f"   {h(op.timeframe)} | {score_percent(op)}% | {h(status_ar(op.status))}\n"
            f"   {freshness_badge(op)} — {h(human_age(op.updated_at))}"
        )
    blocks.append("\n<i>النتائج من أحدث ما أرسله TradingView إلى الخادم السحابي.</i>")
    return "\n\n".join(blocks)


def format_symbol_analysis(symbol: str, opportunities: list[Opportunity]) -> str:
    if not opportunities:
        return (
            f"<b>تحليل {h(symbol.upper())}</b>\n\n"
            "لا توجد بيانات محفوظة لهذا الرمز ضمن التنبيهات المراقبة في TradingView."
        )

    active = [op for op in opportunities if op.status in {"ACTIVE", "TARGET_1", "TARGET_2"}]
    considered = active or opportunities
    weighted = sum(op.direction * score_percent(op) for op in considered if is_fresh(op.timeframe, op.updated_at))
    if weighted > 20:
        consensus = "إيجابي / صاعد"
        icon = "🟢"
    elif weighted < -20:
        consensus = "سلبي / هابط"
        icon = "🔴"
    else:
        consensus = "مختلط أو غير مكتمل"
        icon = "🟡"

    freshest = max(opportunities, key=lambda item: item.updated_at)
    best = max(considered, key=score_percent)
    lines = [
        f"📊 <b>التحليل الفني — {h(freshest.tickerid)}</b>",
        "",
        f"{icon} <b>الخلاصة متعددة الفواصل:</b> {h(consensus)}",
        f"<b>أفضل فرصة محفوظة:</b> {h(direction_ar(best.direction))} على {h(best.timeframe)}",
        f"<b>التوافق:</b> {score_percent(best)}%",
        f"<b>آخر تحديث:</b> {h(human_age(freshest.updated_at))}",
        "",
        "<b>تفاصيل الفواصل:</b>",
    ]
    for op in opportunities[:8]:
        lines.append(
            f"• {h(op.timeframe)}: {h(direction_short(op.direction))} | "
            f"{score_percent(op)}% | {h(status_ar(op.status))} | {freshness_badge(op)}"
        )
    lines += [
        "",
        f"<b>الدخول المرجعي:</b> <code>{price(best.entry)}</code>",
        f"<b>وقف الإلغاء:</b> <code>{price(best.stop)}</code>",
        f"<b>الأهداف:</b> <code>{price(best.target1)}</code> / <code>{price(best.target2)}</code> / <code>{price(best.target3)}</code>",
        "",
        "<i>هذه قراءة فنية مبنية على آخر إشارات TradingView المخزنة، وليست توصية شخصية أو ضمانًا للنتيجة.</i>",
    ]
    return "\n".join(lines)


def format_health(snapshot: dict[str, object]) -> str:
    last = snapshot.get("last_event")
    counts = snapshot.get("active_by_market") or {}
    lines = ["🩺 <b>حالة البوت وتدفق البيانات</b>", "", "✅ الخادم يعمل ويستجيب."]
    if isinstance(last, dict):
        received_at = str(last.get("received_at"))
        lines += [
            f"<b>آخر تنبيه TradingView:</b> {h(human_age(received_at))}",
            f"<b>آخر رمز:</b> <code>{h(last.get('tickerid'))}</code> — {h(last.get('timeframe'))}",
        ]
    else:
        lines.append("⚠️ لم يصل أي تنبيه من TradingView حتى الآن.")
    if isinstance(counts, dict):
        total = sum(int(value) for value in counts.values())
        lines.append(f"<b>الفرص النشطة:</b> {total}")
        for market, count in sorted(counts.items()):
            lines.append(f"• {h(market_ar(str(market)))}: {int(count)}")
    lines += [
        f"<b>المشتركون:</b> {int(snapshot.get('subscribers') or 0)}",
        f"<b>رسائل بانتظار الإرسال:</b> {int(snapshot.get('pending_notifications') or 0)}",
        "",
        "<i>إذا كان آخر تنبيه قديمًا أثناء ساعات السوق، راجع تنبيهات TradingView.</i>",
    ]
    return "\n".join(lines)
