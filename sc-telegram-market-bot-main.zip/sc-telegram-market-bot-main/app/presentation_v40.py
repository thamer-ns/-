from __future__ import annotations

import html
import math
import re
from datetime import timezone

from .market_data import ScanReport
from .presets import PresetReport
from .presets_v39 import frame_code_label
from .school_engine_v38 import FRAME_SPECS
from .school_engine_v39 import is_executable_opportunity
from .risk_engine_v41 import round_market_price, tick_size
from .technical import FrameAnalysis, LiveAnalysis

TELEGRAM_LIMIT = 4096
SAFE_LIMIT = 3900


def price(value: float | None) -> str:
    if value is None:
        return "—"
    return f"{value:.5f}".rstrip("0").rstrip(".")


def progress(frame: FrameAnalysis) -> int:
    for reason in frame.reasons:
        match = re.search(r"تقدم الخطة:\s*(\d+)/3", reason)
        if match:
            return max(0, min(3, int(match.group(1))))
    match = re.search(r"تحقق الهدف\s+(\d)", frame.plan_state)
    return max(0, min(3, int(match.group(1)))) if match else 0


def _range_text(low: int, high: int, unit: str, singular: str) -> str:
    low = max(1, low)
    high = max(low, high)
    if low == high:
        return f"نحو {singular}" if low == 1 else f"نحو {low} {unit}"
    return f"من {low} إلى {high} {unit}"


def duration(frame: FrameAnalysis) -> str:
    if frame.entry is None or not frame.targets or frame.atr <= 0:
        return "غير متاحة قبل اكتمال الخطة"
    if (
        frame.duration_low_bars is not None
        and frame.duration_high_bars is not None
    ):
        bars_low = max(1, frame.duration_low_bars)
        bars_high = max(bars_low, frame.duration_high_bars)
    else:
        reached = progress(frame)
        target = frame.targets[min(reached, len(frame.targets) - 1)]
        reference = (
            frame.entry if "مشروطة" in frame.plan_state else frame.price
        )
        distance = abs(target - reference)
        bars_low = max(
            1, math.ceil(distance / max(frame.atr * 0.85, 1e-12))
        )
        bars_high = max(
            bars_low,
            math.ceil(distance / max(frame.atr * 0.35, 1e-12)),
        )

    minute_map = {
        "1 دقيقة": 1,
        "5 دقائق": 5,
        "15 دقيقة": 15,
        "30 دقيقة": 30,
        "ساعة": 60,
        "4 ساعات": 240,
    }
    if frame.frame in minute_map:
        minutes = minute_map[frame.frame]
        total_low = bars_low * minutes
        total_high = bars_high * minutes
        if frame.market in {"SAUDI", "US", "US_OPTIONS"}:
            # Equity 4-hour candles are session buckets: the second bucket is
            # shorter than four clock hours.  Convert them as two buckets per
            # session instead of overstating them as 480 minutes.
            if frame.frame == "4 ساعات":
                return _range_text(
                    max(1, math.ceil(bars_low / 2)),
                    max(1, math.ceil(bars_high / 2)),
                    "جلسات تداول",
                    "جلسة تداول واحدة",
                )
            session_minutes = 300 if frame.market == "SAUDI" else 390
            if total_high >= session_minutes:
                return _range_text(
                    max(1, math.ceil(total_low / session_minutes)),
                    max(1, math.ceil(total_high / session_minutes)),
                    "جلسات تداول",
                    "جلسة تداول واحدة",
                )
        if total_high < 60:
            return _range_text(
                total_low,
                total_high,
                "دقيقة تداول",
                "دقيقة تداول واحدة",
            )
        if total_high < 24 * 60:
            return _range_text(
                max(1, math.ceil(total_low / 60)),
                max(1, math.ceil(total_high / 60)),
                "ساعات تداول",
                "ساعة تداول واحدة",
            )
        return _range_text(
            max(1, math.ceil(total_low / (24 * 60))),
            max(1, math.ceil(total_high / (24 * 60))),
            "أيام",
            "يوم واحد",
        )
    if frame.frame == "يومي":
        return _range_text(
            bars_low, bars_high, "جلسات تداول", "جلسة تداول واحدة"
        )
    if frame.frame == "أسبوعي":
        return _range_text(bars_low, bars_high, "أسابيع", "أسبوع واحد")
    return _range_text(bars_low, bars_high, "أشهر", "شهر واحد")


def entry_zone(frame: FrameAnalysis) -> tuple[float, float] | None:
    if frame.entry is None:
        return None
    tick = tick_size(frame.market, frame.entry)
    width = max(frame.atr * 0.15, frame.entry * 0.0008, 2 * tick)
    if frame.direction > 0:
        return (
            round_market_price(frame.market, frame.entry, "up"),
            round_market_price(frame.market, frame.entry + width, "up"),
        )
    return (
        round_market_price(frame.market, frame.entry - width, "down"),
        round_market_price(frame.market, frame.entry, "down"),
    )


def qualified(frame: FrameAnalysis) -> bool:
    return bool(getattr(frame, "consensus_qualified", False))


def plan_valid(frame: FrameAnalysis) -> bool:
    return bool(getattr(frame, "plan_valid", False))


def direction_text(direction: int) -> str:
    return "صعود" if direction > 0 else "هبوط" if direction < 0 else "مراقبة"


def direction_icon(direction: int) -> str:
    return "🟢" if direction > 0 else "🔴" if direction < 0 else "🟡"


def signal_type(frame: FrameAnalysis) -> str:
    return str(getattr(frame, "signal_type", "") or frame.event or "قراءة فنية")


def state_explanation(frame: FrameAnalysis) -> str:
    if not qualified(frame):
        return "مراقبة فقط — لا يوجد توافق كافٍ بين المدارس لإصدار فرصة."
    if not plan_valid(frame):
        return "الرأي الفني واضح، لكن لا توجد حاليًا خطة دخول ووقف وأهداف اجتازت شروط المخاطرة."
    reached = progress(frame)
    state = frame.plan_state
    if reached:
        return f"الخطة مستمرة — تحقق {reached} من 3 أهداف، وليست دخولًا جديدًا."
    if "الدخول الجديد متأخر" in state:
        return "الخطة ما زالت قائمة، لكن السعر ابتعد عن منطقة الدخول؛ انتظر عودة السعر ولا تطارد الحركة."
    if "إعادة اختبار عميقة" in state:
        return "الخطة قائمة، والسعر عاد بعمق نحو منطقة الدخول؛ تبقى صالحة ما دام الوقف لم يُكسر."
    if "إعادة اختبار" in state:
        return "الخطة قائمة، والسعر عاد لاختبار منطقة الدخول المحددة."
    if "مشروطة" in state:
        return "فرصة بانتظار التفعيل — الاتجاه موجود، لكن شرط الدخول لم يتأكد بعد."
    if "دخول قائم" in state:
        return "فرصة مفعّلة — تحقق شرط الدخول، والسعر ما زال قريبًا من منطقة التنفيذ."
    return "فرصة فنية مكتملة — الدخول والوقف والأهداف جاهزة للمتابعة."


def alignment_explanation(value: str) -> str:
    text = value.strip()
    if "تعارض" in text:
        return f"{text} — لا تجمع الفواصل كإشارة واحدة؛ التزم بخطة الفاصل المختار."
    if "جزئي" in text or "انتقال" in text:
        return f"{text} — بعض الفواصل تؤيد الاتجاه وبعضها مختلف؛ اعتمد خطة الفاصل الأنسب فقط."
    if "توافق" in text:
        return f"{text} — أغلب الفواصل المدروسة تميل إلى الاتجاه نفسه."
    return text


def _short(value: str, limit: int = 600) -> str:
    text = str(value).strip()
    return text if len(text) <= limit else text[: limit - 1].rstrip() + "…"


def school_lines(frame: FrameAnalysis, max_details: int = 9) -> list[str]:
    names = tuple(getattr(frame, "school_names", ()))
    axes = tuple(getattr(frame, "independent_axes", ()))
    details = tuple(getattr(frame, "school_details", ()))
    opposing = tuple(getattr(frame, "opposing_school_names", ()))
    if not names:
        lines = [
            "عدد المدارس المتوافقة: <b>0</b> — لا يوجد توافق كافٍ حاليًا."
        ]
    elif getattr(frame, "strong_single_school", False):
        lines = [
            f"مدرسة واحدة قوية قابلة للتنفيذ: <b>{html.escape(names[0])}</b>"
        ]
    else:
        lines = [
            f"المدارس المتوافقة: <b>{len(names)}</b> — "
            f"{html.escape(' + '.join(names))}"
        ]
        if axes:
            lines.append(
                f"محاور الأدلة المستقلة: <b>{len(axes)}</b> — "
                f"{html.escape(' + '.join(axes))}"
            )
    if opposing:
        lines.append(
            "⚠️ توجد قراءة معاكسة من: "
            + html.escape(" + ".join(opposing))
        )
    lines.extend(
        f"• {html.escape(_short(detail))}" for detail in details[:max_details]
    )
    return lines


def plan_lines(frame: FrameAnalysis, *, heading: bool = True) -> list[str]:
    if not is_executable_opportunity(frame):
        return []
    assert frame.entry is not None and frame.stop is not None
    lines: list[str] = []
    if heading:
        lines.append(
            f"<b>🎯 خطة الفرصة على فاصل {html.escape(frame.frame)}</b>"
        )
    reached = progress(frame)
    if "مشروطة" in frame.plan_state:
        side = "فوق" if frame.direction > 0 else "تحت"
        lines.append(
            f"شرط التفعيل: إغلاق شمعة {html.escape(frame.frame)} "
            f"{side} <b>{price(frame.entry)}</b>"
        )
        lines.append(f"الدخول بعد التفعيل: <b>{price(frame.entry)}</b>")
    else:
        lines.append(f"الدخول المرجعي: <b>{price(frame.entry)}</b>")
    zone = entry_zone(frame)
    if zone:
        lines.append(
            f"نطاق التنفيذ: <code>{price(zone[0])} - {price(zone[1])}</code>"
        )
    risk_pct = abs(frame.entry - frame.stop) / max(frame.entry, 1e-9) * 100
    risk_atr = (
        f" | {frame.risk_atr:.2f} ATR"
        if frame.risk_atr is not None
        else ""
    )
    lines.append(
        f"🛑 وقف إلغاء الفكرة: <b>{price(frame.stop)}</b> — "
        f"مخاطرة سعرية {risk_pct:.2f}%{risk_atr}"
    )
    for index, target in enumerate(frame.targets, 1):
        marker = "✅" if index <= reached else "🎯"
        move_pct = abs(target - frame.entry) / max(frame.entry, 1e-9) * 100
        target_atr = (
            f" | {frame.target_atr[index - 1]:.2f} ATR"
            if index - 1 < len(frame.target_atr)
            else ""
        )
        lines.append(
            f"{marker} الهدف {index}: <b>{price(target)}</b> — "
            f"مسافة {move_pct:.2f}%{target_atr}"
        )
    lines.append(
        "⏱ المدة التقديرية للوصول إلى الهدف التالي: "
        f"<b>{html.escape(duration(frame))}</b>"
    )
    if frame.duration_method.startswith("historical-first-passage"):
        rate = (
            f"؛ وصل الهدف قبل الوقف في {frame.duration_success_rate * 100:.0f}% "
            "من الحالات المقارنة"
            if frame.duration_success_rate is not None
            else ""
        )
        regime = (
            "اتجاه وتذبذب متقاربان"
            if frame.duration_method == "historical-first-passage"
            else "اتجاه متقارب مع نطاق تذبذب أوسع"
        )
        lines.append(
            f"منهج المدة: عبور تاريخي مزدوج الحاجز — {regime} "
            f"({frame.duration_samples} حالة مقارنة{rate})."
        )
        lines.append(
            "هذه النسبة وصف للعينة التاريخية وليست احتمال نجاح مضمونًا."
        )
    elif frame.duration_method == "atr-range-fallback":
        lines.append(
            "منهج المدة: نطاق تقريبي من ATR لعدم كفاية عينات تاريخية مماثلة."
        )
    if reached:
        lines.append(
            "ℹ️ هذه خطة متابعة بعد تحقق هدف؛ لا تُعامل كنقطة دخول جديدة."
        )
    elif "الدخول الجديد متأخر" in frame.plan_state:
        lines.append(
            "ℹ️ السعر ممتد عن الدخول؛ انتظر إعادة اختبار بدل الدخول المتأخر."
        )
    return lines


def frame_block(frame: FrameAnalysis) -> list[str]:
    names = tuple(getattr(frame, "school_names", ()))
    icon = direction_icon(frame.direction) if qualified(frame) else "🟡"
    if is_executable_opportunity(frame):
        title = (
            f"{icon} <b>{html.escape(frame.frame)} — فرصة "
            f"{direction_text(frame.direction)} قابلة للتنفيذ</b>"
        )
        schools = html.escape(" + ".join(names)) if names else "لا يوجد"
        return [
            title,
            f"النوع: <b>{html.escape(signal_type(frame))}</b> | قوة التوافق: <b>{frame.confidence}/100</b>",
            f"المدارس ({len(names)}): {schools}",
            f"الحالة: {html.escape(state_explanation(frame))}",
            *plan_lines(frame, heading=False),
        ]
    if qualified(frame):
        schools = html.escape(" + ".join(names)) if names else "لا يوجد"
        return [
            f"🧭 <b>{html.escape(frame.frame)} — رأي فني بلا خطة تنفيذ</b>",
            f"الاتجاه: {direction_text(frame.direction)} | النوع: {html.escape(signal_type(frame))} | قوة التوافق: {frame.confidence}/100",
            f"المدارس ({len(names)}): {schools}",
            "القرار: انتظر ظهور دخول ووقف وأهداف صالحة قبل اعتبارها فرصة.",
        ]
    observed = html.escape(" + ".join(names[:2])) if names else "لا توافق كافٍ"
    return [
        f"🟡 <b>{html.escape(frame.frame)} — مراقبة فقط</b> | قوة التوافق: {frame.confidence}/100 | الإشارات: {observed}"
    ]


def _pack_blocks(
    header: list[str],
    blocks: list[list[str]],
    footer: list[str] | None = None,
) -> tuple[str, ...]:
    footer = footer or []
    pages: list[str] = []
    current = list(header)
    for block in blocks:
        if len(current) > len(header):
            block = ["", *block]
        for line in block:
            candidate = "\n".join(current + [line] + footer)
            if len(candidate) > SAFE_LIMIT and len(current) > len(header):
                pages.append("\n".join(current + footer))
                current = list(header)
                if line:
                    current.append("")
            current.append(line)
    if current:
        pages.append("\n".join(current + footer))
    if not all(len(page) <= TELEGRAM_LIMIT for page in pages):
        raise ValueError("Telegram presentation page exceeds limit")
    return tuple(page for page in pages if page)


def analysis_pages(item: LiveAnalysis) -> tuple[str, ...]:
    from .school_format_v39 import select_primary_frame_v39

    primary = select_primary_frame_v39(item)
    title = [
        f"📊 <b>{html.escape(item.display_symbol)} — {html.escape(item.name)}</b>",
        f"السعر الحالي: <b>{price(item.price)} {html.escape(item.currency)}</b>",
    ]
    summary_block = [
        "<b>✅ الخلاصة التنفيذية</b>",
        f"{direction_icon(primary.direction)} <b>{html.escape(state_explanation(primary))}</b>",
        f"الرأي: <b>{direction_text(primary.direction)}</b> | نوع الإشارة: <b>{html.escape(signal_type(primary))}</b>",
        f"الفاصل الأنسب: <b>{html.escape(primary.frame)}</b> | قوة التوافق: <b>{primary.confidence}/100</b>",
        f"توافق الفواصل: <b>{html.escape(alignment_explanation(item.alignment))}</b>",
    ]
    schools_block = [
        "<b>🧠 لماذا ظهرت هذه النتيجة؟</b>",
        *school_lines(primary),
    ]
    if is_executable_opportunity(primary):
        decision_block = plan_lines(primary)
    elif qualified(primary):
        decision_block = [
            "<b>🎯 قرار التنفيذ</b>",
            "لا توجد خطة تنفيذ صالحة حاليًا؛ الرأي الفني وحده لا يكفي للدخول.",
            f"أقرب دعم: <b>{price(primary.support)}</b> | أقرب مقاومة: <b>{price(primary.resistance)}</b>",
        ]
    else:
        decision_block = [
            "<b>🎯 قرار التنفيذ</b>",
            "لا توجد فرصة مكتملة الآن. انتظر توافق المدارس وظهور دخول ووقف وأهداف واضحة.",
            f"أقرب دعم: <b>{price(primary.support)}</b> | أقرب مقاومة: <b>{price(primary.resistance)}</b>",
        ]
    warnings = list(dict.fromkeys(primary.warnings))[:6]
    risk_block: list[str] = []
    if warnings:
        risk_block.extend(["<b>⚠️ ملاحظات المخاطر</b>"])
        risk_block.extend(f"• {html.escape(_short(value))}" for value in warnings)
    updated = item.updated_at.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    risk_block.extend(
        [
            f"مصدر الشموع: <b>{html.escape(item.feed_source)}</b> | آخر إغلاق: <code>{updated}</code>",
            "<i>التحليل فني احتمالي. الوقف هو مستوى إلغاء الفكرة، والمدة تقديرية وليست ضمانًا.</i>",
        ]
    )
    primary_pages = _pack_blocks(
        title,
        [summary_block, schools_block, decision_block, risk_block],
    )
    if len(item.frames) <= 1:
        return primary_pages
    frame_pages = _pack_blocks(
        [
            f"🧭 <b>تفاصيل الفواصل — {html.escape(item.display_symbol)}</b>",
            "الفرص القابلة للتنفيذ تظهر بخطة كاملة؛ فواصل المراقبة تظهر مختصرة.",
        ],
        [frame_block(frame) for frame in item.frames],
        [
            "",
            "<i>اعتمد كل فرصة على فاصلها ولا تخلط دخول فاصل قصير بأهداف فاصل طويل.</i>",
        ],
    )
    return (*primary_pages, *frame_pages)


def scan_title(report: ScanReport) -> str:
    market = {
        "SAUDI": "السوق السعودي",
        "US": "السوق الأمريكي",
        "US_OPTIONS": "الأوبشن الأمريكي حسب اتجاه الأصل",
        "FOREX": "العملات",
        "CRYPTO": "العملات الرقمية",
    }.get(report.market, report.market)
    if report.market == "US_OPTIONS":
        if report.direction > 0:
            return f"🟢 فرص CALL مؤكدة — {market}"
        if report.direction < 0:
            return f"🔴 فرص PUT مؤكدة — {market}"
        return f"🔎 فرص CALL وPUT مؤكدة — {market}"
    if report.direction > 0:
        return f"🧰 خطط صعود/شراء فنية مؤكدة — {market}"
    if report.direction < 0:
        return f"🧰 خطط هبوط فنية مؤكدة — {market}"
    return f"🔎 فرص فنية مؤكدة — {market}"


def scan_item_block(
    index: int,
    item: LiveAnalysis,
    options_mode: bool = False,
) -> list[str]:
    frame = item.frames[0]
    names = tuple(getattr(frame, "school_names", ()))
    side = "CALL" if frame.direction > 0 else "PUT"
    label = f" — {side} حسب الأصل" if options_mode else ""
    zone = entry_zone(frame)
    risk_pct = (
        abs(float(frame.entry) - float(frame.stop))
        / max(float(frame.entry), 1e-9)
        * 100
    )
    lines = [
        f"{index}. {direction_icon(frame.direction)} <b>{html.escape(item.display_symbol)} — {html.escape(item.name)}</b>{label}",
        f"الاتجاه: <b>{direction_text(frame.direction)}</b> | النوع: <b>{html.escape(signal_type(frame))}</b> | قوة التوافق: <b>{frame.confidence}/100</b>",
        f"المدارس ({len(names)}): {html.escape(' + '.join(names) if names else 'لا يوجد')}",
        f"الدخول: <b>{price(frame.entry)}</b>"
        + (
            f" | النطاق: <code>{price(zone[0])} - {price(zone[1])}</code>"
            if zone
            else ""
        ),
        f"🛑 الوقف: <b>{price(frame.stop)}</b> — مخاطرة {risk_pct:.2f}%",
    ]
    lines.extend(
        f"🎯 الهدف {idx}: <b>{price(target)}</b>"
        for idx, target in enumerate(frame.targets, 1)
    )
    lines.append(f"⏱ المدة التقديرية: <b>{html.escape(duration(frame))}</b>")
    return lines


def scan_pages(report: ScanReport) -> tuple[str, ...]:
    frame_label = (
        FRAME_SPECS[report.horizon].label
        if report.horizon in FRAME_SPECS
        else report.horizon
    )
    header = [
        f"<b>{html.escape(scan_title(report))}</b>",
        f"الفاصل: <b>{html.escape(frame_label)}</b> | تم تحليل: <b>{report.analyzed_symbols}/{report.total_symbols}</b>",
        *(
            [f"⚠️ تعذر أو لم يكتمل تحليل <b>{report.failed_symbols}</b> رموز؛ النتائج تخص المكتمل فقط."]
            if report.failed_symbols
            else []
        ),
        "كل نتيجة أدناه اجتازت توافق المدارس وصحة الدخول والوقف والأهداف.",
        *(
            ["ℹ️ CALL/PUT هنا اتجاه الأصل فقط؛ اختيار العقد يحتاج Strike وExpiry وIV وGreeks وسيولة العقد."]
            if report.market == "US_OPTIONS"
            else []
        ),
    ]
    if not report.items:
        return (
            "\n".join(
                header
                + [
                    "",
                    "لا توجد حاليًا فرصة مكتملة تطابق هذه الشروط.",
                    "<i>عدم ظهور نتيجة أفضل من تخفيف شروط المخاطرة أو عرض قراءة غير قابلة للتنفيذ.</i>",
                ]
            ),
        )
    return _pack_blocks(
        header,
        [
            scan_item_block(index, item, report.market == "US_OPTIONS")
            for index, item in enumerate(report.items[:10], 1)
        ],
        [
            "",
            "<i>اضغط على الرمز لعرض المدارس بالتفصيل وتحليل بقية الفواصل.</i>",
        ],
    )


def preset_item_block(index: int, match) -> list[str]:
    item = match.analysis
    frame = item.frames[0]
    reason = (
        "، ".join(html.escape(_short(value, 300)) for value in match.reasons[:3])
        or "مطابقة الشرط الفني"
    )
    lines = [
        f"{index}. {direction_icon(frame.direction)} <b>{html.escape(item.display_symbol)} — {html.escape(item.name)}</b>",
        f"السعر: <b>{price(item.price)} {html.escape(item.currency)}</b> | قوة التوافق: <b>{frame.confidence}/100</b>",
        f"سبب الظهور: {reason}",
    ]
    if is_executable_opportunity(frame):
        lines.extend(plan_lines(frame, heading=False))
    else:
        lines.append(
            "الحالة: اكتشاف فني فقط — لا توجد خطة دخول مكتملة على هذا الفاصل."
        )
    return lines


def preset_pages(report: PresetReport, frame_code: str) -> tuple[str, ...]:
    frame_name = frame_code_label(frame_code)
    header = [
        f"🧰 <b>{html.escape(report.preset.title)}</b>",
        html.escape(report.preset.description),
        "",
        f"السوق: <b>{html.escape(report.universe_label)}</b>",
        f"الفاصل: <b>{html.escape(frame_name)}</b> — شموع مغلقة فقط",
        f"تم تحليل: <b>{report.analyzed_symbols}/{report.total_symbols}</b>",
    ]
    if not report.items:
        return (
            "\n".join(
                header
                + [
                    "",
                    "لم يظهر رمز مطابق للفلتر الآن.",
                    "<i>مطابقة الفلتر لا تُصنع بتخفيف الشروط أو استخدام شمعة غير مكتملة.</i>",
                ]
            ),
        )
    return _pack_blocks(
        header,
        [
            preset_item_block(index, match)
            for index, match in enumerate(report.items[:10], 1)
        ],
        [
            "",
            "<i>الفلاتر غير المشروطة قد تعرض اكتشافًا فنيًا؛ الخطط المؤكدة فقط تعرض دخولًا ووقفًا وأهدافًا.</i>",
        ],
    )
