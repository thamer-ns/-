from __future__ import annotations

from datetime import datetime, timezone
from urllib.parse import quote

US_PREFIXES = {
    "NASDAQ",
    "NYSE",
    "AMEX",
    "ARCA",
    "BATS",
    "CBOE",
    "OTC",
}


def classify_market(tickerid: str, instrument_type: str | None) -> str:
    prefix = tickerid.split(":", 1)[0].upper() if ":" in tickerid else ""
    kind = (instrument_type or "").lower()
    if prefix == "TADAWUL":
        return "SAUDI"
    if kind == "option":
        return "OPTIONS"
    if kind == "forex":
        return "FOREX"
    if kind == "crypto":
        return "CRYPTO"
    if kind in {"index", "futures", "cfd", "bond"}:
        return "GLOBAL"
    if prefix in US_PREFIXES:
        return "US"
    return "OTHER"


def tradingview_chart_url(tickerid: str) -> str:
    return "https://www.tradingview.com/chart/?symbol=" + quote(tickerid, safe="")


def market_ar(market: str) -> str:
    return {
        "ALL": "جميع الأسواق",
        "SAUDI": "السوق السعودي",
        "US": "السوق الأمريكي",
        "FOREX": "العملات",
        "OPTIONS": "الأوبشن الأمريكي",
        "CRYPTO": "العملات الرقمية",
        "GLOBAL": "الأسواق العالمية",
        "OTHER": "سوق آخر",
    }.get(market, market)


def timeframe_minutes(timeframe: str) -> int | None:
    text = timeframe.strip().upper()
    if text.isdigit():
        return int(text)
    if text.endswith("S") and text[:-1].isdigit():
        return max(1, int(text[:-1]) // 60)
    aliases = {
        "D": 1440,
        "1D": 1440,
        "W": 10080,
        "1W": 10080,
        "M": 43200,
        "1M": 43200,
    }
    return aliases.get(text)


def timeframe_horizon(timeframe: str) -> str:
    minutes = timeframe_minutes(timeframe)
    if minutes is None:
        return "ALL"
    if minutes <= 60:
        return "INTRADAY"
    if minutes < 1440:
        return "SWING"
    return "DAILY"


def horizon_ar(horizon: str) -> str:
    return {
        "ALL": "كل الفواصل",
        "INTRADAY": "لحظي حتى ساعة",
        "SWING": "سوينق من ساعتين إلى 4 ساعات",
        "DAILY": "يومي وأعلى",
    }.get(horizon, horizon)


def freshness_limit_hours(timeframe: str) -> float:
    minutes = timeframe_minutes(timeframe)
    if minutes is None:
        return 24.0
    if minutes <= 5:
        return 1.0
    if minutes <= 15:
        return 2.0
    if minutes <= 60:
        return 6.0
    if minutes < 1440:
        return 18.0
    if minutes <= 1440:
        return 72.0
    if minutes <= 10080:
        return 24.0 * 14
    return 24.0 * 45


def age_hours(iso_value: str) -> float:
    dt = datetime.fromisoformat(iso_value)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return max(0.0, (datetime.now(timezone.utc) - dt.astimezone(timezone.utc)).total_seconds() / 3600)


def is_fresh(timeframe: str, updated_at: str) -> bool:
    return age_hours(updated_at) <= freshness_limit_hours(timeframe)
