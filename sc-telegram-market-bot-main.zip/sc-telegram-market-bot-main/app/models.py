from __future__ import annotations

from datetime import datetime, timezone
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class AlertEvent(StrEnum):
    NEW_LONG = "NEW_LONG"
    NEW_SHORT = "NEW_SHORT"
    TARGET_1 = "TARGET_1"
    TARGET_2 = "TARGET_2"
    TARGET_3 = "TARGET_3"
    STOP = "STOP"
    CANCELLED = "CANCELLED"
    FAKEOUT = "FAKEOUT"


EVENT_ALIASES = {
    "NL": AlertEvent.NEW_LONG,
    "NS": AlertEvent.NEW_SHORT,
    "T1": AlertEvent.TARGET_1,
    "T2": AlertEvent.TARGET_2,
    "T3": AlertEvent.TARGET_3,
    "SL": AlertEvent.STOP,
    "C": AlertEvent.CANCELLED,
    "FO": AlertEvent.FAKEOUT,
    "NEW_PLAN_LONG": AlertEvent.NEW_LONG,
    "NEW_PLAN_SHORT": AlertEvent.NEW_SHORT,
}


class TradingViewAlert(BaseModel):
    """Normalized payload accepted from compact or descriptive Pine JSON."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    version: int = Field(default=1, validation_alias="v")
    source: str = Field(default="?", validation_alias="s")
    event: AlertEvent = Field(validation_alias="e")
    tickerid: str = Field(validation_alias="x")
    instrument_type: str | None = Field(default=None, validation_alias="y")
    timeframe: str = Field(default="?", validation_alias="f")
    event_time_ms: int | None = Field(default=None, validation_alias="t")
    price: float | None = Field(default=None, validation_alias="p")
    direction: int = Field(default=0, validation_alias="d")
    entry: float | None = Field(default=None, validation_alias="en")
    stop: float | None = Field(default=None, validation_alias="sl")
    target1: float | None = Field(default=None, validation_alias="t1")
    target2: float | None = Field(default=None, validation_alias="t2")
    target3: float | None = Field(default=None, validation_alias="t3")
    target_count: int = Field(default=3, validation_alias="n")
    score: int = Field(default=0, validation_alias="q")
    score_max: int = Field(default=1, validation_alias="qm")
    counter_trend: bool = Field(default=False, validation_alias="ct")

    @field_validator("event", mode="before")
    @classmethod
    def normalize_event(cls, value: Any) -> Any:
        if isinstance(value, AlertEvent):
            return value
        text = str(value).strip().upper()
        return EVENT_ALIASES.get(text, text)

    @field_validator("tickerid")
    @classmethod
    def normalize_tickerid(cls, value: str) -> str:
        value = value.strip().upper()
        if not value or len(value) > 80:
            raise ValueError("invalid tickerid")
        return value

    @field_validator("target_count")
    @classmethod
    def valid_target_count(cls, value: int) -> int:
        return min(max(value, 1), 3)

    @model_validator(mode="after")
    def infer_direction(self) -> "TradingViewAlert":
        if self.event == AlertEvent.NEW_LONG:
            self.direction = 1
        elif self.event == AlertEvent.NEW_SHORT:
            self.direction = -1
        self.direction = 1 if self.direction > 0 else -1 if self.direction < 0 else 0
        return self

    @property
    def ticker(self) -> str:
        return self.tickerid.split(":", 1)[-1]

    @property
    def event_time(self) -> datetime:
        if self.event_time_ms:
            return datetime.fromtimestamp(self.event_time_ms / 1000, tz=timezone.utc)
        return datetime.now(timezone.utc)

    @property
    def score_percent(self) -> int:
        if self.score_max <= 0:
            return 0
        return max(0, min(100, round(self.score / self.score_max * 100)))


class Opportunity(BaseModel):
    key: str
    event_id: int
    market: str
    tickerid: str
    ticker: str
    timeframe: str
    source: str
    direction: int
    entry: float | None
    stop: float | None
    target1: float | None
    target2: float | None
    target3: float | None
    target_count: int
    score: int
    score_max: int
    counter_trend: bool
    status: str
    last_event: str
    opened_at: str
    updated_at: str
