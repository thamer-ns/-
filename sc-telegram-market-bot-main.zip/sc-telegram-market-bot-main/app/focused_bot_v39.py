from __future__ import annotations

import html
from typing import Any

from .focused_bot_v37_helpers import provider_status_text, sources_text
from .focused_bot_v38_helpers import (
    FRAME_CALLBACK_V38,
    build_analysis_buttons_v38,
    build_frame_scan_buttons_v38,
    frame_label,
    parse_symbol_frame_v38,
)
from .focused_bot_v38_safe import (
    LiveBotService as V38SafeLiveBotService,
)
from .formatting import format_health, format_symbol_analysis
from .presets import (
    PRESET_BY_ID,
    PresetReport,
    presets_for_category,
)
from .presets_v39 import (
    FRAME_CODE_TO_KEY,
    FRAME_KEY_TO_CODE,
    V39PresetScanner,
    frame_code_label,
)
from .school_engine_v39 import VerifiedSchoolConsensusAnalyzer
from .school_format_v39 import format_analysis_v39, format_scan_v39
from .technical import MarketDataError
from .universes import US_FOCUS_UNIVERSE


FOCUSED_HELP_TEXT_V39 = """<b>بوصلة الأسواق V3.9 — فرص مدققة من دقيقة إلى شهر</b>

تدخل النتيجة في مسح الفرص فقط عندما تجتاز معًا:
• مدرسة واحدة قوية قابلة للتنفيذ، أو مدرستان مستقلتان متوافقتان.
• اتجاه واضح على الفاصل.
• دخول ووقف وثلاثة أهداف سليمة هندسيًا.

أمثلة:
<code>/analyze 2222</code> — جميع الفواصل
<code>/analyze 2222 1m</code> — دقيقة
<code>/analyze AAPL 4h</code> — 4 ساعات
<code>/analyze 1120 1w</code> — أسبوعي
<code>/analyze NVDA 1mo</code> — شهري

/scan — مسح الفرص حسب السوق والفاصل
/filters — فلاتر فنية على أي فاصل من الدقيقة إلى الشهر
/recommendations — أفضل الفرص السعودية المدققة
/options — اتجاهات CALL وPUT حسب الأصل
/active — خطط TradingView القائمة
/sources — مصادر البيانات
/status — حالة النظام

<i>الفلاتر أدوات اكتشاف، أما مسح الفرص فلا يعرض خطة بلا وقف وأهداف صحيحة. لا ينفذ البوت صفقات.</i>"""


_FRAME_BUTTONS: tuple[tuple[str, str], ...] = (
    ("1 دقيقة", "1"),
    ("5 دقائق", "5"),
    ("15 دقيقة", "15"),
    ("30 دقيقة", "30"),
    ("ساعة", "H"),
    ("4 ساعات", "4H"),
    ("يومي", "D"),
    ("أسبوعي", "W"),
    ("شهري", "MO"),
)


class LiveBotService(V38SafeLiveBotService):
    """V3.9 production Telegram service."""

    def __init__(self, settings, database, telegram) -> None:
        super().__init__(settings, database, telegram)
        self.live = VerifiedSchoolConsensusAnalyzer()
        self.scanner = V39PresetScanner(self.live)

    @staticmethod
    def _analysis_buttons(symbol: str) -> dict[str, Any]:
        return build_analysis_buttons_v38(symbol)

    @staticmethod
    def _preset_frame_menu(
        market: str, preset_id: str
    ) -> dict[str, Any]:
        rows: list[list[dict[str, str]]] = []
        for index in range(0, len(_FRAME_BUTTONS), 3):
            rows.append(
                [
                    {
                        "text": label,
                        "callback_data": (
                            f"fp:{market}:{preset_id}:{code}"
                        ),
                    }
                    for label, code in _FRAME_BUTTONS[index : index + 3]
                ]
            )
        category_id = PRESET_BY_ID[preset_id].category_id
        rows.append(
            [
                {
                    "text": "⬅️ نفس التصنيف",
                    "callback_data": f"fc:{market}:{category_id}",
                }
            ]
        )
        return {"inline_keyboard": rows}

    @staticmethod
    def _quick_filters_menu(market: str) -> dict[str, Any]:
        quick = (
            "pathup",
            "pathdn",
            "rtup",
            "rtdn",
            "planup",
            "plandn",
            "volrise",
            "squeeze",
        )
        rows: list[list[dict[str, str]]] = []
        for index in range(0, len(quick), 2):
            rows.append(
                [
                    {
                        "text": PRESET_BY_ID[preset_id].title,
                        "callback_data": f"fpf:{market}:{preset_id}",
                    }
                    for preset_id in quick[index : index + 2]
                ]
            )
        rows.append(
            [
                {
                    "text": "⬅️ التصنيفات",
                    "callback_data": f"fm:{market}",
                }
            ]
        )
        return {"inline_keyboard": rows}

    @staticmethod
    def _preset_menu(
        market: str, category_id: str
    ) -> dict[str, Any]:
        items = presets_for_category(category_id)
        rows: list[list[dict[str, str]]] = []
        for index in range(0, len(items), 2):
            rows.append(
                [
                    {
                        "text": item.title,
                        "callback_data": (
                            f"fpf:{market}:{item.preset_id}"
                        ),
                    }
                    for item in items[index : index + 2]
                ]
            )
        rows.append(
            [
                {
                    "text": "⬅️ التصنيفات",
                    "callback_data": f"fm:{market}",
                }
            ]
        )
        return {"inline_keyboard": rows}

    @staticmethod
    def _preset_result_buttons(
        report: PresetReport, frame_code: str
    ) -> dict[str, Any]:
        rows: list[list[dict[str, str]]] = []
        callback_code = frame_code.upper()
        for match in report.items[:8]:
            item = match.analysis
            rows.append(
                [
                    {
                        "text": (
                            f"📊 {item.display_symbol} · "
                            f"{item.confidence}%"
                        ),
                        "callback_data": (
                            f"a38:{item.display_symbol}:{callback_code}"
                        ),
                    }
                ]
            )
        rows += [
            [
                {
                    "text": "🕒 تغيير الفاصل",
                    "callback_data": (
                        f"fpf:{report.market}:{report.preset.preset_id}"
                    ),
                }
            ],
            [
                {
                    "text": "⬅️ نفس التصنيف",
                    "callback_data": (
                        f"fc:{report.market}:{report.preset.category_id}"
                    ),
                },
                {
                    "text": "🏠 الرئيسية",
                    "callback_data": "menu:home",
                },
            ],
        ]
        return {"inline_keyboard": rows}

    @classmethod
    def _format_preset_report(
        cls, report: PresetReport, frame_code: str
    ) -> str:
        frame_name = frame_code_label(frame_code)
        lines = [
            f"🧰 <b>{html.escape(report.preset.title)}</b>",
            html.escape(report.preset.description),
            "",
            f"السوق: <b>{html.escape(report.universe_label)}</b>",
            f"الفاصل: <b>{html.escape(frame_name)}</b> — شموع مغلقة فقط",
            f"تم تحليل: <b>{report.analyzed_symbols}/{report.total_symbols}</b>",
            "",
        ]
        if not report.items:
            lines += [
                "لم يظهر رمز مطابق للفلتر الآن.",
                "<i>عدم ظهور نتيجة لا يبرر تخفيف تعريف الإشارة أو استخدام شمعة غير مكتملة.</i>",
            ]
        for index, match in enumerate(report.items[:10], 1):
            item = match.analysis
            frame = item.frames[0]
            icon = (
                "🟢"
                if frame.direction > 0
                else "🔴"
                if frame.direction < 0
                else "🟡"
            )
            reason = "، ".join(
                html.escape(value) for value in match.reasons[:3]
            ) or "مطابقة الشرط الفني"
            status = (
                "فرصة تنفيذ"
                if getattr(frame, "plan_valid", False)
                else "اكتشاف فني"
            )
            lines += [
                f"{index}. {icon} <b>{html.escape(item.display_symbol)}</b> — {item.price:g} — قوة {item.confidence}/100 — {status}",
                f"   السبب: {reason}",
            ]
        if report.failed_symbols:
            lines += [
                "",
                f"تعذر جلب {report.failed_symbols} رمزًا في هذه الجولة.",
            ]
        lines += [
            "",
            "<i>مطابقة الفلتر ليست دائمًا فرصة دخول؛ افتح الرمز للتأكد من قبول المدارس وصحة الخطة.</i>",
        ]
        message = "\n".join(lines)
        if len(message) <= 4096:
            return message
        return "\n".join(lines[:12] + ["", "<i>اختُصرت النتائج لحماية حد Telegram.</i>"])

    async def _status_text(self) -> str:
        health = format_health(await self.db.health_snapshot())
        return (
            health
            + "\n\n<b>محرك التحليل:</b> V3.9 — تدقيق الفرص والمدارس\n"
            + "<b>شرط المسح:</b> قبول المدارس + اتجاه واضح + خطة سليمة\n"
            + "<b>الفواصل:</b> 1د، 5د، 15د، 30د، ساعة، 4س، يومي، أسبوعي، شهري\n"
            + "<b>الفلاتر:</b> تعمل على الفواصل التسعة مع مستويات سابقة للزناد\n"
            + f"<b>القائمة الأمريكية:</b> {len(US_FOCUS_UNIVERSE)} سهمًا\n"
            + provider_status_text()
            + "\n<i>لا ينفذ أوامر ولا يختار عقد أوبشن أو Greeks.</i>"
        )

    async def _send_symbol_analysis(
        self,
        chat_id: int,
        symbol: str,
        frame_key: str | None = None,
    ) -> None:
        clean = symbol.strip().upper()
        if not clean:
            await self.telegram.send_message(
                chat_id,
                "أرسل الرمز مثل <code>2222</code> أو <code>AAPL</code>، ثم الفاصل اختياريًا.",
            )
            return
        await self.telegram.send_message(
            chat_id,
            f"⏳ تحليل <code>{html.escape(clean)}</code> — "
            f"{html.escape(frame_label(frame_key))} من الشموع المغلقة...",
        )
        try:
            result = (
                await self.live.analyze_one(clean, frame_key)
                if frame_key
                else await self.live.analyze(clean)
            )
        except MarketDataError as exc:
            stored = await self.db.find_symbol(clean, limit=12)
            if stored:
                await self.telegram.send_message(
                    chat_id,
                    "⚠️ تعذر الجلب المباشر، وهذه آخر بيانات TradingView محفوظة:\n\n"
                    + format_symbol_analysis(clean, stored),
                    self._detail_buttons(stored[0]),
                )
                return
            await self.telegram.send_message(
                chat_id,
                "❌ <b>تعذر تحليل الرمز الآن.</b>\n\n"
                + f"السبب: {html.escape(str(exc))}",
                self._main_menu(),
            )
            return
        await self.telegram.send_message(
            chat_id,
            format_analysis_v39(result),
            self._analysis_buttons(result.display_symbol),
        )

    async def _send_frame_scan(
        self,
        chat_id: int,
        market: str,
        frame_key: str,
        direction: int = 0,
        min_score: int = 60,
    ) -> None:
        await self.telegram.send_message(
            chat_id,
            f"⏳ مسح <b>{html.escape(market)}</b> على فاصل <b>{html.escape(frame_label(frame_key))}</b>؛ لن تظهر نتيجة بلا دخول ووقف وأهداف سليمة...",
        )
        try:
            report = await self.live.scan_frame_detailed(
                market, frame_key, direction, min_score, limit=10
            )
        except MarketDataError as exc:
            await self.telegram.send_message(
                chat_id,
                "❌ تعذر تنفيذ المسح: " + html.escape(str(exc)),
                self._main_menu(),
            )
            return
        await self.telegram.send_message(
            chat_id,
            format_scan_v39(report),
            build_frame_scan_buttons_v38(
                list(report.items),
                market,
                frame_key,
                direction,
                min_score,
            ),
        )

    async def _send_preset(
        self,
        chat_id: int,
        market: str,
        preset_id: str,
        frame_code: str,
    ) -> None:
        preset = PRESET_BY_ID.get(preset_id)
        if preset is None:
            await self.telegram.send_message(
                chat_id, "❌ الفلتر غير معروف.", self._main_menu()
            )
            return
        try:
            frame_name = frame_code_label(frame_code)
        except KeyError:
            await self.telegram.send_message(
                chat_id, "❌ فاصل الفلتر غير صالح.", self._main_menu()
            )
            return
        await self.telegram.send_message(
            chat_id,
            f"⏳ تطبيق فلتر <b>{html.escape(preset.title)}</b> على <b>{html.escape(frame_name)}</b>...",
        )
        try:
            report = await self.scanner.scan_preset(
                market, preset_id, frame_code, limit=10
            )
        except MarketDataError as exc:
            await self.telegram.send_message(
                chat_id,
                "❌ تعذر تنفيذ الفلتر الآن: "
                + html.escape(str(exc)),
                self._filter_categories_menu(market),
            )
            return
        await self.telegram.send_message(
            chat_id,
            self._format_preset_report(report, frame_code),
            self._preset_result_buttons(report, frame_code),
        )

    async def _handle_text(self, chat_id: int, text: str) -> None:
        command = text.partition(" ")[0].split("@", 1)[0].lower()
        if command in {"/start", "/help"}:
            await self.telegram.send_message(
                chat_id, FOCUSED_HELP_TEXT_V39, self._main_menu()
            )
            return
        if command == "/sources":
            await self.telegram.send_message(
                chat_id,
                sources_text().replace("V3.7", "V3.9"),
                self._main_menu(),
            )
            return
        await super()._handle_text(chat_id, text)

    async def _handle_callback(
        self, callback: dict[str, Any]
    ) -> None:
        callback_id = str(callback["id"])
        message = callback.get("message") or {}
        chat_id = int(message.get("chat", {}).get("id", 0))
        user_id = int(callback.get("from", {}).get("id", 0))
        data = str(callback.get("data", ""))

        if data in {"menu:home", "menu:help"}:
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(
                    callback_id, "غير مصرح"
                )
                return
            await self.telegram.answer_callback(
                callback_id, "القائمة الرئيسية"
            )
            await self.telegram.send_message(
                chat_id, FOCUSED_HELP_TEXT_V39, self._main_menu()
            )
            return

        if data.startswith("fpf:"):
            if not await self._is_authorized(user_id, chat_id):
                await self.telegram.answer_callback(
                    callback_id, "غير مصرح"
                )
                return
            parts = data.split(":")
            if (
                len(parts) != 3
                or parts[2] not in PRESET_BY_ID
            ):
                await self.telegram.answer_callback(
                    callback_id, "فلتر غير صالح"
                )
                return
            market, preset_id = parts[1], parts[2]
            await self.telegram.answer_callback(
                callback_id, "اختر الفاصل"
            )
            await self.telegram.send_message(
                chat_id,
                f"<b>{html.escape(PRESET_BY_ID[preset_id].title)}</b>\nاختر الفاصل المراد فحصه:",
                self._preset_frame_menu(market, preset_id),
            )
            return

        await super()._handle_callback(callback)


FOCUSED_HELP_TEXT = FOCUSED_HELP_TEXT_V39
AuditedMarketAnalyzer = VerifiedSchoolConsensusAnalyzer
