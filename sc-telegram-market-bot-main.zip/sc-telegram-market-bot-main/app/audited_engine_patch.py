from __future__ import annotations

from dataclasses import replace
from typing import Any

from .audited_engine import AuditedMarketAnalyzer as BaseAuditedMarketAnalyzer
from .technical import FrameAnalysis, LiveAnalysis


class AuditedMarketAnalyzer(BaseAuditedMarketAnalyzer):
    @staticmethod
    def _build_audited(
        symbol: str,
        frames: list[FrameAnalysis],
        metadata: dict[str, Any],
        feed_sources: list[str],
    ) -> LiveAnalysis:
        result = BaseAuditedMarketAnalyzer._build_audited(
            symbol, frames, metadata, feed_sources
        )
        if "تعارض قوي" not in result.alignment:
            return result
        blocked = tuple(
            replace(
                frame,
                plan_state="مراقبة — تعارض قوي بين اليومي والساعة",
                entry=None,
                stop=None,
                targets=(),
                risk_reward=None,
                warnings=tuple(
                    dict.fromkeys((*frame.warnings, "مُنعت الخطة بسبب تعارض الفواصل"))
                ),
            )
            for frame in result.frames
        )
        return replace(result, frames=blocked)
