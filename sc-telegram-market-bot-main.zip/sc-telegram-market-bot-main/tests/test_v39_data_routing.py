from __future__ import annotations

import asyncio
from typing import Any

from app.analyzer_v39 import ProductionVerifiedAnalyzer
from app.data_sources import ProviderResult
from app.data_sources_v39 import V39DirectProvider, _period_days
from app.technical import Candle, normalize_symbol


class _FakeProvider:
    def __init__(self, provider_id: str) -> None:
        self.provider_id = provider_id
        self.calls: list[tuple[str, str]] = []

    async def fetch(self, spec, period: str, interval: str):
        self.calls.append((period, interval))
        return ProviderResult(
            candles=[Candle(1, 1, 1, 1, 1, 1)],
            metadata={},
            provider_id=self.provider_id,
        )


def test_period_parser_preserves_requested_history() -> None:
    assert _period_days("10y") == 3650
    assert _period_days("2y") == 730
    assert _period_days("60d") == 60
    assert _period_days("6mo") == 186


def test_short_crypto_frames_use_binance_first() -> None:
    async def scenario() -> None:
        provider = V39DirectProvider(timeout=1)
        binance = _FakeProvider("binance")
        yahoo = _FakeProvider("yahoo")
        provider.binance = binance  # type: ignore[assignment]
        provider.yahoo = yahoo  # type: ignore[assignment]
        spec = normalize_symbol("BTCUSD")

        result = await provider.fetch(spec, "7d", "1m")
        assert result.provider_id == "binance"
        assert binance.calls == [("7d", "1m")]
        assert yahoo.calls == []

        result = await provider.fetch(spec, "10y", "1d")
        assert result.provider_id == "yahoo"
        assert yahoo.calls == [("10y", "1d")]

    asyncio.run(scenario())


def test_production_analyzer_uses_v39_sources() -> None:
    analyzer = ProductionVerifiedAnalyzer(timeout=1)
    assert analyzer.providers[0].__class__.__name__ == "V39MultiSourceProvider"
    assert analyzer._v38_yahoo.__class__.__name__ == "V39DirectProvider"
