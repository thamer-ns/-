from __future__ import annotations

from app.opportunity_v37 import _lookback_bars


def test_hourly_memory_covers_at_least_two_trading_weeks() -> None:
    # Around six closed hourly bars per regular session × ten sessions.
    assert _lookback_bars("ساعة") >= 60


def test_memory_windows_scale_with_the_timeframe() -> None:
    assert _lookback_bars("15 دقيقة") >= _lookback_bars("ساعة")
    assert _lookback_bars("يومي") >= 30
