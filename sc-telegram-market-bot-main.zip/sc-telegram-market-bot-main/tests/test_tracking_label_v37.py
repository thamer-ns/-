from __future__ import annotations

from datetime import datetime, timezone

from app.market_safety_v37 import clarify_tracking_state
from app.technical import FrameAnalysis, LiveAnalysis


def test_progressed_plan_is_labeled_for_tracking_not_fresh_entry() -> None:
    frame = FrameAnalysis(
        frame="ساعة",
        price=105,
        trend="صاعد",
        structure="قمم وقيعان صاعدة",
        event="كسر مقاومة مؤكد",
        score=70,
        confidence=72,
        evidence_long=72,
        evidence_short=20,
        rsi=60,
        ema20=102,
        ema50=99,
        ema200=95,
        macd_hist=0.7,
        atr=1.2,
        atr_percent=1.1,
        volume_ratio=1.4,
        volume_trusted=True,
        support=100,
        resistance=108,
        direction=1,
        plan_state="فرصة قائمة — تحقق الهدف 1 من 3",
        entry=102,
        stop=99,
        targets=(105, 107, 109),
        risk_reward=1.0,
        reasons=("تقدم الخطة: 1/3",),
        warnings=(),
        updated_at=datetime.now(timezone.utc),
    )
    item = LiveAnalysis(
        query="2222",
        yahoo_symbol="2222.SR",
        display_symbol="2222",
        name="Company",
        exchange="Saudi",
        currency="SAR",
        asset_class="stock",
        price=105,
        score=70,
        confidence=72,
        recommendation="إيجابي",
        direction=1,
        alignment="قراءة فاصل واحد: ساعة",
        feed_source="test",
        frames=(frame,),
        updated_at=frame.updated_at,
    )

    clarified = clarify_tracking_state(item)
    updated = clarified.frames[0]
    assert updated.plan_state.startswith("فرصة قائمة للمتابعة")
    assert updated.entry == frame.entry
    assert updated.stop == frame.stop
    assert updated.targets == frame.targets
