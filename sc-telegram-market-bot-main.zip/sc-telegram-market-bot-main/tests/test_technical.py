from __future__ import annotations

from app.technical import Candle, analyze_frame, normalize_symbol


def candles(direction: int, count: int = 260) -> list[Candle]:
    result: list[Candle] = []
    price = 100.0
    for index in range(count):
        drift = 0.22 * direction
        wave = ((index % 7) - 3) * 0.03
        open_price = price
        close = max(1.0, price + drift + wave)
        high = max(open_price, close) + 0.45
        low = min(open_price, close) - 0.45
        result.append(Candle(1_700_000_000 + index * 86400, open_price, high, low, close, 1_000_000 + index * 1000))
        price = close
    return result


def test_symbol_normalization() -> None:
    assert normalize_symbol("1120").yahoo_symbol == "1120.SR"
    assert normalize_symbol("EURUSD").yahoo_symbol == "EURUSD=X"
    assert normalize_symbol("BTCUSD").yahoo_symbol == "BTC-USD"


def test_uptrend_analysis_has_no_wrong_side_stop() -> None:
    result = analyze_frame(candles(1), "يومي", "stock")
    if result.entry is not None:
        assert result.stop is not None
        assert result.stop < result.entry
        assert all(target > result.entry for target in result.targets)


def test_downtrend_analysis_has_no_wrong_side_stop() -> None:
    result = analyze_frame(candles(-1), "يومي", "stock")
    if result.entry is not None:
        assert result.stop is not None
        assert result.stop > result.entry
        assert all(target < result.entry for target in result.targets)


def test_forex_volume_is_not_trusted() -> None:
    result = analyze_frame(candles(1), "ساعة", "forex")
    assert result.volume_trusted is False
    assert result.volume_ratio is None


def test_neutral_market_does_not_force_plan() -> None:
    data = candles(1, 100)
    flat: list[Candle] = []
    for index, item in enumerate(data):
        base = 100 + ((index % 10) - 5) * 0.05
        flat.append(Candle(item.timestamp, base, base + 0.3, base - 0.3, base + (0.02 if index % 2 else -0.02), item.volume))
    result = analyze_frame(flat, "ساعة", "stock")
    if result.direction == 0:
        assert result.entry is None
        assert result.stop is None
