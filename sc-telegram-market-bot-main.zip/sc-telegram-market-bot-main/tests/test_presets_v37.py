from __future__ import annotations

from datetime import datetime, timezone

from app.presets_v37 import build_signal_snapshot_v37
from app.technical import Candle, FrameAnalysis


def _frame(plan_state: str) -> FrameAnalysis:
    return FrameAnalysis(
        frame="يومي",
        price=100,
        trend="صاعد",
        structure="قمم وقيعان صاعدة",
        event="تجهيز لاختراق المقاومة",
        score=68,
        confidence=68,
        evidence_long=68,
        evidence_short=20,
        rsi=58,
        ema20=99,
        ema50=97,
        ema200=94,
        macd_hist=0.5,
        atr=2,
        atr_percent=2,
        volume_ratio=1.2,
        volume_trusted=True,
        support=95,
        resistance=101,
        direction=1,
        plan_state=plan_state,
        entry=101.2,
        stop=97,
        targets=(105.4, 108.5, 111.7),
        risk_reward=1,
        reasons=(),
        warnings=(),
        updated_at=datetime.now(timezone.utc),
    )


def _candles() -> list[Candle]:
    candles: list[Candle] = []
    for index in range(80):
        price = 90 + index * 0.12
        candles.append(
            Candle(
                index + 1,
                price,
                price + 0.5,
                price - 0.5,
                price + 0.1,
                1_000_000 + index * 1000,
            )
        )
    return candles


def test_conditional_numeric_plan_is_not_a_confirmed_plan() -> None:
    snapshot = build_signal_snapshot_v37(
        _candles(),
        _frame("فرصة مشروطة — انتظار إغلاق يومي فوق 101.2"),
    )
    assert "confirmed_plan" not in snapshot.tags


def test_triggered_plan_remains_confirmed() -> None:
    snapshot = build_signal_snapshot_v37(
        _candles(),
        _frame("دخول قائم — الزناد تحقق"),
    )
    assert "confirmed_plan" in snapshot.tags
