from __future__ import annotations

import math
from dataclasses import replace
from datetime import datetime, timezone

from app.market_data import ScanReport
from app.opportunity_format import format_analysis_v37, format_scan_v37
from app.opportunity_v37 import (
    OpportunityMarketAnalyzer,
    _build_plan,
    _evaluate_progress,
    enrich_frame_opportunity,
    opportunity_state_rank,
)
from app.technical import Candle, FrameAnalysis


def _frame(
    *,
    name: str = "ساعة",
    price: float = 100.0,
    direction: int = 1,
    confidence: int = 68,
    entry: float | None = None,
    stop: float | None = None,
    targets: tuple[float, ...] = (),
    plan_state: str = "مراقبة — الاتجاه قائم لكن زناد الدخول غير مؤكد",
) -> FrameAnalysis:
    return FrameAnalysis(
        frame=name,
        price=price,
        trend=(
            "صاعد"
            if direction > 0
            else "هابط"
            if direction < 0
            else "محايد/انتقالي"
        ),
        structure=(
            "قمم وقيعان صاعدة"
            if direction > 0
            else "قمم وقيعان هابطة"
        ),
        event="لا يوجد زناد مؤكد",
        score=68 if direction > 0 else 32,
        confidence=confidence,
        evidence_long=confidence if direction > 0 else 20,
        evidence_short=confidence if direction < 0 else 20,
        rsi=58.0,
        ema20=99.0,
        ema50=97.0,
        ema200=94.0,
        macd_hist=0.5 if direction > 0 else -0.5,
        atr=1.2,
        atr_percent=1.2,
        volume_ratio=1.3,
        volume_trusted=True,
        support=97.5,
        resistance=102.0,
        direction=direction,
        plan_state=plan_state,
        entry=entry,
        stop=stop,
        targets=targets,
        risk_reward=1.0 if entry is not None else None,
        reasons=("بنية داو صاعدة", "EMA20 أعلى EMA50"),
        warnings=(),
        updated_at=datetime.now(timezone.utc),
    )


def _range_candles(count: int = 90) -> list[Candle]:
    start = int(
        datetime(2026, 1, 1, tzinfo=timezone.utc).timestamp()
    )
    candles: list[Candle] = []
    for index in range(count):
        close = 99.5 + math.sin(index / 2.0) * 0.35
        candles.append(
            Candle(
                start + index * 3600,
                close - 0.1,
                100.2,
                98.8,
                close,
                1_000_000 + index * 1000,
            )
        )
    return candles


def test_directional_frame_gets_numeric_conditional_plan_before_breakout() -> None:
    candles = _range_candles()
    frame = _frame(price=candles[-1].close)
    enriched = enrich_frame_opportunity(candles, frame)
    assert "فرصة مشروطة" in enriched.plan_state
    assert enriched.entry is not None
    assert enriched.entry > frame.resistance
    assert enriched.stop is not None
    assert enriched.stop < enriched.entry
    assert len(enriched.targets) == 3


def test_recent_breakout_remains_visible_after_later_closed_bars() -> None:
    candles = _range_candles(80)
    base_time = candles[-1].timestamp
    candles.extend(
        [
            Candle(
                base_time + 3600,
                99.8,
                102.8,
                99.7,
                102.4,
                2_000_000,
            ),
            Candle(
                base_time + 7200,
                101.4,
                101.8,
                100.9,
                101.5,
                1_600_000,
            ),
            Candle(
                base_time + 10_800,
                101.5,
                101.9,
                101.0,
                101.6,
                1_400_000,
            ),
        ]
    )
    frame = _frame(price=candles[-1].close, confidence=75)
    enriched = enrich_frame_opportunity(candles, frame)
    assert any(
        marker in enriched.plan_state
        for marker in (
            "دخول قائم",
            "فرصة قائمة",
            "إعادة اختبار",
            "الخطة قائمة",
        )
    )
    assert enriched.entry is not None
    assert any("زناد الخطة" in reason for reason in enriched.reasons)


def test_progress_starts_after_close_confirmed_trigger_candle() -> None:
    candles = [
        Candle(1, 99, 110, 90, 101, 1000),
        Candle(2, 101, 102.2, 100.2, 101.8, 1000),
        Candle(3, 101.8, 103.2, 101.0, 102.8, 1000),
    ]
    state, reached = _evaluate_progress(
        candles, 0, 1, 98.0, (102.0, 103.0, 104.0)
    )
    assert state == "ACTIVE"
    assert reached == 2


def test_plan_does_not_change_when_future_candles_are_appended() -> None:
    at_event = _range_candles(80)
    at_event.append(
        Candle(
            at_event[-1].timestamp + 3600,
            99.8,
            102.8,
            99.7,
            102.4,
            2_000_000,
        )
    )
    first = _build_plan(
        candles=at_event,
        frame_name="ساعة",
        direction=1,
        event_level=100.2,
    )
    future = [
        *at_event,
        Candle(
            at_event[-1].timestamp + 7200,
            102.4,
            150.0,
            101.0,
            140.0,
            3_000_000,
        ),
    ]
    second = _build_plan(
        candles=future[: len(at_event)],
        frame_name="ساعة",
        direction=1,
        event_level=100.2,
    )
    assert first == second


def test_strong_conflict_preserves_frame_specific_plans() -> None:
    daily = _frame(
        name="يومي",
        direction=1,
        confidence=75,
        entry=101,
        stop=96,
        targets=(106, 110, 114),
        plan_state="فرصة مشروطة — انتظار إغلاق يومي فوق 101",
    )
    hourly = _frame(
        name="ساعة",
        direction=-1,
        confidence=72,
        entry=99,
        stop=103,
        targets=(95, 92, 89),
        plan_state=(
            "دخول قائم — الزناد تحقق والسعر ضمن نطاق غير ممتد"
        ),
    )
    result = OpportunityMarketAnalyzer._build_audited(
        "AAPL",
        [daily, hourly],
        {"longName": "Apple", "currency": "USD"},
        ["yahoo", "yahoo"],
    )
    assert result.direction == 0
    assert "تعارض" in result.alignment
    assert all(frame.entry is not None for frame in result.frames)
    assert any(
        "منفصلة" in frame.plan_state
        or any("منفصلة" in warning for warning in frame.warnings)
        for frame in result.frames
    )


def test_new_format_starts_with_plan_and_stays_within_telegram_limit() -> None:
    from app.technical import LiveAnalysis

    frame = _frame(
        entry=102,
        stop=99,
        targets=(105, 107.25, 109.5),
        plan_state="فرصة قائمة — تحقق الهدف 1 من 3",
    )
    frame = replace(
        frame,
        reasons=(*frame.reasons, "تقدم الخطة: 1/3"),
    )
    item = LiveAnalysis(
        query="2222",
        yahoo_symbol="2222.SR",
        display_symbol="2222",
        name="Saudi Arabian Oil Company",
        exchange="Saudi",
        currency="SAR",
        asset_class="stock",
        price=105.5,
        score=70,
        confidence=72,
        recommendation="إيجابي — خطة قائمة",
        direction=1,
        alignment="توافق كامل للفواصل",
        feed_source="yahoo",
        frames=(frame,),
        updated_at=frame.updated_at,
    )
    text = format_analysis_v37(item)
    assert "الخلاصة التنفيذية" in text
    assert "خطة الصفقة" in text
    assert "المدة التقديرية" in text
    assert "الهدف 1" in text
    assert len(text) <= 4096


def test_scan_prioritizes_active_plan_over_conditional() -> None:
    from app.technical import LiveAnalysis

    active = _frame(
        entry=100,
        stop=97,
        targets=(103, 105, 107),
        plan_state="دخول قائم — الزناد تحقق",
    )
    conditional = _frame(
        entry=101,
        stop=98,
        targets=(104, 106, 108),
        plan_state=(
            "فرصة مشروطة — انتظار إغلاق ساعة فوق 101"
        ),
    )
    assert opportunity_state_rank(active) > opportunity_state_rank(
        conditional
    )

    def item(symbol: str, frame: FrameAnalysis) -> LiveAnalysis:
        return LiveAnalysis(
            query=symbol,
            yahoo_symbol=symbol,
            display_symbol=symbol,
            name=symbol,
            exchange="X",
            currency="SAR",
            asset_class="stock",
            price=frame.price,
            score=frame.score,
            confidence=frame.confidence,
            recommendation="إيجابي",
            direction=frame.direction,
            alignment="قراءة فاصل واحد",
            feed_source="test",
            frames=(frame,),
            updated_at=frame.updated_at,
        )

    report = ScanReport(
        "SAUDI",
        "INTRADAY",
        "test",
        2,
        2,
        0,
        1,
        (item("B", conditional), item("A", active)),
    )
    text = format_scan_v37(report)
    assert text.index("A") < text.index("B")
    assert len(text) <= 4096
