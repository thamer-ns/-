from __future__ import annotations

from datetime import datetime as RealDateTime, timezone

import app.data_sources as data_sources
from app.data_sources import (
    SOURCE_CATALOG,
    YahooChartProvider,
    _WebullProvider,
    _finite_candle,
    _parse_timestamp,
    reference_links,
)
from app.technical import normalize_symbol
from app.universes import US_FOCUS_UNIVERSE, US_OPTIONS_PRIORITY, _cboe_symbol


EXPECTED_US_SYMBOLS = {
    "AAPL", "ABBV", "AMAT", "AMD", "AMZN", "ANET", "AVGO", "AXP", "BRK-B",
    "C", "CAT", "COST", "CSCO", "CVX", "DELL", "GE", "GEV", "GOOG", "GOOGL",
    "GS", "HD", "INTC", "JNJ", "JPM", "KLAC", "KO", "LLY", "LRCX", "MA",
    "META", "MRK", "MS", "MSFT", "MU", "NVDA", "ORCL", "PANW", "PG", "PLTR",
    "PM", "RTX", "SNDK", "SPCX", "TMUS", "TSLA", "TXN", "UNH", "V", "WFC",
    "WMT", "XOM",
}


def test_us_scan_is_exactly_the_attached_51_symbols() -> None:
    assert len(US_FOCUS_UNIVERSE) == 51
    assert set(US_FOCUS_UNIVERSE) == EXPECTED_US_SYMBOLS
    assert US_OPTIONS_PRIORITY == US_FOCUS_UNIVERSE
    assert not {"SPY", "QQQ", "IWM", "NFLX", "COIN"} & set(US_FOCUS_UNIVERSE)


def test_cboe_normalizes_class_share_symbols() -> None:
    assert _cboe_symbol("BRK-B") == "BRK.B"
    assert _cboe_symbol("BRK/B") == "BRK.B"


def test_catalog_contains_requested_sources() -> None:
    ids = {item.source_id for item in SOURCE_CATALOG}
    assert {"binance", "webull", "barchart", "yahoo", "finviz"} <= ids


def test_optional_providers_are_not_constructed_without_keys(monkeypatch) -> None:
    monkeypatch.delenv("WEBULL_APP_KEY", raising=False)
    monkeypatch.delenv("WEBULL_APP_SECRET", raising=False)
    monkeypatch.delenv("BARCHART_API_KEY", raising=False)
    provider = YahooChartProvider(timeout=1)
    assert provider.webull is None
    assert provider.barchart is None
    assert provider.binance.provider_id == "binance"
    assert provider.yahoo.provider_id == "yahoo"


def test_reference_links_follow_asset_type() -> None:
    us_names = {name for name, _ in reference_links(normalize_symbol("AAPL"))}
    crypto_names = {name for name, _ in reference_links(normalize_symbol("BTCUSD"))}
    assert {"Yahoo", "Finviz", "Barchart", "Webull"} == us_names
    assert "Binance" in crypto_names
    assert "Barchart" not in crypto_names


def test_timestamp_and_candle_validation() -> None:
    assert _parse_timestamp("2026-07-22T10:00:00Z") > 0
    assert _parse_timestamp(1_700_000_000_000) == 1_700_000_000
    assert _finite_candle(1, 1, 2, 0.5, 1.5, 100) is not None
    assert _finite_candle(1, 1, 2, 0.5, float("nan"), 100) is None


def test_webull_signature_is_stable(monkeypatch) -> None:
    class FixedDateTime:
        @classmethod
        def now(cls, tz=None):
            return RealDateTime(2022, 1, 4, 3, 55, 31, tzinfo=timezone.utc)

    class FixedUuid:
        hex = "48ef5afed43d4d91ae514aaeafbc29ba"

    monkeypatch.setattr(data_sources, "datetime", FixedDateTime)
    monkeypatch.setattr(data_sources.uuid, "uuid4", lambda: FixedUuid())
    monkeypatch.setenv("WEBULL_API_HOST", "api.webull.com")
    provider = _WebullProvider(
        "776da210ab4a452795d74e726ebd74b6",
        "0f50a2e853334a9aae1a783bee120c1f",
        timeout=1,
    )
    params = {
        "symbol": "AAPL",
        "category": "US_STOCK",
        "count": "1200",
        "real_time_required": "false",
        "timespan": "D",
    }
    headers = provider._headers("/openapi/market-data/stock/bars", params)
    assert headers["x-signature"] == "Un3zrCICLcmexsPxLCKnmBO4+oY="
