from __future__ import annotations

from app.focused_bot import FOCUSED_HELP_TEXT, LiveBotService
from app.presets import CATEGORIES


def _callbacks(markup: dict) -> list[str]:
    return [
        str(button["callback_data"])
        for row in markup.get("inline_keyboard", [])
        for button in row
        if "callback_data" in button
    ]


def test_static_messages_fit_telegram_limit() -> None:
    messages = [
        FOCUSED_HELP_TEXT,
        LiveBotService._us_list_text(),
        LiveBotService._sources_text(),
        LiveBotService._provider_status_text(),
    ]
    assert all(len(message) <= 4096 for message in messages)


def test_all_main_and_filter_callbacks_fit_telegram_limit() -> None:
    markups = [LiveBotService._main_menu(), LiveBotService._filter_market_menu()]
    for market in ("SAUDI", "US", "FOREX", "CRYPTO"):
        markups.extend(
            [
                LiveBotService._horizon_menu(market),
                LiveBotService._filter_categories_menu(market),
                LiveBotService._quick_filters_menu(market),
            ]
        )
        markups.extend(
            LiveBotService._preset_menu(market, category.category_id)
            for category in CATEGORIES
        )
    callbacks = [value for markup in markups for value in _callbacks(markup)]
    assert callbacks
    assert all(1 <= len(value.encode("utf-8")) <= 64 for value in callbacks)
