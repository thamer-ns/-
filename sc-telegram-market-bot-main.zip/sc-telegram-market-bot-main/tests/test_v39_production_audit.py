from __future__ import annotations

import asyncio
from dataclasses import fields
from datetime import datetime, timezone
from typing import Any

import pytest

import app.presets_v39 as presets_v39
import app.school_engine_v39 as engine_v39
from app.focused_bot_v39 import LiveBotService as V39BotService
from app.focused_bot_v39_final import _COMMANDS
from app.market_data import ScanReport
from app.presets import SignalSnapshot
from app.presets_v39 import FRAME_CODE_TO_KEY
from app.school_engine_v38 import (
    SchoolConsensus,
    SchoolFrameAnalysis,
    SchoolSignal,
)
from app.school_engine_v39 import (
    VerifiedSchoolConsensusAnalyzer,
    VerifiedSchoolFrameAnalysis,
    _valid_plan_geometry,
    finalize_school_frame,
    is_executable_opportunity,
)
from app.school_format_v39 import (
    format_analysis_v39,
    format_scan_v39,
    select_primary_frame_v39,
)
from app.technical import Candle, FrameAnalysis, LiveAnalysis


_SCHOOL_FIELDS = {
    "school_count",
    "school_names",
    "school_details",
    "signal_type",
    "consensus_strength",
    "strong_single_school",
}


def _base_school_frame(**changes: Any) -> SchoolFrameAnalysis:
    school_changes = {
        key: changes.pop(key)
        for key in tuple(changes)
        if key in _SCHOOL_FIELDS
    }
    base = FrameAnalysis(
        frame="ساعة",
        price=103.0,
        trend="صاعد",
        structure="قمم وقيعان صاعدة",
        event="اختراق",
        score=75,
        confidence=80,
        evidence_long=80,
        evidence_short=20,
        rsi=60.0,
        ema20=101.0,
        ema50=99.0,
        ema200=95.0,
        macd_hist=0.5,
        atr=1.0,
        atr_percent=1.0,
        volume_ratio=1.5,
        volume_trusted=True,
        support=101.0,
        resistance=102.0,
        direction=1,
        plan_state="دخول قائم — الزناد تحقق",
        entry=103.0,
        stop=101.5,
        targets=(104.5, 105.7, 106.9),
        risk_reward=1.0,
        reasons=("تقدم الخطة: 0/3",),
        warnings=(),
        updated_at=datetime.now(timezone.utc),
    )
    values = {
        item.name: getattr(base, item.name)
        for item in fields(FrameAnalysis)
    }
    values.update(changes)
    school_values: dict[str, Any] = {
        "school_count": 2,
        "school_names": (
            "الدعم والمقاومة",
            "داو والبنية السعرية",
        ),
        "school_details": (
            "الدعم والمقاومة (90%): اختراق",
            "داو والبنية السعرية (84%): BOS",
        ),
        "signal_type": "اختراق",
        "consensus_strength": 90,
        "strong_single_school": False,
    }
    school_values.update(school_changes)
    return SchoolFrameAnalysis(**values, **school_values)


def _verified(
    *,
    qualified: bool = True,
    plan_valid: bool = True,
    **changes: Any,
) -> VerifiedSchoolFrameAnalysis:
    frame = _base_school_frame(**changes)
    values = {
        item.name: getattr(frame, item.name)
        for item in fields(SchoolFrameAnalysis)
    }
    return VerifiedSchoolFrameAnalysis(
        **values,
        consensus_qualified=qualified,
        plan_valid=plan_valid,
        opposing_school_names=(),
    )


def _candles() -> list[Candle]:
    return [
        Candle(
            index + 1,
            (close := 100 + index * 0.04) - 0.1,
            close + 0.5,
            close - 0.5,
            close,
            1000,
        )
        for index in range(80)
    ]


def _analysis(frame: FrameAnalysis) -> LiveAnalysis:
    return LiveAnalysis(
        query="TEST",
        yahoo_symbol="TEST",
        display_symbol="TEST",
        name="شركة اختبار طويلة " * 10,
        exchange="TEST",
        currency="SAR",
        asset_class="stock",
        price=frame.price,
        score=frame.score,
        confidence=frame.confidence,
        recommendation="اختبار",
        direction=frame.direction,
        alignment="توافق الفواصل",
        feed_source="test",
        frames=(frame,),
        updated_at=frame.updated_at,
    )


def test_plan_geometry_accepts_only_ordered_long_and_short() -> None:
    assert _valid_plan_geometry(_base_school_frame()) is True
    assert _valid_plan_geometry(
        _base_school_frame(
            direction=-1,
            trend="هابط",
            entry=100.0,
            stop=102.0,
            targets=(98.0, 96.4, 94.8),
        )
    ) is True
    assert _valid_plan_geometry(
        _base_school_frame(stop=104.0)
    ) is False
    assert _valid_plan_geometry(
        _base_school_frame(targets=(104.0, 103.5, 106.0))
    ) is False


def test_unqualified_consensus_cannot_keep_old_plan(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    consensus = SchoolConsensus(
        direction=0,
        qualified=False,
        strength=62,
        signal_type="محايد",
        signals=(
            SchoolSignal(
                "اتباع الاتجاه والمتوسطات",
                1,
                72,
                "استمرار اتجاه",
                "سياق صاعد",
                False,
            ),
        ),
        opposing=(
            SchoolSignal(
                "وايكوف المبسط (عرض وطلب)",
                -1,
                88,
                "انعكاس",
                "Upthrust",
                True,
            ),
        ),
        strong_single=False,
    )
    monkeypatch.setattr(
        engine_v39,
        "evaluate_school_consensus_final",
        lambda *args: consensus,
    )
    monkeypatch.setattr(
        engine_v39,
        "apply_school_consensus_final",
        lambda *args: _base_school_frame(),
    )
    result = finalize_school_frame(
        _candles(), _base_school_frame(), "stock"
    )
    assert result.consensus_qualified is False
    assert result.plan_valid is False
    assert result.direction == 0
    assert result.entry is None and result.stop is None
    assert result.targets == ()
    assert "مراقبة" in result.plan_state


def test_scan_rejects_unqualified_or_invalid_plans(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    valid = _analysis(_verified())
    unqualified = _analysis(
        _verified(
            qualified=False,
            plan_valid=False,
            direction=0,
            entry=None,
            stop=None,
            targets=(),
        )
    )
    invalid = _analysis(
        _verified(
            plan_valid=False,
            entry=None,
            stop=None,
            targets=(),
        )
    )
    analyzer = VerifiedSchoolConsensusAnalyzer()

    async def fake_scan(*args: Any, **kwargs: Any):
        return (valid, unqualified, invalid), 3, 3

    monkeypatch.setattr(analyzer, "_scan_all", fake_scan)
    report = asyncio.run(
        analyzer.scan_frame_detailed(
            "US", "1h", 0, 60, limit=10
        )
    )
    assert len(report.items) == 1
    assert is_executable_opportunity(report.items[0].frames[0])


def test_primary_frame_prefers_verified_opportunity() -> None:
    rejected = _verified(
        qualified=False,
        plan_valid=False,
        frame="شهري",
        direction=0,
        confidence=96,
        entry=None,
        stop=None,
        targets=(),
    )
    executable = _verified(
        frame="15 دقيقة",
        confidence=70,
    )
    base = _analysis(executable)
    values = {
        item.name: getattr(base, item.name)
        for item in fields(LiveAnalysis)
    }
    values["frames"] = (rejected, executable)
    assert select_primary_frame_v39(
        LiveAnalysis(**values)
    ) is executable


def test_preset_frames_cover_minute_to_month() -> None:
    assert set(FRAME_CODE_TO_KEY.values()) == {
        "1m", "5m", "15m", "30m", "1h",
        "4h", "1d", "1w", "1mo",
    }
    menu = V39BotService._preset_frame_menu("US", "pathup")
    callbacks = [
        button["callback_data"]
        for row in menu["inline_keyboard"]
        for button in row
        if "callback_data" in button
    ]
    for code in FRAME_CODE_TO_KEY:
        assert f"fp:US:pathup:{code}" in callbacks
    assert all(
        len(value.encode("utf-8")) <= 64
        for value in callbacks
    )


def test_breakout_snapshot_replaces_legacy_level_tags(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(
        presets_v39,
        "build_signal_snapshot_v37",
        lambda *args: SignalSnapshot(
            frozenset({"break_up", "above20"}),
            (("break_up", "قديم"), ("above20", "فوق المتوسط")),
            None,
            0,
        ),
    )
    monkeypatch.setattr(
        presets_v39,
        "_reference_levels",
        lambda *args: (99.0, 104.0, [99.0, 104.0]),
    )
    monkeypatch.setattr(
        presets_v39,
        "_setup_event_audited",
        lambda *args: (-1, "إعادة اختبار هابطة مؤكدة", 99.0),
    )
    snapshot = presets_v39.build_signal_snapshot_v39(
        _candles(), _base_school_frame()
    )
    assert "break_up" not in snapshot.tags
    assert "retest_down" in snapshot.tags
    assert "above20" in snapshot.tags


def test_telegram_commands_and_messages_are_safe() -> None:
    commands = {command for command, _ in _COMMANDS}
    assert {
        "start", "analyze", "scan", "filters",
        "recommendations", "options", "calls", "puts",
        "saudi", "us", "forex", "crypto", "active",
        "sources", "status",
    }.issubset(commands)

    long_details = tuple(
        f"مدرسة {index} (90%): " + "سبب فني طويل " * 30
        for index in range(9)
    )
    frame = _verified(school_details=long_details)
    analysis_text = format_analysis_v39(_analysis(frame))
    assert len(analysis_text) <= 4096
    assert analysis_text.count("<b>") == analysis_text.count("</b>")
    assert analysis_text.count("<i>") == analysis_text.count("</i>")

    report = ScanReport(
        market="US",
        horizon="1h",
        universe_label="السوق الأمريكي",
        total_symbols=51,
        analyzed_symbols=51,
        failed_symbols=0,
        direction=0,
        items=tuple(_analysis(frame) for _ in range(10)),
    )
    scan_text = format_scan_v39(report)
    assert len(scan_text) <= 4096
    assert scan_text.count("<b>") == scan_text.count("</b>")
    assert scan_text.count("<i>") == scan_text.count("</i>")


def test_health_contract_is_v40() -> None:
    from app.main import VERSION, _analysis_contract

    contract = _analysis_contract()
    assert VERSION == "4.1.1"
    assert contract["explicit_consensus_qualification"] is True
    assert contract["scan_requires_valid_plan_geometry"] is True
    assert contract["all_frame_presets"] is True
    assert contract["beginner_friendly_presentation"] is True
    assert contract["paginated_multi_frame_analysis"] is True
    assert contract["full_plan_in_scan_results"] is True


def test_v41_health_contract_and_feed_status_are_transparent() -> None:
    from app.main import VERSION, _analysis_contract, _feed_status

    contract = _analysis_contract()
    feeds = _feed_status()
    assert VERSION == "4.1.1"
    assert contract["timeframe_adaptive_risk"] is True
    assert contract["market_tick_aware_levels"] is True
    assert contract["empirical_first_passage_duration"] is True
    assert contract["durable_telegram_inbox"] is True
    assert feeds["status_basis"] == "configuration_only_not_live_probe"


def test_invalid_numeric_environment_has_clear_error(monkeypatch) -> None:
    from app.config import Settings

    monkeypatch.setenv("DEFAULT_MIN_SCORE", "not-a-number")
    with pytest.raises(RuntimeError, match="DEFAULT_MIN_SCORE"):
        Settings.from_env()
