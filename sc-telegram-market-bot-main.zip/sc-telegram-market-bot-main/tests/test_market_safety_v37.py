from __future__ import annotations

from app.market_safety_v37 import sanitize_candles, valid_candle
from app.technical import Candle


def test_invalid_ohlc_geometry_and_negative_values_are_rejected() -> None:
    assert not valid_candle(Candle(1, 100, 99, 98, 100, 1000))
    assert not valid_candle(Candle(1, 100, 101, 102, 100, 1000))
    assert not valid_candle(Candle(1, -1, 1, 1, 1, 1000))
    assert not valid_candle(Candle(1, 100, 101, 99, 100, -1))


def test_candles_are_sorted_and_duplicate_timestamps_are_replaced() -> None:
    older = Candle(1, 100, 101, 99, 100, 1000)
    duplicate = Candle(2, 100, 102, 99, 101, 1200)
    replacement = Candle(2, 101, 103, 100, 102, 1300)
    cleaned = sanitize_candles([duplicate, older, replacement])
    assert [item.timestamp for item in cleaned] == [1, 2]
    assert cleaned[-1] == replacement
