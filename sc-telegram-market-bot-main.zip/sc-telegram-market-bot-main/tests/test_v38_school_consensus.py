from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest

import app.school_engine_v38 as engine
from app.focused_bot_v38_helpers import (
    FRAME_ALIASES_V38,
    build_analysis_buttons_v38,
    build_frame_menu_v38,
)
from app.school_engine_v38 import (
    FRAME_SPECS,
    SchoolConsensus,
    SchoolFrameAnalysis,
    SchoolSignal,
    apply_school_consensus,
    evaluate_school_consensus,
    resample_candles,
)
from app.school_format_v38 import format_analysis_v38
from app.technical import Candle, FrameAnalysis, LiveAnalysis


def _frame() -> FrameAnalysis:
    now = datetime(2025, 1, 1, tzinfo=timezone.utc)
    return FrameAnalysis(
        frame="ساعة",
        price=100.0,
        trend="محايد/انتقالي",
        structure="عرضي أو انتقالي",
        event="لا يوجد زناد مؤكد",
        score=50,
        confidence=50,
        evidence_long=45,
        evidence_short=42,
        rsi=52.0,
        ema20=99.5,
        ema50=99.0,
        ema200=95.0,
        macd_hist=0.1,
        atr=1.2,
        atr_percent=1.2,
        volume_ratio=1.3,
        volume_trusted=True,
        support=98.0,
        resistance=102.0,
        direction=0,
        plan_state="مراقبة",
        entry=None,
        stop=None,
        targets=(),
        risk_reward=None,
        reasons=(),
        warnings=(),
        updated_at=now,
    )


def _candles(count: int = 90) -> list[Candle]:
    start = datetime(2024, 1, 1, tzinfo=timezone.utc)
    result: list[Candle] = []
    for index in range(count):
        close = 99.0 + index * 0.01
        result.append(
            Candle(
                int((start + timedelta(hours=index)).timestamp()),
                close - 0.15,
                close + 0.35,
                close - 0.35,
                close,
                1_000_000,
            )
        )
    return result


def test_all_frames_from_minute_to_month_are_registered() -> None:
    assert tuple(FRAME_SPECS) == (
        "1m", "5m", "15m", "30m", "1h", "4h", "1d", "1w", "1mo"
    )
    assert FRAME_ALIASES_V38["دقيقة"] == "1m"
    assert FRAME_ALIASES_V38["أسبوعي"] == "1w"
    assert FRAME_ALIASES_V38["شهري"] == "1mo"


def test_two_independent_schools_are_enough(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        engine,
        "_school_signals",
        lambda *args: [
            SchoolSignal("داو والبنية السعرية", 1, 72, "استمرار اتجاه", "بنية صاعدة"),
            SchoolSignal("الزخم (MACD وRSI)", 1, 68, "تأكيد زخم", "زخم صاعد"),
        ],
    )
    result = evaluate_school_consensus(_candles(), _frame(), "stock")
    assert result.qualified is True
    assert result.direction == 1
    assert result.strong_single is False
    assert result.school_names == ("داو والبنية السعرية", "الزخم (MACD وRSI)")


def test_one_strong_actionable_school_is_enough(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        engine,
        "_school_signals",
        lambda *args: [
            SchoolSignal("وايكوف المبسط (عرض وطلب)", 1, 88, "انعكاس", "Spring", True)
        ],
    )
    result = evaluate_school_consensus(_candles(), _frame(), "stock")
    assert result.qualified is True
    assert result.strong_single is True
    assert result.direction == 1


def test_strong_opposition_vetoes_weak_consensus(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        engine,
        "_school_signals",
        lambda *args: [
            SchoolSignal("الاتجاه", 1, 64, "استمرار اتجاه", "صاعد"),
            SchoolSignal("الزخم", 1, 62, "تأكيد زخم", "صاعد"),
            SchoolSignal("وايكوف", -1, 88, "انعكاس", "Upthrust", True),
        ],
    )
    result = evaluate_school_consensus(_candles(), _frame(), "stock")
    assert result.qualified is False
    assert result.direction == 0


def test_strong_school_builds_entry_stop_and_three_targets(monkeypatch: pytest.MonkeyPatch) -> None:
    consensus = SchoolConsensus(
        direction=1,
        qualified=True,
        strength=90,
        signal_type="انعكاس",
        signals=(SchoolSignal("وايكوف المبسط", 1, 90, "انعكاس", "Spring", True),),
        opposing=(),
        strong_single=True,
    )
    monkeypatch.setattr(engine, "evaluate_school_consensus", lambda *args: consensus)
    enriched = apply_school_consensus(_candles(), _frame(), "stock")
    assert isinstance(enriched, SchoolFrameAnalysis)
    assert enriched.school_count == 1
    assert enriched.entry is not None
    assert enriched.stop is not None and enriched.stop < enriched.entry
    assert len(enriched.targets) == 3
    assert all(target > enriched.entry for target in enriched.targets)
    assert "مدرسة واحدة قوية" in enriched.plan_state


def test_weekly_and_monthly_resampling_use_closed_old_periods() -> None:
    start = datetime(2023, 1, 2, tzinfo=timezone.utc)
    candles = [
        Candle(
            int((start + timedelta(days=index)).timestamp()),
            100 + index,
            101 + index,
            99 + index,
            100.5 + index,
            1000,
        )
        for index in range(120)
    ]
    weekly = resample_candles(candles, "1w", "US", {"marketTimezone": "UTC"})
    monthly = resample_candles(candles, "1mo", "US", {"marketTimezone": "UTC"})
    assert 15 <= len(weekly) <= 20
    assert 3 <= len(monthly) <= 5
    assert all(bar.high >= max(bar.open, bar.close) for bar in weekly + monthly)


def test_telegram_buttons_stay_within_callback_limit() -> None:
    keyboards = [
        build_analysis_buttons_v38("BRK-B"),
        build_frame_menu_v38("US_OPTIONS"),
    ]
    for keyboard in keyboards:
        for row in keyboard["inline_keyboard"]:
            for button in row:
                if "callback_data" in button:
                    assert len(button["callback_data"].encode()) <= 64


def test_analysis_message_names_schools_and_plan() -> None:
    base = _frame()
    values = {name: getattr(base, name) for name in base.__dataclass_fields__}
    frame = SchoolFrameAnalysis(
        **values,
        school_count=2,
        school_names=("داو والبنية السعرية", "الزخم (MACD وRSI)"),
        school_details=(
            "داو والبنية السعرية (75%): بنية صاعدة",
            "الزخم (MACD وRSI) (70%): زخم صاعد",
        ),
        signal_type="ارتداد",
        consensus_strength=76,
        strong_single_school=False,
    )
    frame = frame.__class__(
        **{
            **{name: getattr(frame, name) for name in frame.__dataclass_fields__},
            "direction": 1,
            "confidence": 76,
            "plan_state": "فرصة ارتداد محتملة — توافق مدرستين",
            "entry": 100.0,
            "stop": 98.0,
            "targets": (102.0, 103.6, 105.2),
            "risk_reward": 1.0,
        }
    )
    item = LiveAnalysis(
        query="2222",
        yahoo_symbol="2222.SR",
        display_symbol="2222",
        name="أرامكو السعودية",
        exchange="Tadawul",
        currency="SAR",
        asset_class="stock",
        price=100.0,
        score=70,
        confidence=76,
        recommendation="إيجابي",
        direction=1,
        alignment="توافق جزئي",
        feed_source="yahoo",
        frames=(frame,),
        updated_at=frame.updated_at,
    )
    text = format_analysis_v38(item)
    assert "عدد المدارس المتوافقة" in text
    assert "داو والبنية السعرية" in text
    assert "منطقة الدخول" in text
    assert "وقف الإلغاء" in text
    assert "الهدف 3" in text
    assert len(text) <= 4096
