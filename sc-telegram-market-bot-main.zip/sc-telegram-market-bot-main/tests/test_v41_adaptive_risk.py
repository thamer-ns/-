from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timezone

import pytest

from app.audited_engine import analyze_frame_audited
from app.presentation_v40 import duration, plan_lines, scan_pages
from app.risk_engine_v41 import (
    PROFILES,
    build_adaptive_plan,
    estimate_remaining_duration,
    round_market_price,
    round_to_tick,
    saudi_tick_size,
    tick_size,
)
from app.school_engine_v38 import _equity_period_complete, resample_candles
from app.school_engine_v38_safe import _last_4h_bucket_closed
from app.technical import Candle, FrameAnalysis, LiveAnalysis, _atr
from app.market_data import ScanReport


def _candles(count: int = 420, seconds: int = 86_400) -> list[Candle]:
    bars: list[Candle] = []
    for index in range(count):
        close = 8.0 + index * 0.006 + (0.08 if index % 7 < 3 else -0.05)
        bars.append(
            Candle(
                1_600_000_000 + index * seconds,
                close - 0.03,
                close + 0.35,
                close - 0.35,
                close,
                1_000 + index,
            )
        )
    return bars


def test_saudi_tick_bands_and_directional_rounding() -> None:
    assert saudi_tick_size(24.99) == 0.01
    assert saudi_tick_size(25.00) == 0.02
    assert saudi_tick_size(50.00) == 0.05
    assert saudi_tick_size(100.00) == 0.10
    assert saudi_tick_size(250.00) == 0.20
    assert saudi_tick_size(500.00) == 0.50
    assert round_to_tick(25.011, 0.02, "up") == 25.02
    assert round_to_tick(25.019, 0.02, "down") == 25.0
    assert tick_size("US", 115.0) == 0.01


def test_targets_and_stops_scale_with_their_own_timeframe() -> None:
    # Use a low-volatility price series so every profile can construct a plan.
    # Feeding daily-sized candles to a one-minute profile should be rejected,
    # not forced into an unsafe stop.
    candles: list[Candle] = []
    for index in range(420):
        close = 100.0 + index * 0.01 + (0.015 if index % 7 < 3 else -0.01)
        candles.append(
            Candle(
                1_600_000_000 + index * 86_400,
                close - 0.02,
                close + 0.08,
                close - 0.08,
                close,
                1_000 + index,
            )
        )
    current = candles[-1].close
    atr = _atr(candles)
    plans = {
        frame: build_adaptive_plan(
            candles=candles,
            frame_name=frame,
            direction=1,
            event_level=current - 0.05,
            market="SAUDI",
            entry_override=current,
        )
        for frame in PROFILES
    }
    assert plans["1 دقيقة"].valid is False
    valid_plans = {frame: plan for frame, plan in plans.items() if frame != "1 دقيقة"}
    assert all(plan.valid for plan in valid_plans.values())
    assert all(len(plan.targets) == 3 for plan in valid_plans.values())
    expected_daily_target = PROFILES["يومي"].min_target_atr[0] * atr
    assert plans["يومي"].targets[0] - plans["يومي"].entry >= expected_daily_target * 0.94
    assert plans["يومي"].targets[0] > plans["15 دقيقة"].targets[0]
    assert plans["أسبوعي"].targets[0] > plans["يومي"].targets[0]
    for frame, plan in valid_plans.items():
        assert plan.stop < plan.entry < plan.targets[0] < plan.targets[1] < plan.targets[2]
        for value in (plan.entry, plan.stop, *plan.targets):
            own_tick = tick_size("SAUDI", value)
            assert abs(value / own_tick - round(value / own_tick)) < 1e-7, (frame, value)
        assert plan.risk_atr is not None
        assert plan.risk_atr >= PROFILES[frame].min_stop_atr - 0.08
        max_rounding_atr = tick_size("SAUDI", plan.stop) / atr
        assert plan.risk_atr <= PROFILES[frame].max_stop_atr + max_rounding_atr + 0.03
        assert plan.target_atr[0] >= PROFILES[frame].min_target_atr[0] - 0.08


def test_historical_first_passage_duration_and_fallback() -> None:
    trending: list[Candle] = []
    for index in range(500):
        close = 20 + index * 0.05 + (index % 5) * 0.01
        trending.append(
            Candle(
                1_600_000_000 + index * 86_400,
                close - 0.02,
                close + 0.15,
                close - 0.12,
                close,
                1_000,
            )
        )
    atr = _atr(trending)
    low, high, samples, success_rate, method = estimate_remaining_duration(
        trending,
        frame_name="يومي",
        direction=1,
        reference=trending[-1].close,
        stop=trending[-1].close - atr,
        target=trending[-1].close + 1.3 * atr,
        atr=atr,
    )
    assert method == "historical-first-passage"
    assert 1 <= low <= high
    assert samples >= 8
    assert success_rate is not None

    short = trending[-40:]
    low, high, _, _, method = estimate_remaining_duration(
        short,
        frame_name="يومي",
        direction=1,
        reference=short[-1].close,
        stop=short[-1].close - atr,
        target=short[-1].close + 1.3 * atr,
        atr=atr,
    )
    assert method == "atr-range-fallback"
    assert 1 <= low <= high <= PROFILES["يومي"].duration_horizon


def test_saudi_week_starts_on_sunday() -> None:
    def bar(year: int, month: int, day: int, close: float) -> Candle:
        timestamp = int(
            datetime(year, month, day, 12, tzinfo=timezone.utc).timestamp()
        )
        return Candle(timestamp, close - 0.1, close + 0.2, close - 0.2, close, 100)

    candles = [
        bar(2024, 1, 4, 10.0),   # Thursday, prior Saudi week
        bar(2024, 1, 7, 10.2),   # Sunday, new Saudi week
        bar(2024, 1, 8, 10.3),
        bar(2024, 1, 11, 10.5),
        bar(2024, 1, 14, 10.7),  # next Sunday
    ]
    result = resample_candles(
        candles,
        "1w",
        "SAUDI",
        {"marketTimezone": "Asia/Riyadh"},
    )
    assert len(result) == 3
    assert result[1].timestamp == candles[1].timestamp
    assert result[1].open == candles[1].open
    assert result[1].close == candles[3].close


def test_zero_current_volume_never_borrows_old_volume_confirmation() -> None:
    candles = _candles(100)
    candles[-1] = replace(candles[-1], volume=0.0)
    frame = analyze_frame_audited(candles, "ساعة", "stock")
    assert frame.volume_ratio is None
    assert "مشاركة حجم مؤهلة" not in frame.reasons


def _executable_frame() -> FrameAnalysis:
    base = analyze_frame_audited(_candles(), "يومي", "stock")
    plan = build_adaptive_plan(
        candles=_candles(),
        frame_name="يومي",
        direction=1,
        event_level=_candles()[-1].close - 0.2,
        market="SAUDI",
        entry_override=_candles()[-1].close,
    )
    assert plan.valid
    return replace(
        base,
        market="SAUDI",
        direction=1,
        confidence=88,
        plan_state="دخول قائم — الزناد تحقق",
        entry=plan.entry,
        stop=plan.stop,
        targets=plan.targets,
        risk_reward=plan.first_rr,
        risk_atr=plan.risk_atr,
        target_atr=plan.target_atr,
        duration_low_bars=1,
        duration_high_bars=1,
        duration_samples=20,
        duration_method="historical-first-passage",
    )


def test_presentation_explains_atr_risk_and_duration_method() -> None:
    frame = _executable_frame()
    # Promote through the verified dataclass used by the executable predicate.
    from dataclasses import fields
    from app.school_engine_v38 import SchoolFrameAnalysis
    from app.school_engine_v39 import VerifiedSchoolFrameAnalysis

    values = {field.name: getattr(frame, field.name) for field in fields(FrameAnalysis)}
    school = SchoolFrameAnalysis(
        **values,
        school_count=2,
        school_names=("الاتجاه", "الزخم"),
        school_details=(),
        signal_type="استمرار اتجاه",
        consensus_strength=88,
        strong_single_school=False,
        independent_axes=("الاتجاه", "الزخم"),
    )
    verified_values = {
        field.name: getattr(school, field.name) for field in fields(SchoolFrameAnalysis)
    }
    verified = VerifiedSchoolFrameAnalysis(
        **verified_values,
        consensus_qualified=True,
        plan_valid=True,
        opposing_school_names=(),
    )
    text = "\n".join(plan_lines(verified))
    assert "ATR" in text
    assert "عبور تاريخي" in text
    assert "نحو جلسة تداول واحدة" in text
    assert "1 إلى 1" not in text

    item = LiveAnalysis(
        query="TEST",
        yahoo_symbol="TEST",
        display_symbol="TEST",
        name="Test",
        exchange="Tadawul",
        currency="SAR",
        asset_class="stock",
        price=verified.price,
        score=70,
        confidence=88,
        recommendation="اختبار",
        direction=1,
        alignment="توافق",
        feed_source="test",
        frames=(verified,),
        updated_at=verified.updated_at,
        market="SAUDI",
    )
    report = ScanReport(
        market="US_OPTIONS",
        horizon="1d",
        universe_label="US",
        total_symbols=51,
        analyzed_symbols=49,
        failed_symbols=2,
        direction=1,
        items=(item,),
    )
    scan_text = "\n".join(scan_pages(report))
    assert "Strike" in scan_text and "Expiry" in scan_text
    assert "تعذر أو لم يكتمل تحليل" in scan_text


def test_market_rounding_uses_each_saudi_price_band() -> None:
    assert round_market_price("SAUDI", 24.997, "up") == 25.0
    assert round_market_price("SAUDI", 25.011, "up") == 25.02
    assert round_market_price("SAUDI", 49.991, "up") == 50.0
    assert round_market_price("SAUDI", 50.021, "up") == 50.05
    for value in (24.99, 25.0, 25.02, 49.98, 50.0, 50.05, 100.0, 250.0):
        tick = tick_size("SAUDI", value)
        assert abs(value / tick - round(value / tick)) < 1e-8


def test_risk_engine_rejects_stop_when_volatility_exceeds_frame_budget() -> None:
    candles = _candles()  # intentionally daily-sized movement at a low price
    plan = build_adaptive_plan(
        candles=candles,
        frame_name="1 دقيقة",
        direction=1,
        event_level=candles[-1].close - 0.2,
        market="SAUDI",
        entry_override=candles[-1].close,
    )
    assert plan.valid is False
    assert "المخاطرة" in plan.rejection_reason


def test_four_hour_bucket_closes_at_exchange_session_end() -> None:
    from zoneinfo import ZoneInfo

    riyadh = ZoneInfo("Asia/Riyadh")
    ny = ZoneInfo("America/New_York")
    saudi_start = int(datetime(2026, 7, 23, 14, 0, tzinfo=riyadh).timestamp())
    us_start = int(datetime(2026, 7, 23, 13, 30, tzinfo=ny).timestamp())
    saudi = [Candle(saudi_start, 10, 10.1, 9.9, 10, 100)]
    us = [Candle(us_start, 100, 101, 99, 100, 100)]
    assert not _last_4h_bucket_closed(
        saudi, market="SAUDI", metadata={"marketTimezone": "Asia/Riyadh"},
        target_seconds=14_400, now_utc=datetime(2026, 7, 23, 14, 30, tzinfo=riyadh).astimezone(timezone.utc),
    )
    assert _last_4h_bucket_closed(
        saudi, market="SAUDI", metadata={"marketTimezone": "Asia/Riyadh"},
        target_seconds=14_400, now_utc=datetime(2026, 7, 23, 15, 21, tzinfo=riyadh).astimezone(timezone.utc),
    )
    assert not _last_4h_bucket_closed(
        us, market="US", metadata={"marketTimezone": "America/New_York"},
        target_seconds=14_400, now_utc=datetime(2026, 7, 23, 15, 50, tzinfo=ny).astimezone(timezone.utc),
    )
    assert _last_4h_bucket_closed(
        us, market="US", metadata={"marketTimezone": "America/New_York"},
        target_seconds=14_400, now_utc=datetime(2026, 7, 23, 16, 6, tzinfo=ny).astimezone(timezone.utc),
    )


def test_four_hour_duration_uses_two_equity_buckets_per_session() -> None:
    frame = _executable_frame()
    frame = replace(
        frame,
        frame="4 ساعات",
        duration_low_bars=2,
        duration_high_bars=4,
    )
    assert duration(frame) == "من 1 إلى 2 جلسات تداول"


def test_equity_week_and_month_close_are_session_aware() -> None:
    from zoneinfo import ZoneInfo

    riyadh = ZoneInfo("Asia/Riyadh")
    ny = ZoneInfo("America/New_York")
    assert not _equity_period_complete(
        "1w", "SAUDI", datetime(2026, 7, 23, 15, 0, tzinfo=riyadh)
    )
    assert _equity_period_complete(
        "1w", "SAUDI", datetime(2026, 7, 23, 15, 21, tzinfo=riyadh)
    )
    assert _equity_period_complete(
        "1w", "SAUDI", datetime(2026, 7, 24, 12, 0, tzinfo=riyadh)
    )
    assert not _equity_period_complete(
        "1w", "SAUDI", datetime(2026, 7, 26, 12, 0, tzinfo=riyadh)
    )
    assert not _equity_period_complete(
        "1w", "US", datetime(2026, 7, 24, 15, 59, tzinfo=ny)
    )
    assert _equity_period_complete(
        "1w", "US", datetime(2026, 7, 24, 16, 5, tzinfo=ny)
    )
    assert not _equity_period_complete(
        "1mo", "SAUDI", datetime(2026, 7, 23, 16, 0, tzinfo=riyadh)
    )
    assert _equity_period_complete(
        "1mo", "US", datetime(2026, 7, 31, 16, 5, tzinfo=ny)
    )
