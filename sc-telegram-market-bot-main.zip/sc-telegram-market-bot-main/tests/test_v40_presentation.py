from __future__ import annotations

import asyncio
from dataclasses import fields
from datetime import datetime, timezone
from typing import Any

from app.focused_bot_v40 import LiveBotService
from app.market_data import ScanReport
from app.presentation_v40 import (
    analysis_pages,
    preset_pages,
    scan_pages,
    state_explanation,
)
from app.presets import (
    PRESET_BY_ID,
    PresetMatch,
    PresetReport,
)
from app.school_engine_v38 import SchoolFrameAnalysis
from app.school_engine_v39 import VerifiedSchoolFrameAnalysis
from app.technical import FrameAnalysis, LiveAnalysis


_SCHOOL_FIELDS = {
    "school_count",
    "school_names",
    "school_details",
    "signal_type",
    "consensus_strength",
    "strong_single_school",
}


def _frame(
    *,
    frame_name: str = "15 دقيقة",
    direction: int = 1,
    qualified: bool = True,
    valid: bool = True,
    plan_state: str = "دخول قائم — الزناد تحقق والسعر ضمن نطاق غير ممتد",
    confidence: int = 92,
    **changes: Any,
) -> VerifiedSchoolFrameAnalysis:
    school_changes = {
        key: changes.pop(key)
        for key in tuple(changes)
        if key in _SCHOOL_FIELDS
    }
    entry = 23.51
    stop = 23.30 if direction > 0 else 23.72
    targets = (
        (23.72, 23.89, 24.06)
        if direction > 0
        else (23.30, 23.14, 22.98)
    )
    if not valid:
        entry = None
        stop = None
        targets = ()
    base = FrameAnalysis(
        frame=frame_name,
        price=23.55,
        trend="صاعد" if direction > 0 else "هابط" if direction < 0 else "محايد",
        structure="قمم وقيعان صاعدة" if direction > 0 else "قمم وقيعان هابطة",
        event="إعادة اختبار",
        score=88 if direction > 0 else 12 if direction < 0 else 50,
        confidence=confidence,
        evidence_long=88 if direction > 0 else 12,
        evidence_short=88 if direction < 0 else 12,
        rsi=60.0 if direction > 0 else 40.0,
        ema20=23.5,
        ema50=23.7,
        ema200=24.0,
        macd_hist=0.2 if direction > 0 else -0.2,
        atr=0.18,
        atr_percent=0.76,
        volume_ratio=2.1,
        volume_trusted=True,
        support=23.30,
        resistance=23.72,
        direction=direction,
        plan_state=plan_state,
        entry=entry,
        stop=stop,
        targets=targets,
        risk_reward=1.0 if valid else None,
        reasons=("تقدم الخطة: 0/3",),
        warnings=(),
        updated_at=datetime.now(timezone.utc),
    )
    frame_values = {
        item.name: getattr(base, item.name)
        for item in fields(FrameAnalysis)
    }
    frame_values.update(changes)
    school_values: dict[str, Any] = {
        "school_count": 3,
        "school_names": (
            "الدعم والمقاومة",
            "داو والبنية السعرية",
            "الزخم (MACD وRSI)",
        ),
        "school_details": (
            "الدعم والمقاومة (92%): إعادة اختبار مؤكدة",
            "داو والبنية السعرية (84%): BOS مؤكد",
            "الزخم (MACD وRSI) (84%): الزخم يدعم الاتجاه",
        ),
        "signal_type": "ارتداد",
        "consensus_strength": 92,
        "strong_single_school": False,
    }
    school_values.update(school_changes)
    school = SchoolFrameAnalysis(**frame_values, **school_values)
    verified_values = {
        item.name: getattr(school, item.name)
        for item in fields(SchoolFrameAnalysis)
    }
    return VerifiedSchoolFrameAnalysis(
        **verified_values,
        consensus_qualified=qualified,
        plan_valid=valid,
        opposing_school_names=(),
    )


def _analysis(frames: tuple[FrameAnalysis, ...]) -> LiveAnalysis:
    primary = frames[0]
    return LiveAnalysis(
        query="1150",
        yahoo_symbol="1150.SR",
        display_symbol="1150",
        name="Alinma Bank — مصرف الإنماء",
        exchange="Tadawul",
        currency="SAR",
        asset_class="stock",
        price=23.55,
        score=primary.score,
        confidence=primary.confidence,
        recommendation="اختبار",
        direction=primary.direction,
        alignment="توافق جزئي/مرحلة انتقال",
        feed_source="yahoo",
        frames=frames,
        updated_at=primary.updated_at,
    )


def _assert_safe_pages(pages: tuple[str, ...]) -> None:
    assert pages
    for page in pages:
        assert len(page) <= 4096
        assert page.count("<b>") == page.count("</b>")
        assert page.count("<i>") == page.count("</i>")
        assert page.count("<code>") == page.count("</code>")


def test_state_wording_is_clear_for_beginner() -> None:
    assert "فرصة مفعّلة" in state_explanation(_frame())
    assert "بانتظار التفعيل" in state_explanation(
        _frame(plan_state="فرصة مشروطة — تنتظر إغلاق الزناد")
    )
    assert "لا يوجد توافق كافٍ" in state_explanation(
        _frame(
            qualified=False,
            valid=False,
            direction=0,
            plan_state="مراقبة",
            confidence=20,
        )
    )


def test_analysis_pages_show_complete_plan_for_every_actionable_frame() -> None:
    frames = (
        _frame(frame_name="يومي", direction=-1),
        _frame(frame_name="1 دقيقة", direction=1, confidence=84),
        _frame(frame_name="5 دقائق", direction=1, confidence=81),
        _frame(
            frame_name="15 دقيقة",
            direction=0,
            qualified=False,
            valid=False,
            confidence=0,
            plan_state="مراقبة",
        ),
        _frame(
            frame_name="30 دقيقة",
            direction=0,
            qualified=False,
            valid=False,
            confidence=38,
            plan_state="مراقبة",
        ),
        _frame(
            frame_name="ساعة",
            direction=0,
            qualified=False,
            valid=False,
            confidence=48,
            plan_state="مراقبة",
        ),
        _frame(
            frame_name="4 ساعات",
            direction=0,
            qualified=False,
            valid=False,
            confidence=40,
            plan_state="مراقبة",
        ),
        _frame(
            frame_name="أسبوعي",
            direction=0,
            qualified=False,
            valid=False,
            confidence=38,
            plan_state="مراقبة",
        ),
        _frame(frame_name="شهري", direction=1, confidence=72),
    )
    pages = analysis_pages(_analysis(frames))
    _assert_safe_pages(pages)
    text = "\n".join(pages)
    assert "الخلاصة التنفيذية" in text
    assert "لماذا ظهرت هذه النتيجة؟" in text
    assert "خطة الفرصة على فاصل يومي" in text
    assert text.count("وقف إلغاء الفكرة") >= 4
    assert text.count("الهدف 1") >= 4
    assert text.count("الهدف 2") >= 4
    assert text.count("الهدف 3") >= 4
    assert text.count("المدة التقديرية") >= 4
    assert "15 دقيقة — مراقبة فقط" in text
    assert "بعض الفواصل تؤيد الاتجاه" in text


def test_option_scan_pages_label_call_and_show_full_underlying_plan() -> None:
    item = _analysis((_frame(frame_name="15 دقيقة", direction=1),))
    report = ScanReport(
        market="US_OPTIONS",
        horizon="15m",
        universe_label="الأوبشن الأمريكي",
        total_symbols=51,
        analyzed_symbols=51,
        failed_symbols=0,
        direction=1,
        items=(item, item),
    )
    pages = scan_pages(report)
    _assert_safe_pages(pages)
    text = "\n".join(pages)
    assert "فرص CALL مؤكدة" in text
    assert "CALL حسب الأصل" in text
    assert "الوقف" in text
    assert "الهدف 1" in text and "الهدف 2" in text and "الهدف 3" in text
    assert "المدة التقديرية" in text


def test_confirmed_buy_preset_shows_entry_stop_targets_and_duration() -> None:
    item = _analysis((_frame(frame_name="15 دقيقة", direction=1),))
    report = PresetReport(
        market="SAUDI",
        frame_key="15m",
        universe_label="أسهم السوق السعودي الرئيسي",
        total_symbols=251,
        analyzed_symbols=249,
        failed_symbols=2,
        preset=PRESET_BY_ID["planup"],
        items=(PresetMatch(item, ("الخطة تحتوي دخولًا ووقفًا وأهدافًا صالحة",), 95.0),),
    )
    pages = preset_pages(report, "15")
    _assert_safe_pages(pages)
    text = "\n".join(pages)
    assert "خطة شراء مؤكدة" in text
    assert "الدخول المرجعي" in text
    assert "وقف إلغاء الفكرة" in text
    assert "الهدف 1" in text and "الهدف 2" in text and "الهدف 3" in text
    assert "المدة التقديرية" in text


def test_send_pages_places_buttons_only_on_last_message() -> None:
    class FakeTelegram:
        def __init__(self) -> None:
            self.calls: list[tuple[str, object]] = []

        async def send_message(self, chat_id, text, buttons=None):
            self.calls.append((text, buttons))

    service = object.__new__(LiveBotService)
    service.telegram = FakeTelegram()
    buttons = {"inline_keyboard": [[{"text": "اختبار", "callback_data": "x"}]]}
    asyncio.run(service._send_pages(1, ("الأولى", "الثانية", "الثالثة"), buttons))
    assert [call[1] for call in service.telegram.calls] == [None, None, buttons]
