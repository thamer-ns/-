from __future__ import annotations

from datetime import datetime, timezone

import pytest

import app.school_engine_v38_final as final
from app.school_engine_v38 import (
    SchoolConsensus,
    SchoolFrameAnalysis,
    SchoolSignal,
)
from app.technical import Candle, FrameAnalysis


def _base_frame(**changes) -> SchoolFrameAnalysis:
    base = FrameAnalysis(
        frame="ساعة",
        price=103.0,
        trend="صاعد",
        structure="قمم وقيعان صاعدة",
        event="لا يوجد زناد",
        score=70,
        confidence=75,
        evidence_long=75,
        evidence_short=25,
        rsi=60.0,
        ema20=101.0,
        ema50=99.0,
        ema200=95.0,
        macd_hist=0.5,
        atr=1.0,
        atr_percent=1.0,
        volume_ratio=1.2,
        volume_trusted=True,
        support=101.5,
        resistance=104.0,
        direction=1,
        plan_state="مراقبة",
        entry=None,
        stop=None,
        targets=(),
        risk_reward=None,
        reasons=(),
        warnings=(),
        updated_at=datetime.now(timezone.utc),
    )
    values = {
        name: getattr(base, name)
        for name in base.__dataclass_fields__
    }
    values.update(changes)
    return SchoolFrameAnalysis(
        **values,
        school_count=1,
        school_names=("الدعم والمقاومة",),
        school_details=("اختراق",),
        signal_type="اختراق",
        consensus_strength=90,
        strong_single_school=True,
    )


def _candles() -> list[Candle]:
    candles: list[Candle] = []
    for index in range(70):
        close = 100.0 + index * 0.02
        candles.append(
            Candle(index + 1, close - 0.1, close + 0.4, close - 0.4, close, 1000)
        )
    candles[-2] = Candle(69, 101.5, 102.1, 101.2, 101.8, 1000)
    candles[-1] = Candle(70, 101.9, 103.4, 101.7, 103.0, 1800)
    return candles


def test_breakout_uses_level_known_before_trigger(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(final, "_school_signals", lambda *args: [])
    monkeypatch.setattr(
        final,
        "_reference_levels",
        lambda candles, price, atr: (99.0, 102.0, [99.0, 102.0]),
    )
    signals = final._corrected_school_signals(
        _candles(), _base_frame(), "stock"
    )
    support_signal = next(
        signal
        for signal in signals
        if signal.school == "الدعم والمقاومة"
    )
    assert support_signal.direction == 1
    assert support_signal.signal_type == "اختراق"
    assert support_signal.actionable is True
    assert "معروفة قبل" in support_signal.reason


def test_direct_long_plan_uses_nearest_valid_support() -> None:
    candles = _candles()
    frame = _base_frame(
        price=103.0,
        support=101.5,
        entry=None,
        stop=None,
        targets=(),
    )
    consensus = SchoolConsensus(
        direction=1,
        qualified=True,
        strength=88,
        signal_type="ارتداد",
        signals=(
            SchoolSignal(
                "السلوك السعري والشموع",
                1,
                88,
                "ارتداد",
                "مطرقة قرب دعم",
                True,
            ),
        ),
        opposing=(),
        strong_single=True,
    )
    result = final._direct_school_plan(candles, frame, consensus)
    assert result.entry == pytest.approx(103.0)
    assert result.stop is not None
    assert 100.0 < result.stop < result.entry
    assert len(result.targets) == 3


def test_consensus_reports_all_aligned_schools(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    aligned = [
        SchoolSignal(f"مدرسة {index}", 1, 70 - index, "استمرار اتجاه", "سبب")
        for index in range(1, 6)
    ]
    monkeypatch.setattr(
        final,
        "_corrected_school_signals",
        lambda *args: aligned,
    )
    result = final.evaluate_school_consensus_final(
        _candles(), _base_frame(), "stock"
    )
    assert result.qualified is True
    assert len(result.signals) == 5
    assert result.school_names[-1] == "مدرسة 5"


def test_correlated_structure_schools_count_as_one_axis(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    signals = [
        SchoolSignal("داو والبنية السعرية", 1, 80, "اختراق", "BOS", True),
        SchoolSignal("الدعم والمقاومة", 1, 78, "اختراق", "كسر", True),
        SchoolSignal("وايكوف المبسط (عرض وطلب)", 1, 76, "ارتداد", "Spring", True),
    ]
    monkeypatch.setattr(final, "_corrected_school_signals", lambda *args: signals)
    result = final.evaluate_school_consensus_final(
        _candles(), _base_frame(), "stock"
    )
    assert result.qualified is False
    assert result.independent_axes == ("البنية والمستويات",)


def test_two_independent_axes_can_qualify(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    signals = [
        SchoolSignal("اتباع الاتجاه والمتوسطات", 1, 72, "استمرار اتجاه", "اتجاه", False),
        SchoolSignal("الزخم (MACD وRSI)", 1, 70, "تأكيد زخم", "زخم", True),
    ]
    monkeypatch.setattr(final, "_corrected_school_signals", lambda *args: signals)
    result = final.evaluate_school_consensus_final(
        _candles(), _base_frame(), "stock"
    )
    assert result.qualified is True
    assert set(result.independent_axes) == {"الاتجاه", "الزخم"}


def test_single_strong_school_requires_clear_margin(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    close_opposition = [
        SchoolSignal("السلوك السعري والشموع", 1, 90, "انعكاس", "مطرقة", True),
        SchoolSignal("الزخم (MACD وRSI)", -1, 80, "تأكيد زخم", "زخم هابط", True),
    ]
    monkeypatch.setattr(
        final, "_corrected_school_signals", lambda *args: close_opposition
    )
    rejected = final.evaluate_school_consensus_final(
        _candles(), _base_frame(), "stock"
    )
    assert rejected.qualified is False

    monkeypatch.setattr(
        final,
        "_corrected_school_signals",
        lambda *args: close_opposition[:1],
    )
    accepted = final.evaluate_school_consensus_final(
        _candles(), _base_frame(), "stock"
    )
    assert accepted.qualified is True
    assert accepted.strong_single is True
