from __future__ import annotations

from datetime import datetime, timezone

from app.focused_bot import LiveBotService
from app.models import Opportunity
from app.presentation_v40 import duration
from app.stored_presentation_v40 import active_plan_pages
from app.technical import FrameAnalysis


def test_main_menu_exposes_beginner_shortcuts() -> None:
    menu = LiveBotService._main_menu()
    buttons = [button for row in menu["inline_keyboard"] for button in row]
    texts = {button["text"] for button in buttons}
    callbacks = {button.get("callback_data") for button in buttons}
    assert "📊 تحليل سهم أو رمز" in texts
    assert "🔎 فرص مكتملة" in texts
    assert "🟢 خطط شراء سعودية" in texts
    assert "🔴 خطط هبوط سعودية" in texts
    assert "🟢 فرص CALL" in texts
    assert "🔴 فرص PUT" in texts
    assert "📂 خطط TradingView النشطة" in texts
    assert {
        "menu:analyze",
        "menu:scan",
        "fpf:SAUDI:planup",
        "fpf:SAUDI:plandn",
        "quick:calls",
        "quick:puts",
        "menu:active",
    }.issubset(callbacks)
    assert all(
        len(str(callback).encode("utf-8")) <= 64
        for callback in callbacks
        if callback
    )


def test_active_tradingview_plan_shows_all_levels() -> None:
    now = datetime.now(timezone.utc).isoformat()
    item = Opportunity(
        key="TADAWUL:1150|15|1",
        event_id=1,
        market="SAUDI",
        tickerid="TADAWUL:1150",
        ticker="1150",
        timeframe="15",
        source="SC",
        direction=1,
        entry=23.51,
        stop=23.30,
        target1=23.72,
        target2=23.89,
        target3=24.06,
        target_count=3,
        score=92,
        score_max=100,
        counter_trend=False,
        status="TARGET_1",
        last_event="TARGET_1",
        opened_at=now,
        updated_at=now,
    )
    pages = active_plan_pages([item])
    assert pages and all(len(page) <= 4096 for page in pages)
    text = "\n".join(pages)
    assert "خطط TradingView النشطة" in text
    assert "الدخول المرجعي" in text
    assert "وقف إلغاء الفكرة" in text
    assert "الهدف 1" in text
    assert "الهدف 2" in text
    assert "الهدف 3" in text
    assert "تحقق الهدف الأول" in text


def test_duration_never_says_one_to_one() -> None:
    frame = FrameAnalysis(
        frame="يومي",
        price=100.0,
        trend="صاعد",
        structure="صاعد",
        event="اختبار",
        score=80,
        confidence=80,
        evidence_long=80,
        evidence_short=20,
        rsi=60.0,
        ema20=99.0,
        ema50=98.0,
        ema200=95.0,
        macd_hist=0.2,
        atr=10.0,
        atr_percent=10.0,
        volume_ratio=1.2,
        volume_trusted=True,
        support=95.0,
        resistance=105.0,
        direction=1,
        plan_state="دخول قائم",
        entry=100.0,
        stop=90.0,
        targets=(101.0, 102.0, 103.0),
        risk_reward=0.1,
        reasons=("تقدم الخطة: 0/3",),
        warnings=(),
        updated_at=datetime.now(timezone.utc),
    )
    result = duration(frame)
    assert result == "نحو جلسة تداول واحدة"
    assert "1 إلى 1" not in result
