from __future__ import annotations

import asyncio
from pathlib import Path

import pytest
from pydantic import ValidationError

from app.audited_models import AuditedTradingViewAlert
from app.database_v39 import VerifiedDatabase
from app.models import AlertEvent


def _alert(
    event: AlertEvent,
    *,
    event_time_ms: int,
    direction: int = 1,
    target_count: int = 3,
) -> AuditedTradingViewAlert:
    values = {
        "source": "TEST",
        "event": event,
        "tickerid": "TADAWUL:2222",
        "timeframe": "60",
        "event_time_ms": event_time_ms,
        "price": 26.5,
        "direction": direction,
        "target_count": target_count,
        "score": 80,
        "score_max": 100,
    }
    if event in {AlertEvent.NEW_LONG, AlertEvent.NEW_SHORT}:
        if direction > 0:
            values.update(
                entry=26.5,
                stop=25.9,
                target1=27.0,
                target2=27.2,
                target3=27.4,
            )
        else:
            values.update(
                entry=26.5,
                stop=27.1,
                target1=26.0,
                target2=25.8,
                target3=25.6,
            )
    return AuditedTradingViewAlert(**values)


def test_target_count_is_rejected_not_clamped() -> None:
    with pytest.raises(ValidationError):
        _alert(
            AlertEvent.NEW_LONG,
            event_time_ms=1_000,
            target_count=0,
        )
    with pytest.raises(ValidationError):
        _alert(
            AlertEvent.NEW_LONG,
            event_time_ms=2_000,
            target_count=99,
        )


def test_opportunity_transitions_are_monotonic(
    tmp_path: Path,
) -> None:
    async def scenario() -> None:
        db = VerifiedDatabase(tmp_path / "bot.sqlite3")
        await db.initialize()

        _, created, _ = await db.record_alert(
            _alert(AlertEvent.NEW_LONG, event_time_ms=10_000)
        )
        assert created is True

        _, created, _ = await db.record_alert(
            _alert(AlertEvent.TARGET_2, event_time_ms=20_000)
        )
        assert created is True
        rows = await db.find_symbol("2222", limit=1)
        assert rows[0].status == "TARGET_2"

        _, created, _ = await db.record_alert(
            _alert(AlertEvent.TARGET_1, event_time_ms=30_000)
        )
        assert created is False
        rows = await db.find_symbol("2222", limit=1)
        assert rows[0].status == "TARGET_2"

        _, created, _ = await db.record_alert(
            _alert(AlertEvent.TARGET_3, event_time_ms=40_000)
        )
        assert created is True
        rows = await db.find_symbol("2222", limit=1)
        assert rows[0].status == "COMPLETED"

        _, created, _ = await db.record_alert(
            _alert(AlertEvent.STOP, event_time_ms=50_000)
        )
        assert created is False
        rows = await db.find_symbol("2222", limit=1)
        assert rows[0].status == "COMPLETED"

    asyncio.run(scenario())


def test_state_event_without_open_plan_is_ignored(
    tmp_path: Path,
) -> None:
    async def scenario() -> None:
        db = VerifiedDatabase(tmp_path / "empty.sqlite3")
        await db.initialize()
        _, created, _ = await db.record_alert(
            _alert(AlertEvent.TARGET_1, event_time_ms=60_000)
        )
        assert created is False
        assert await db.find_symbol("2222", limit=1) == []

    asyncio.run(scenario())


def test_declared_target_count_closes_at_last_declared_target_and_preserves_plan(
    tmp_path: Path,
) -> None:
    async def scenario() -> None:
        for target_count, final_event in (
            (1, AlertEvent.TARGET_1),
            (2, AlertEvent.TARGET_2),
        ):
            db = VerifiedDatabase(tmp_path / f"targets-{target_count}.sqlite3")
            await db.initialize()
            plan = _alert(
                AlertEvent.NEW_LONG,
                event_time_ms=100_000 + target_count,
                target_count=target_count,
            )
            await db.record_alert(plan)
            _, created, _ = await db.record_alert(
                _alert(
                    final_event,
                    event_time_ms=110_000 + target_count,
                    target_count=target_count,
                )
            )
            assert created is True
            row = (await db.find_symbol("2222", limit=1))[0]
            assert row.status == "COMPLETED"
            assert row.target_count == target_count
            assert row.score == 80 and row.score_max == 100
            assert row.entry == pytest.approx(26.5)
            assert row.stop == pytest.approx(25.9)
            assert row.target1 == pytest.approx(27.0)

    asyncio.run(scenario())


def test_stale_new_plan_does_not_replace_newer_plan(tmp_path: Path) -> None:
    async def scenario() -> None:
        db = VerifiedDatabase(tmp_path / "stale.sqlite3")
        await db.initialize()
        newer = _alert(AlertEvent.NEW_LONG, event_time_ms=200_000)
        older = _alert(AlertEvent.NEW_LONG, event_time_ms=100_000).model_copy(
            update={"entry": 25.0, "stop": 24.0, "target1": 26.0,
                    "target2": 27.0, "target3": 28.0}
        )
        await db.record_alert(newer)
        _, created, _ = await db.record_alert(older)
        assert created is False
        row = (await db.find_symbol("2222", limit=1))[0]
        assert row.entry == pytest.approx(26.5)
        assert row.status == "ACTIVE"

    asyncio.run(scenario())


def test_durable_telegram_inbox_deduplicates_retries_and_recovers(
    tmp_path: Path,
) -> None:
    async def scenario() -> None:
        path = tmp_path / "inbox.sqlite3"
        db = VerifiedDatabase(path)
        await db.initialize()
        payload = {"update_id": 7, "message": {"text": "/status"}}
        assert await db.enqueue_telegram_update(7, payload) is True
        assert await db.enqueue_telegram_update(7, payload) is False
        rows = await db.pending_telegram_updates(limit=10)
        assert [row["update_id"] for row in rows] == [7]
        await db.mark_telegram_update_failed(7, 1, "temporary")

        # Force immediate retry without waiting for exponential backoff.
        with db._connect() as conn:
            conn.execute(
                "UPDATE telegram_inbox SET next_attempt_at=? WHERE update_id=7",
                (db._now(),),
            )
        rows = await db.pending_telegram_updates(limit=10)
        assert rows and rows[0]["attempts"] == 1

        # A restart must recover a row left in PROCESSING.
        restarted = VerifiedDatabase(path)
        await restarted.initialize()
        rows = await restarted.pending_telegram_updates(limit=10)
        assert rows and rows[0]["update_id"] == 7
        await restarted.mark_telegram_update_done(7)
        assert await restarted.pending_telegram_updates(limit=10) == []

    asyncio.run(scenario())


def test_first_admin_claim_is_atomic(tmp_path: Path) -> None:
    async def scenario() -> None:
        db = VerifiedDatabase(tmp_path / "admin.sqlite3")
        await db.initialize()
        results = await asyncio.gather(
            db.claim_first_admin(1, 1),
            db.claim_first_admin(2, 2),
        )
        assert sum(bool(value) for value in results) == 1

    asyncio.run(scenario())
