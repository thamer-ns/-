from dataclasses import replace
from datetime import datetime, timezone

from app.presets import PRESETS, build_signal_snapshot, match_preset, normalize_analysis
from app.technical import Candle, FrameAnalysis, LiveAnalysis


def frame(*, direction=0, confidence=50, score=50, price=100.0, entry=None):
    return FrameAnalysis(
        frame="يومي",
        price=price,
        trend="صاعد" if direction > 0 else "هابط" if direction < 0 else "محايد/انتقالي",
        structure="قمم وقيعان صاعدة" if direction > 0 else "قمم وقيعان هابطة" if direction < 0 else "عرضي أو انتقالي",
        event="لا يوجد زناد مؤكد",
        score=score,
        confidence=confidence,
        evidence_long=confidence if direction > 0 else 20,
        evidence_short=confidence if direction < 0 else 20,
        rsi=55.0,
        ema20=98.0,
        ema50=95.0,
        ema200=90.0,
        macd_hist=1.0,
        atr=2.0,
        atr_percent=2.0,
        volume_ratio=1.2,
        volume_trusted=True,
        support=99.5,
        resistance=110.0,
        direction=direction,
        plan_state="خطة مؤكدة" if entry is not None else "مراقبة",
        entry=entry,
        stop=entry - 2 if entry is not None else None,
        targets=(entry + 2, entry + 4, entry + 6) if entry is not None else (),
        risk_reward=1.0 if entry is not None else None,
        reasons=(),
        warnings=(),
        updated_at=datetime.now(timezone.utc),
    )


def analysis(single_frame, *, aggregate_direction=1, aggregate_score=65):
    return LiveAnalysis(
        query="TEST",
        yahoo_symbol="TEST",
        display_symbol="TEST",
        name="Test",
        exchange="TEST",
        currency="SAR",
        asset_class="stock",
        price=single_frame.price,
        score=aggregate_score,
        confidence=single_frame.confidence,
        recommendation="قديم",
        direction=aggregate_direction,
        alignment="قديم",
        feed_source="test",
        frames=(single_frame,),
        updated_at=datetime.now(timezone.utc),
    )


def candles_with_last(values, *, last_open=None, last_high=None, last_low=None):
    candles = []
    for index, close in enumerate(values):
        open_price = close - 0.4
        high = close + 0.6
        low = close - 0.8
        if index == len(values) - 1:
            open_price = close - 0.4 if last_open is None else last_open
            high = close + 0.6 if last_high is None else last_high
            low = close - 0.8 if last_low is None else last_low
        candles.append(Candle(1_700_000_000 + index * 86_400, open_price, high, low, close, 1_000_000 + index * 1000))
    return candles


def test_single_frame_direction_cannot_be_invented_by_aggregate_score():
    item = analysis(frame(direction=0, confidence=48, score=57), aggregate_direction=1, aggregate_score=62)
    fixed = normalize_analysis(item)
    assert fixed.direction == 0
    assert fixed.score == 57
    assert "فاصل واحد" in fixed.alignment


def test_three_rising_closes_are_detected():
    values = [80 + index * 0.1 for index in range(57)] + [90.0, 91.0, 92.0]
    current_frame = frame(direction=1, confidence=70, score=70, price=92.0)
    snapshot = build_signal_snapshot(candles_with_last(values), current_frame)
    assert "up3" in snapshot.tags
    preset = next(item for item in PRESETS if item.preset_id == "up3")
    matched, reasons, _ = match_preset(preset, analysis(current_frame), snapshot)
    assert matched
    assert any("ثلاثة إغلاقات" in reason for reason in reasons)


def test_bullish_engulfing_requires_support_context_in_preset():
    values = [100 + index * 0.01 for index in range(58)] + [100.0, 101.0]
    candles = candles_with_last(values)
    previous = Candle(candles[-2].timestamp, 101.0, 101.2, 99.8, 100.0, 1_000_000)
    current = Candle(candles[-1].timestamp, 99.8, 101.5, 99.5, 101.2, 2_000_000)
    candles[-2:] = [previous, current]
    current_frame = replace(frame(direction=1, confidence=70, score=70, price=101.2), support=100.8)
    snapshot = build_signal_snapshot(candles, current_frame)
    assert "bull_engulf" in snapshot.tags
    assert "near_support" in snapshot.tags


def test_plan_preset_rejects_direction_without_entry_stop_targets():
    current_frame = frame(direction=1, confidence=80, score=75, price=100.0, entry=None)
    values = [90 + index * 0.1 for index in range(60)]
    snapshot = build_signal_snapshot(candles_with_last(values), current_frame)
    preset = next(item for item in PRESETS if item.preset_id == "planup")
    matched, _, _ = match_preset(preset, analysis(current_frame), snapshot)
    assert not matched


def test_preset_ids_are_unique():
    ids = [item.preset_id for item in PRESETS]
    assert len(ids) == len(set(ids))
