from app.universes import SAUDI_MAIN_MARKET, US_OPTIONS_PRIORITY, UniverseCatalog


def test_saudi_main_market_is_broad() -> None:
    assert len(SAUDI_MAIN_MARKET) >= 200
    assert {"1120", "2222", "2010", "7010", "8313"}.issubset(SAUDI_MAIN_MARKET)


def test_us_options_priority_is_focused() -> None:
    assert len(set(US_OPTIONS_PRIORITY)) == 51
    assert {"AAPL", "NVDA", "TSLA", "COST", "XOM"}.issubset(
        US_OPTIONS_PRIORITY
    )
    assert not {"SPY", "QQQ", "COIN"} & set(US_OPTIONS_PRIORITY)


def test_cboe_parser_extracts_underlyings() -> None:
    text = "Underlying Symbol,Description\nAAPL,Apple\nSPY,ETF\nBRK/B,Berkshire\n"
    assert UniverseCatalog._parse_cboe_symbols(text) >= {"AAPL", "SPY", "BRK.B"}
