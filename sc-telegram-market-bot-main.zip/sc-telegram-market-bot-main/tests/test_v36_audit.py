from __future__ import annotations

import asyncio
from dataclasses import replace
from datetime import datetime, timedelta, timezone

from app.audited_engine import (
    AuditedMultiSourceProvider,
    _setup_event_audited,
    analyze_frame_audited,
)
from app.audited_engine_patch import AuditedMarketAnalyzer
from app.audited_runtime import AuditedDatabase
from app.models import TradingViewAlert
from app.technical import Candle, FrameAnalysis, SymbolSpec
from app.universes import US_FOCUS_UNIVERSE


def _frame(
    name: str,
    price: float,
    direction: int,
    confidence: int,
    score: int,
    updated_at: datetime,
) -> FrameAnalysis:
    return FrameAnalysis(
        frame=name,
        price=price,
        trend="صاعد" if direction > 0 else "هابط" if direction < 0 else "محايد/انتقالي",
        structure="قمم وقيعان صاعدة" if direction > 0 else "قمم وقيعان هابطة" if direction < 0 else "عرضي أو انتقالي",
        event="لا يوجد زناد مؤكد",
        score=score,
        confidence=confidence,
        evidence_long=confidence if direction > 0 else 20,
        evidence_short=confidence if direction < 0 else 20,
        rsi=55.0,
        ema20=price - 1,
        ema50=price - 2,
        ema200=price - 3,
        macd_hist=1.0 if direction > 0 else -1.0 if direction < 0 else 0.0,
        atr=2.0,
        atr_percent=2.0,
        volume_ratio=1.2,
        volume_trusted=True,
        support=price - 5,
        resistance=price + 5,
        direction=direction,
        plan_state="مراقبة",
        entry=None,
        stop=None,
        targets=(),
        risk_reward=None,
        reasons=(),
        warnings=(),
        updated_at=updated_at,
    )


def test_attached_us_screens_are_complete_and_exact() -> None:
    expected = {
        "AAPL", "ABBV", "AMAT", "AMD", "AMZN", "ANET", "AVGO", "AXP", "BRK-B",
        "C", "CAT", "COST", "CSCO", "CVX", "DELL", "GE", "GEV", "GOOG", "GOOGL",
        "GS", "HD", "INTC", "JNJ", "JPM", "KLAC", "KO", "LLY", "LRCX", "MA",
        "META", "MRK", "MS", "MSFT", "MU", "NVDA", "ORCL", "PANW", "PG", "PLTR",
        "PM", "RTX", "SNDK", "SPCX", "TMUS", "TSLA", "TXN", "UNH", "V", "WFC",
        "WMT", "XOM",
    }
    assert len(US_FOCUS_UNIVERSE) == 51
    assert set(US_FOCUS_UNIVERSE) == expected


def test_breakout_uses_preexisting_level() -> None:
    candles = [
        Candle(1, 98, 99, 97, 98.5, 1000),
        Candle(2, 98.5, 100, 98, 99, 1000),
        Candle(3, 99, 103, 98.8, 102, 1800),
    ]
    direction, text, level = _setup_event_audited(candles, 95, 100, 1.5)
    assert direction == 1
    assert text == "كسر مقاومة مؤكد"
    assert level == 100


def test_retest_rejects_deep_overshoot() -> None:
    candles = [
        Candle(1, 98, 99, 97, 98, 1000),
        Candle(2, 99, 102, 98.5, 101.5, 1200),
        Candle(3, 101, 102, 90, 101, 1600),
    ]
    direction, text, _ = _setup_event_audited(candles, 95, 100, 2.0)
    assert not (direction == 1 and text.startswith("إعادة اختبار"))


def test_latest_closed_frame_sets_reference_price_and_sources_are_aggregated() -> None:
    now = datetime.now(timezone.utc)
    frames = [
        _frame("يومي", 100, 1, 72, 70, now - timedelta(days=1)),
        _frame("ساعة", 105, 1, 68, 66, now - timedelta(hours=1)),
        _frame("15 دقيقة", 106, 0, 48, 52, now - timedelta(minutes=15)),
    ]
    result = AuditedMarketAnalyzer._build_audited(
        "AAPL",
        frames,
        {"longName": "Apple", "exchangeName": "Nasdaq", "currency": "USD"},
        ["barchart", "yahoo", "yahoo"],
    )
    assert result.price == 106
    assert result.direction == 1
    assert result.alignment == "توافق جزئي مع فواصل محايدة"
    assert result.feed_source == "barchart + yahoo"


def test_strong_daily_hourly_conflict_blocks_direction_and_all_plans() -> None:
    now = datetime.now(timezone.utc)
    daily = replace(
        _frame("يومي", 100, 1, 75, 72, now - timedelta(days=1)),
        plan_state="خطة مؤكدة بعد إغلاق الزناد",
        entry=101,
        stop=96,
        targets=(106, 110, 114),
        risk_reward=1.0,
    )
    hourly = replace(
        _frame("ساعة", 95, -1, 72, 35, now - timedelta(hours=1)),
        plan_state="خطة مؤكدة بعد إغلاق الزناد",
        entry=94,
        stop=98,
        targets=(90, 87, 84),
        risk_reward=1.0,
    )
    result = AuditedMarketAnalyzer._build_audited(
        "AAPL", [daily, hourly], {}, ["yahoo", "yahoo"]
    )
    assert result.direction == 0
    assert "تعارض قوي" in result.alignment
    assert all(frame.entry is None for frame in result.frames)
    assert all(frame.stop is None for frame in result.frames)
    assert all(not frame.targets for frame in result.frames)
    assert all("تعارض قوي" in frame.plan_state for frame in result.frames)


def test_new_listing_daily_history_is_analyzed_but_not_given_a_plan() -> None:
    start = int(datetime(2026, 6, 1, tzinfo=timezone.utc).timestamp())
    candles = []
    price = 100.0
    for index in range(40):
        close = price + 0.8
        candles.append(
            Candle(start + index * 86_400, price, close + 0.5, price - 0.5, close, 1_000_000 + index * 10_000)
        )
        price = close
    frame = analyze_frame_audited(candles, "يومي", "stock")
    assert frame.entry is None
    assert frame.stop is None
    assert not frame.targets
    assert "سجل" in frame.plan_state
    assert any("سجل حديث" in warning for warning in frame.warnings)


def test_webull_class_share_symbol_is_normalized() -> None:
    spec = SymbolSpec("BRK-B", "BRK-B", "BRK-B", "stock", "US")
    mapped = AuditedMultiSourceProvider._provider_spec(spec, "webull")
    assert mapped.display_symbol == "BRK.B"
    assert mapped.yahoo_symbol == "BRK-B"


def test_missing_tradingview_timestamp_deduplicates_retries_but_not_next_minute(tmp_path, monkeypatch) -> None:
    db = AuditedDatabase(tmp_path / "audit.sqlite3")
    payload = TradingViewAlert.model_validate(
        {
            "e": "NL",
            "x": "NASDAQ:AAPL",
            "f": "60",
            "en": 100,
            "sl": 95,
            "t1": 105,
            "t2": 110,
            "t3": 115,
            "q": 70,
            "qm": 100,
        }
    )

    async def scenario() -> None:
        await db.initialize()
        monkeypatch.setattr("app.audited_runtime.time.time", lambda: 1_800_000_000.0)
        _, first_created, _ = await db.record_alert(payload)
        _, retry_created, _ = await db.record_alert(payload)
        monkeypatch.setattr("app.audited_runtime.time.time", lambda: 1_800_000_061.0)
        _, future_created, _ = await db.record_alert(payload)
        assert first_created is True
        assert retry_created is False
        assert future_created is True

    asyncio.run(scenario())
