from app.live_bot import LiveBotService
from app.presets import CATEGORIES, PRESET_BY_ID, presets_for_category


def _callback_values(markup):
    for row in markup.get("inline_keyboard", []):
        for button in row:
            value = button.get("callback_data")
            if value:
                yield value


def test_all_advanced_filter_callbacks_fit_telegram_limit():
    values = list(_callback_values(LiveBotService._main_menu()))
    values += list(_callback_values(LiveBotService._filter_market_menu()))
    for market in ("SAUDI", "US", "FOREX", "CRYPTO"):
        values += list(_callback_values(LiveBotService._filter_categories_menu(market)))
        values += list(_callback_values(LiveBotService._quick_filters_menu(market)))
        for category in CATEGORIES:
            values += list(_callback_values(LiveBotService._preset_menu(market, category.category_id)))
    assert values
    assert max(map(len, values)) <= 64


def test_every_preset_is_reachable_from_its_category():
    reachable = {
        item.preset_id
        for category in CATEGORIES
        for item in presets_for_category(category.category_id)
    }
    assert reachable == set(PRESET_BY_ID)
