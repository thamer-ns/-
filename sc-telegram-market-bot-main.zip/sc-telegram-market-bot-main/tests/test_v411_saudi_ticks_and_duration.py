from __future__ import annotations

import math

from app.risk_engine_v41 import (
    _duration_window,
    profile_for,
    round_market_price,
    saudi_tick_size,
)
from app.technical import Candle, _atr


def test_saudi_equity_tick_table_matches_official_bands() -> None:
    expected = {
        9.99: 0.01,
        10.00: 0.01,
        24.99: 0.01,
        25.00: 0.02,
        49.98: 0.02,
        50.00: 0.05,
        99.95: 0.05,
        100.00: 0.10,
        249.90: 0.10,
        250.00: 0.20,
        499.80: 0.20,
        500.00: 0.50,
    }
    for price, tick in expected.items():
        assert saudi_tick_size(price) == tick


def test_saudi_rounding_rechecks_tick_band_after_crossing_boundary() -> None:
    cases = (
        (24.999, "up", 25.00),
        (25.001, "down", 25.00),
        (49.999, "down", 49.98),
        (49.999, "up", 50.00),
        (99.999, "down", 99.95),
        (99.999, "up", 100.00),
        (249.999, "down", 249.90),
        (249.999, "up", 250.00),
        (499.999, "down", 499.80),
        (499.999, "up", 500.00),
    )
    for raw, mode, expected in cases:
        rounded = round_market_price("SAUDI", raw, mode)
        assert rounded == expected
        units = rounded / saudi_tick_size(rounded)
        assert math.isclose(units, round(units), abs_tol=1e-9)


def _trend_candles(count: int = 340) -> list[Candle]:
    rows: list[Candle] = []
    for index in range(count):
        close = 100.0 + index * 0.05
        rows.append(
            Candle(
                timestamp=1_700_000_000 + index * 3_600,
                open=close - 0.02,
                high=close + 0.20,
                low=close - 0.05,
                close=close,
                volume=1_000_000,
            )
        )
    return rows


def test_duration_uses_regime_matched_first_passage_sample() -> None:
    candles = _trend_candles()
    atr = _atr(candles)
    reference = candles[-1].close
    low, high, samples, hit_rate, method = _duration_window(
        candles,
        direction=1,
        reference=reference,
        stop=reference - atr,
        target=reference + atr,
        current_atr=atr,
        profile=profile_for("ساعة"),
    )
    assert method == "historical-first-passage"
    assert samples >= 8
    assert hit_rate is not None and hit_rate > 0.80
    assert 1 <= low <= high


def test_same_bar_target_stop_collision_is_not_a_success() -> None:
    candles: list[Candle] = []
    for index in range(340):
        close = 100.0 + index * 0.10
        candles.append(
            Candle(
                timestamp=1_700_000_000 + index * 3_600,
                open=close,
                high=close + 2.0,
                low=close - 2.0,
                close=close,
                volume=1_000_000,
            )
        )
    atr = _atr(candles)
    reference = candles[-1].close
    _, _, samples, hit_rate, method = _duration_window(
        candles,
        direction=1,
        reference=reference,
        stop=reference - 0.4 * atr,
        target=reference + 0.4 * atr,
        current_atr=atr,
        profile=profile_for("ساعة"),
    )
    assert method == "atr-range-fallback"
    assert samples > 0
    assert hit_rate == 0.0
