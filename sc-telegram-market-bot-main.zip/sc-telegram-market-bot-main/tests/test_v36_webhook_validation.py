from __future__ import annotations

import pytest
from pydantic import ValidationError

from app.audited_models import AuditedTradingViewAlert


def _long_payload() -> dict[str, object]:
    return {
        "e": "NL",
        "x": "NASDAQ:AAPL",
        "f": "60",
        "d": 1,
        "en": 100,
        "sl": 95,
        "t1": 105,
        "t2": 110,
        "t3": 115,
        "n": 3,
        "q": 70,
        "qm": 100,
    }


def test_valid_long_plan_is_accepted() -> None:
    model = AuditedTradingViewAlert.model_validate(_long_payload())
    assert model.direction == 1
    assert model.entry == 100


def test_long_stop_above_entry_is_rejected() -> None:
    payload = _long_payload()
    payload["sl"] = 101
    with pytest.raises(ValidationError):
        AuditedTradingViewAlert.model_validate(payload)


def test_unsorted_targets_are_rejected() -> None:
    payload = _long_payload()
    payload["t2"] = 104
    with pytest.raises(ValidationError):
        AuditedTradingViewAlert.model_validate(payload)


def test_nonfinite_or_negative_prices_are_rejected() -> None:
    payload = _long_payload()
    payload["en"] = float("nan")
    with pytest.raises(ValidationError):
        AuditedTradingViewAlert.model_validate(payload)
    payload = _long_payload()
    payload["sl"] = -1
    with pytest.raises(ValidationError):
        AuditedTradingViewAlert.model_validate(payload)


def test_state_change_requires_direction() -> None:
    with pytest.raises(ValidationError):
        AuditedTradingViewAlert.model_validate(
            {"e": "T1", "x": "NASDAQ:AAPL", "f": "60", "p": 105, "q": 70, "qm": 100}
        )


def test_score_cannot_exceed_score_max() -> None:
    payload = _long_payload()
    payload["q"] = 101
    payload["qm"] = 100
    with pytest.raises(ValidationError):
        AuditedTradingViewAlert.model_validate(payload)


def test_rejects_future_event_time_and_unsafe_ticker() -> None:
    import time

    base = {
        "source": "TEST",
        "event": "NEW_LONG",
        "tickerid": "TADAWUL:2222",
        "timeframe": "60",
        "direction": 1,
        "entry": 10,
        "stop": 9,
        "target1": 11,
        "target2": 12,
        "target3": 13,
        "target_count": 3,
        "score": 80,
        "score_max": 100,
    }
    with pytest.raises(ValidationError):
        AuditedTradingViewAlert(
            **base,
            event_time_ms=int(time.time() * 1000) + 10 * 60_000,
        )
    with pytest.raises(ValidationError):
        AuditedTradingViewAlert(
            **{**base, "tickerid": "<b>2222</b>"},
            event_time_ms=int(time.time() * 1000),
        )
