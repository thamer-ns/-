from __future__ import annotations

import asyncio

from app.audited_runtime import AuditedDatabase
from app.models import TradingViewAlert


def test_old_event_id_resolves_to_current_plan_state(tmp_path) -> None:
    db = AuditedDatabase(tmp_path / "bot.sqlite3")
    opened = TradingViewAlert.model_validate(
        {
            "e": "NL",
            "x": "TADAWUL:2222",
            "f": "60",
            "t": 1_800_000_000_000,
            "en": 100,
            "sl": 95,
            "t1": 105,
            "t2": 110,
            "t3": 115,
            "q": 70,
            "qm": 100,
        }
    )
    target = TradingViewAlert.model_validate(
        {
            "e": "T1",
            "x": "TADAWUL:2222",
            "f": "60",
            "t": 1_800_000_060_000,
            "d": 1,
            "p": 105,
            "q": 70,
            "qm": 100,
        }
    )

    async def scenario() -> None:
        await db.initialize()
        old_event_id, created, _ = await db.record_alert(opened)
        assert created is True
        _, target_created, _ = await db.record_alert(target)
        assert target_created is True
        current = await db.get_opportunity_by_event(old_event_id)
        assert current is not None
        assert current.status == "TARGET_1"
        assert current.entry == 100
        assert current.target3 == 115

    asyncio.run(scenario())
