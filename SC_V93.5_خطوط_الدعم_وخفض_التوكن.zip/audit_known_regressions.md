# تقرير فاحص الرجوع SC

الملفات المفحوصة: **3** — النتائج: **12**

| حرج | عالٍ | متوسط | منخفض |
|---:|---:|---:|---:|
| 0 | 9 | 3 | 0 |

| الشدة | المعرّف | الملف:السطر | النتيجة |
|---|---|---|---|
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_SC-FXM-V17.5.txt:990` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_SC-FXM-V17.5.txt:991` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_SC-FXM-V17.5.txt:992` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اللحظي_SC-V93.5-I.txt:934` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اللحظي_SC-V93.5-I.txt:935` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اللحظي_SC-V93.5-I.txt:936` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اليومي_SC-V93.5-D.txt:885` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اليومي_SC-V93.5-D.txt:886` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| high | `PINE-HTF-LOOKAHEAD` | `بوصلة_التحليل_اليومي_SC-V93.5-D.txt:887` | lookahead_on بلا إزاحة تاريخية ظاهرة |
| medium | `PINE-SIZE-RISK` | `بوصلة_التحليل_SC-FXM-V17.5.txt:1` | ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل |
| medium | `PINE-SIZE-RISK` | `بوصلة_التحليل_اللحظي_SC-V93.5-I.txt:1` | ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل |
| medium | `PINE-SIZE-RISK` | `بوصلة_التحليل_اليومي_SC-V93.5-D.txt:1` | ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل |

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_SC-FXM-V17.5.txt:990`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe1, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_SC-FXM-V17.5.txt:991`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe2, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_SC-FXM-V17.5.txt:992`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe3, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.5-I.txt:934`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe1, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.5-I.txt:935`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe2, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.5-I.txt:936`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe3, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اليومي_SC-V93.5-D.txt:885`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe1, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اليومي_SC-V93.5-D.txt:886`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe2, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-HTF-LOOKAHEAD — lookahead_on بلا إزاحة تاريخية ظاهرة

- الملف: `بوصلة_التحليل_اليومي_SC-V93.5-D.txt:887`
- الدليل: `request.security(syminfo.tickerid, higherTimeframe3, f_closed_htf_context(), lookahead = barmerge.lookahead_on)`
- الإصلاح: استخدم تعبيرًا مؤكدًا بإزاحة [1] للفاصل الأعلى.

## PINE-SIZE-RISK — ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل

- الملف: `بوصلة_التحليل_SC-FXM-V17.5.txt:1`
- الدليل: `lines=3833`
- الإصلاح: قلّل التكرار واختبر IL tokens داخل Pine Editor.

## PINE-SIZE-RISK — ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل

- الملف: `بوصلة_التحليل_اللحظي_SC-V93.5-I.txt:1`
- الدليل: `lines=3578`
- الإصلاح: قلّل التكرار واختبر IL tokens داخل Pine Editor.

## PINE-SIZE-RISK — ملف كبير يحتاج تجميعًا رسميًا بعد كل تعديل

- الملف: `بوصلة_التحليل_اليومي_SC-V93.5-D.txt:1`
- الدليل: `lines=3730`
- الإصلاح: قلّل التكرار واختبر IL tokens داخل Pine Editor.

## حدود الفاحص

هذا فحص ساكن لأنماط معروفة، وليس مترجم Pine ولا اختبار بيانات سوق. النجاح لا يثبت خلو الكود من كل خطأ مستقبلي.
